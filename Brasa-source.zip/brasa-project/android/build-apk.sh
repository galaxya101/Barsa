#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
npm run build:apk
cd android
./gradlew --no-daemon --max-workers=2 assembleRelease
