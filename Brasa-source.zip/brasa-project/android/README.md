# Brasa Android

This folder contains the native Android shell, launcher icons, import/export
file pickers, reminders, and the home-screen widget. The Android release uses
the separate package ID `app.brasa.timer.fixed` so it can be installed beside
an older Brasa build without replacing or deleting its data.

## Build

Requirements: Node.js 20 or newer, JDK 17 or newer, Android SDK Platform 35,
and Android Build Tools 35.

From the project root:

```sh
npm ci
npm run build:apk
cd android
./gradlew assembleRelease
```

The installable APK is written to
`android/app/build/outputs/apk/release/app-release.apk`.

The first Gradle run downloads Gradle 8.9 and the Android Gradle Plugin if they
are not already cached. The APK is signed with the local Android debug signing
configuration. A Play Store release should be signed with the owner's private
release key instead.
