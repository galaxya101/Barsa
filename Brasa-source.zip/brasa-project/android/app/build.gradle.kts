plugins {
    id("com.android.application")
}

android {
    sourceSets {
        getByName("main") {
            manifest.srcFile("/workspace/artifacts/fixed_AndroidManifest.xml")
        }
    }

    namespace = "app.brasa.timer"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.brasa.timer"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

val generateLauncherAssets by tasks.registering(Exec::class) {
    commandLine("python3", file("scripts/generate_launcher_assets.py").absolutePath)
}

tasks.named("preBuild").configure {
    dependsOn(generateLauncherAssets)
}

val fixManifest by tasks.registering(Exec::class) {
    commandLine("python3", file("scripts/fix_manifest.py").absolutePath)
}

tasks.named("preBuild").configure {
    dependsOn(fixManifest)
}
