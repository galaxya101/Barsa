#!/usr/bin/env python3
"""Fix AndroidManifest.xml: remove app label, set per-icon labels, add StepService."""
from pathlib import Path
import re

p = Path(__file__).resolve().parent.parent / "src" / "main" / "AndroidManifest.xml"
text = p.read_text()

# Permissions
if "FOREGROUND_SERVICE" not in text:
    text = text.replace(
        '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
        '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n'
        '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n'
        '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_HEALTH" />\n'
        '    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />'
    )

# Remove application label
text = text.replace('        android:label="@string/app_name"\n', '')

# MainActivity exported
text = text.replace(
    'android:name="app.brasa.timer.MainActivity"\n            android:configChanges="keyboard|keyboardHidden|orientation|screenSize|smallestScreenSize|uiMode"\n            android:exported="false"',
    'android:name="app.brasa.timer.MainActivity"\n            android:configChanges="keyboard|keyboardHidden|orientation|screenSize|smallestScreenSize|uiMode"\n            android:exported="true"'
)

# Per-icon labels on aliases
def fix_alias(m):
    block = m.group(0)
    nm = re.search(r'Launcher_([a-z]+)_', block)
    if nm:
        icon = nm.group(1)
        block = re.sub(r'android:label="@string/[^"]*"', f'android:label="@string/name_{icon}"', block)
    return block
text = re.sub(r'<activity-alias[\s\S]*?</activity-alias>', fix_alias, text)

# StepService
if "StepService" not in text:
    text = text.replace(
        '    </application>',
        '''
        <service
            android:name="app.brasa.timer.StepService"
            android:exported="false"
            android:foregroundServiceType="health" />
    </application>'''
    )

p.write_text(text)
print(f"Manifest fixed: name_ember={text.count('name_ember')}, StepService={'StepService' in text}")
