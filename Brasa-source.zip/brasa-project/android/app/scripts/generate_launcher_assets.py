#!/usr/bin/env python3
"""Generate iOS 27 liquid-glass launcher icons."""
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
RES = APP / "src" / "main" / "res"
DRAWABLE = RES / "drawable"

THEMES = {
    "carbon": ("#0A0A0C", "#1C1C1E", "#FF7A3C", "#FFB088"),
    "dawn": ("#E8E8ED", "#F7F7FA", "#FF5A1F", "#FF9A6B"),
    "tide": ("#0A0A0C", "#1A2332", "#64D2FF", "#B8ECFF"),
    "bone": ("#EDE8E0", "#F8F4EE", "#FF6B3D", "#FFB08A"),
}

GLYPHS = {
    "ember": [
        ("M24,9 C24,16 19.5,19 17.5,24 C15.5,28 17.5,35 24,37 C30.5,35 32.5,28 30.5,24 C28.5,19 24,16 24,9 Z", "fill"),
        ("M24,21 C22.2,24.5 20.5,26.5 20.5,29.5 C20.5,32.2 22.2,34 24,34 C26.5,34 28.5,32.2 28.5,29.5 C28.5,26.5 26,24.5 24,21 Z", "core"),
    ],
    "anvil": [
        ("M10,17 H38 V22 H32 V25 H36 V29 H28 V36 H20 V29 H12 V25 H16 V22 H10 Z", "fill"),
    ],
    "split": [
        ("M15,14 H22 L17,24 L22,34 H15 L9,24 Z", "fill"),
        ("M26,14 H33 L39,24 L33,34 H26 L32,24 Z", "fill"),
    ],
    "pulse": [
        ("M9,24 H13 V34 H9 Z", "fill"),
        ("M16,13 H20 V34 H16 Z", "fill"),
        ("M24,18 H28 V34 H24 Z", "fill"),
        ("M32,21 H36 V34 H32 Z", "fill"),
    ],
    "orbit": [
        ("M24,13 A11,11 0 1,0 24,35 A11,11 0 1,0 24,13 Z", "stroke"),
        ("M34,13 A2.8,2.8 0 1,0 34,18.6 A2.8,2.8 0 1,0 34,13 Z", "fill"),
    ],
    "stamp": [
        ("M13,13 H35 V35 H13 Z", "stroke"),
        ("M18,30 L30,18", "stroke"),
        ("M24,22.5 A1.8,1.8 0 1,0 24,26.1 A1.8,1.8 0 1,0 24,22.5 Z", "fill"),
    ],
}

SQUIRCLE = "M16,1 H32 Q47,1 47,16 V32 Q47,47 32,47 H16 Q1,47 1,32 V16 Q1,1 16,1 Z"


def make_vector(icon: str, theme: str) -> str:
    dark, mid, accent, accent_light = THEMES[theme]
    is_light = theme in ("dawn", "bone")
    highlight = "#FFFFFF" if not is_light else "#FFFFFF"
    hi_alpha = "0.55" if not is_light else "0.7"
    edge = "#000000" if not is_light else "#000000"
    edge_alpha = "0.35" if not is_light else "0.12"

    parts = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
        '    android:width="48dp"',
        '    android:height="48dp"',
        '    android:viewportWidth="48"',
        '    android:viewportHeight="48">',
        '',
        '    <!-- Liquid glass base -->',
        '    <path android:pathData="' + SQUIRCLE + '">',
        '        <aapt:attr name="android:fillColor" xmlns:aapt="http://schemas.android.com/aapt">',
        '            <gradient',
        '                android:type="linear"',
        '                android:startX="24" android:startY="0"',
        '                android:endX="24" android:endY="48"',
        f'                android:startColor="{mid}"',
        f'                android:endColor="{dark}" />',
        '        </aapt:attr>',
        '    </path>',
        '',
        '    <!-- Soft inner depth -->',
        f'    <path android:fillColor="{edge}" android:fillAlpha="{edge_alpha}"',
        '        android:pathData="M1,28 H47 V32 Q47,47 32,47 H16 Q1,47 1,32 Z" />',
        '',
        '    <!-- Specular highlight (liquid glass shine) -->',
        f'    <path android:fillColor="{highlight}" android:fillAlpha="{hi_alpha}"',
        '        android:pathData="M2,2 H46 Q47,2 47,8 V18 Q36,10 24,9 Q12,10 1,18 V8 Q1,2 8,2 Z" />',
        '',
        '    <!-- Accent glass tint blob -->',
        f'    <path android:fillColor="{accent}" android:fillAlpha="0.18"',
        '        android:pathData="M8,20 Q24,12 40,22 Q42,32 24,38 Q6,32 8,20 Z" />',
        '',
    ]

    for path, mode in GLYPHS[icon]:
        if mode == "core":
            parts.append(f'    <path android:fillColor="{dark}" android:pathData="{path}" />')
        elif mode == "stroke":
            parts.append(
                f'    <path android:fillColor="@android:color/transparent" android:strokeColor="{accent}" '
                f'android:strokeWidth="3.2" android:strokeLineCap="round" android:strokeLineJoin="round" '
                f'android:pathData="{path}" />'
            )
            # lighter stroke glow
            parts.append(
                f'    <path android:fillColor="@android:color/transparent" android:strokeColor="{accent_light}" '
                f'android:strokeWidth="1.2" android:strokeLineCap="round" android:strokeLineJoin="round" '
                f'android:pathData="{path}" />'
            )
        else:
            # glyph with slight top highlight via second lighter path offset
            parts.append(f'    <path android:fillColor="{accent}" android:pathData="{path}" />')
            parts.append(
                f'    <path android:fillColor="{accent_light}" android:fillAlpha="0.45" '
                f'android:pathData="{path}" />'
            )

    # Inner glass rim
    parts.append(
        f'    <path android:fillColor="@android:color/transparent" android:strokeColor="#FFFFFF" '
        f'android:strokeAlpha="0.28" android:strokeWidth="1" '
        f'android:pathData="{SQUIRCLE}" />'
    )
    parts.append("</vector>")
    return "\n".join(parts) + "\n"


def main():
    print('Skipping icon generation (keeping existing)'); return
    DRAWABLE.mkdir(parents=True, exist_ok=True)
    for icon in GLYPHS:
        for theme in THEMES:
            name = f"launcher_{icon}_{theme}.xml"
            (DRAWABLE / name).write_text(make_vector(icon, theme), encoding="utf-8")
            print(f"wrote {name}")
    print("Done: 24 liquid-glass icons")


if __name__ == "__main__":
    main()
