package app.brasa.timer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONObject;

public final class StepService extends Service implements SensorEventListener {
    public static final String ACTION_START = "app.brasa.timer.STEP_START";
    public static final String ACTION_STOP = "app.brasa.timer.STEP_STOP";
    public static final String ACTION_SNAPSHOT = "app.brasa.timer.STEP_SNAPSHOT";
    private static final String PREFS = "brasa_steps";
    private static final String CHANNEL = "brasa_steps";
    private static final int NOTIF_ID = 42;

    private SensorManager sensorManager;
    private Sensor stepSensor;
    private PowerManager.WakeLock wakeLock;
    private long lastTotal = -1;
    private int todaySteps = 0;
    private String todayDate = "";

    public static void start(Context context) {
        Intent i = new Intent(context, StepService.class);
        i.setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }

    public static void stop(Context context) {
        Intent i = new Intent(context, StepService.class);
        i.setAction(ACTION_STOP);
        context.startService(i);
    }

    public static String snapshot(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, MODE_PRIVATE);
        try {
            JSONObject o = new JSONObject();
            o.put("active", prefs.getBoolean("active", false));
            o.put("steps", prefs.getInt("today", 0));
            o.put("date", prefs.getString("date", ""));
            o.put("source", "hardware");
            o.put("permission", "granted");
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) : null;
        if (stepSensor == null && sensorManager != null) {
            stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        }
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Brasa:StepWake");
            wakeLock.setReferenceCounted(false);
        }
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            Notification notif = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH);
            } else {
                startForeground(NOTIF_ID, notif);
            }
        } catch (Exception e) {
            // If we can't go foreground, stop cleanly so the app doesn't crash
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(10 * 60 * 1000L);
            registerSensor();
            loadState();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("active", true).apply();
        } catch (Exception ignored) {}
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void registerSensor() {
        if (sensorManager == null || stepSensor == null) return;
        sensorManager.unregisterListener(this);
        sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void loadState() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        todaySteps = prefs.getInt("today", 0);
        todayDate = prefs.getString("date", currentDate());
        lastTotal = prefs.getLong("lastTotal", -1);
        if (!todayDate.equals(currentDate())) {
            todaySteps = 0;
            todayDate = currentDate();
            lastTotal = -1;
        }
    }

    private void saveState() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("today", todaySteps)
                .putString("date", todayDate)
                .putLong("lastTotal", lastTotal)
                .putBoolean("active", true)
                .apply();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            long total = (long) event.values[0];
            if (lastTotal < 0) lastTotal = total;
            long delta = total - lastTotal;
            if (delta > 0 && delta < 1000) { // ignore huge jumps
                todaySteps += (int) delta;
                lastTotal = total;
                saveState();
                updateNotification();
            }
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            todaySteps += 1;
            saveState();
                updateNotification();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private String currentDate() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Pasos Brasa", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Contador de pasos en segundo plano");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        String text = todaySteps > 0 ? todaySteps + " pasos hoy" : "Contando pasos en segundo plano";
        return builder
                .setContentTitle("Brasa · Pasos")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_directions)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_LOW)
                .build();
    }

    private void updateNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification());
        } catch (Exception ignored) {}
    }
}
