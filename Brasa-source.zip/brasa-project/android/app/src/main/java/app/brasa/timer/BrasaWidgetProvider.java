package app.brasa.timer;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import org.json.JSONObject;

public final class BrasaWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_OPEN = "app.brasa.timer.WIDGET_OPEN";
    private static final String PREFS = "brasa_widget";

    public static void updateAll(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, BrasaWidgetProvider.class));
            if (ids == null || ids.length == 0) return;
            for (int id : ids) {
                manager.updateAppWidget(id, build(context));
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onEnabled(Context context) {
        updateAll(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            try {
                manager.updateAppWidget(id, build(context));
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent == null) return;
        String action = intent.getAction();
        if (ACTION_OPEN.equals(action) || "android.appwidget.action.APPWIDGET_UPDATE".equals(action)) {
            if (ACTION_OPEN.equals(action)) {
                try {
                    Intent launch = new Intent(context, MainActivity.class);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(launch);
                } catch (Exception ignored) {}
            }
            updateAll(context);
        }
    }

    private static RemoteViews build(Context context) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_brasa);
        String title = "Brasa";
        String detail = "Toca para abrir";
        String timer = "00:00";
        try {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("payload", "{}");
            JSONObject p = new JSONObject(json);
            title = p.optString("title", "Brasa");
            detail = p.optString("detail", "Toca para abrir");
            if (p.optBoolean("active", false)) {
                long ms = p.optLong("remainingMs", 0);
                long sec = Math.max(0, (ms + 999) / 1000);
                timer = String.format(java.util.Locale.ROOT, "%02d:%02d", sec / 60, sec % 60);
            } else {
                timer = p.optString("hero", "00:00");
            }
        } catch (Exception ignored) {}
        views.setTextViewText(R.id.widget_timer, timer);
        views.setTextViewText(R.id.widget_title, title);
        views.setTextViewText(R.id.widget_detail, detail);
        views.setTextViewText(R.id.widget_kicker, "BRASA");
        views.setTextViewText(R.id.widget_action, "Abrir");

        Intent open = new Intent(context, BrasaWidgetProvider.class).setAction(ACTION_OPEN);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        views.setOnClickPendingIntent(R.id.widget_action, pi);
        return views;
    }
}
