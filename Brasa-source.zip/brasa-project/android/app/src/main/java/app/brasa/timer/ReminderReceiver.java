package app.brasa.timer;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

public final class ReminderReceiver extends BroadcastReceiver {
    private static final String PREFS = "brasa_reminders";
    private static final String KEY = "json";
    private static final String CHANNEL = "brasa-reminders";
    private static final String ACTION = "app.brasa.timer.REMINDER";

    static void sync(Context context, String json) {
        if (json == null) return;
        Context app = context.getApplicationContext();
        String old = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        cancelAll(app, old);
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply();
        scheduleAll(app, json);
    }

    static void rescheduleSaved(Context context) {
        String json = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        scheduleAll(context.getApplicationContext(), json);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION.equals(intent.getAction())) return;
        String body = intent.getStringExtra("body");
        if (!MainActivity.isVisible) postNotification(context, body);
        scheduleNext(
                context,
                intent.getStringExtra("id"),
                intent.getIntExtra("day", -1),
                intent.getIntExtra("hour", 18),
                intent.getIntExtra("minute", 0),
                body);
    }

    private static void scheduleAll(Context context, String json) {
        try {
            JSONArray reminders = new JSONArray(json);
            for (int i = 0; i < reminders.length(); i++) {
                JSONObject reminder = reminders.optJSONObject(i);
                if (reminder == null || !reminder.optBoolean("enabled", false)) continue;
                JSONArray days = reminder.optJSONArray("days");
                if (days == null) continue;
                String id = reminder.optString("id", "");
                String body = reminder.optString("label", "Hora de entrenar");
                int hour = reminder.optInt("hour", 18);
                int minute = reminder.optInt("minute", 0);
                for (int j = 0; j < days.length(); j++) {
                    int day = days.optInt(j, -1);
                    if (day >= 0 && day <= 6) scheduleNext(context, id, day, hour, minute, body);
                }
            }
        } catch (Exception ignored) {
            // Ignore a malformed reminder store without preventing app launch.
        }
    }

    private static void cancelAll(Context context, String json) {
        try {
            JSONArray reminders = new JSONArray(json);
            AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarms == null) return;
            for (int i = 0; i < reminders.length(); i++) {
                JSONObject reminder = reminders.optJSONObject(i);
                if (reminder == null) continue;
                JSONArray days = reminder.optJSONArray("days");
                if (days == null) continue;
                for (int j = 0; j < days.length(); j++) {
                    cancelOne(context, alarms, reminder.optString("id", ""), days.optInt(j, -1));
                }
            }
        } catch (Exception ignored) {
            // Existing alarms are best-effort cleanup.
        }
    }

    private static void cancelOne(Context context, AlarmManager alarms, String id, int day) {
        PendingIntent pending = pendingIntent(context, id, day, 0, 0, "");
        if (pending != null) {
            alarms.cancel(pending);
            pending.cancel();
        }
    }

    private static void scheduleNext(Context context, String id, int day, int hour, int minute, String body) {
        if (id == null || day < 0 || day > 6) return;
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
        next.set(Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        int targetDay = day + 1; // Java Calendar uses Sunday=1; settings use Sunday=0.
        while (next.get(Calendar.DAY_OF_WEEK) != targetDay || next.getTimeInMillis() <= System.currentTimeMillis()) {
            next.add(Calendar.DAY_OF_YEAR, 1);
        }
        PendingIntent pending = pendingIntent(context, id, day, hour, minute, body);
        if (pending == null) return;
        try {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
        } catch (Exception ignored) {
            // The in-app reminder engine remains available if the OS blocks alarms.
        }
    }

    private static PendingIntent pendingIntent(Context context, String id, int day, int hour, int minute, String body) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION);
        intent.setData(android.net.Uri.parse("brasa://reminder/" + UriSafe(id) + "/" + day));
        intent.putExtra("id", id);
        intent.putExtra("day", day);
        intent.putExtra("hour", hour);
        intent.putExtra("minute", minute);
        intent.putExtra("body", body);
        int requestCode = (id + ":" + day).hashCode();
        return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String UriSafe(String value) {
        return value.replaceAll("[^A-Za-z0-9_-]", "_");
    }

    private static void postNotification(Context context, String body) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(new NotificationChannel(CHANNEL, "Recordatorios de Brasa", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Notification notification = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Brasa")
                .setContentText(body == null || body.isEmpty() ? "Hora de entrenar" : body)
                .setAutoCancel(true)
                .build();
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), notification);
    }
}
