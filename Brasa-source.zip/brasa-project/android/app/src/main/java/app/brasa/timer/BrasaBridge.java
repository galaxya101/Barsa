package app.brasa.timer;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

public final class BrasaBridge {
    private final MainActivity activity;

    BrasaBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public boolean setIcon(String id, String theme) {
        return activity.setSelectedIcon(id, theme);
    }

    @JavascriptInterface
    public boolean saveFile(String filename, String mimeType, String content) {
        return activity.saveFile(filename, mimeType, content);
    }

    @JavascriptInterface
    public void syncWidget(String json) {
        try {
            new JSONObject(json);
            activity.getSharedPreferences("brasa_widget", Context.MODE_PRIVATE)
                    .edit()
                    .putString("payload", json)
                    .apply();
            BrasaWidgetProvider.updateAll(activity);
        } catch (Exception ignored) {
            Toast.makeText(activity, "No se pudo actualizar el widget", Toast.LENGTH_SHORT).show();
        }
    }

    @JavascriptInterface
    public boolean pinWidget() {
        if (Build.VERSION.SDK_INT < 26) return false;
        AppWidgetManager manager = AppWidgetManager.getInstance(activity);
        if (!manager.isRequestPinAppWidgetSupported()) return false;
        try {
            manager.requestPinAppWidget(
                    new ComponentName(activity, BrasaWidgetProvider.class),
                    null,
                    null);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    @JavascriptInterface
    public void syncReminders(String json) {
        ReminderReceiver.sync(activity, json);
    }

    @JavascriptInterface
    public void notify(String title, String body) {
        activity.showNotification(title, body);
    }

    @JavascriptInterface
    public void keepAwake(boolean enabled) {
        activity.setKeepAwake(enabled);
    }

    @JavascriptInterface
    public void vibrate(String pattern) {
        vibrate(activity, pattern);
    }

    @JavascriptInterface
    public boolean speak(String text, String language, float volume, float rate, float pitch) {
        return activity.speak(text, language, volume, rate, pitch);
    }

    @JavascriptInterface
    public void stopSpeech() {
        activity.stopSpeech();
    }


    @JavascriptInterface
    public boolean startStepTracking(int goal, String unit) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                if (activity.checkSelfPermission(android.Manifest.permission.ACTIVITY_RECOGNITION)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    activity.requestPermissions(
                            new String[]{android.Manifest.permission.ACTIVITY_RECOGNITION}, 4104);
                    return false;
                }
            }
            StepService.start(activity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void stopStepTracking() {
        StepService.stop(activity);
    }

    @JavascriptInterface
    public String stepSnapshot() {
        return StepService.snapshot(activity);
    }

    static void vibrate(Context context, String pattern) {
        try {
            String[] pieces = pattern == null ? new String[0] : pattern.split(",");
            long[] timings = new long[pieces.length];
            for (int i = 0; i < pieces.length; i++) {
                timings[i] = Math.max(1, Long.parseLong(pieces[i].trim()));
            }
            if (timings.length == 0) return;
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(timings, -1));
            else vibrator.vibrate(timings, -1);
        } catch (Exception ignored) {
            // Haptics are optional on devices without a compatible vibrator.
        }
    }
}
