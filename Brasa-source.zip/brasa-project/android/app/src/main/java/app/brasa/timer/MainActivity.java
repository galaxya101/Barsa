package app.brasa.timer;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 4101;
    private static final int REQUEST_EXPORT = 4102;
    private static final int REQUEST_NOTIFICATIONS = 4103;
    private static final String APP_ASSET_HOST = "appassets.androidplatform.net";
    private static final String NOTIFICATION_CHANNEL = "brasa-reminders";

    public static volatile boolean isVisible = false;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingExportName;
    private String pendingExportMime;
    private String pendingExportContent;
    private String pendingWidgetAction;
    private TextToSpeech textToSpeech;
    private boolean speechReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
        setupWebView();
        requestActivityRecognitionIfNeeded();
        ensureWidgetPayload();
        try { BrasaWidgetProvider.updateAll(this); } catch (Exception ignored) {}
        handleWidgetIntent(getIntent());
    }

    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.addJavascriptInterface(new BrasaBridge(this), "BrasaNative");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent chooser = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                chooser.addCategory(Intent.CATEGORY_OPENABLE);
                chooser.setType("*/*");
                chooser.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try {
                    startActivityForResult(chooser, REQUEST_IMPORT);
                    return true;
                } catch (Exception error) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return localAsset(request.getUrl());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return localAsset(Uri.parse(url));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_ASSET_HOST.equals(uri.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "No se puede abrir este enlace", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                dispatchWidgetAction();
            }
        });

        setContentView(webView);
        webView.loadUrl("https://" + APP_ASSET_HOST + "/assets/index.html");
        textToSpeech = new TextToSpeech(this, status -> speechReady = status == TextToSpeech.SUCCESS);
        setThemeChrome("carbon");
    }

    private WebResourceResponse localAsset(Uri uri) {
        if (!APP_ASSET_HOST.equals(uri.getHost())) return null;
        String assetPath = uri.getPath();
        if (assetPath == null || assetPath.equals("/")) return null;
        assetPath = assetPath.startsWith("/") ? assetPath.substring(1) : assetPath;
        if (assetPath.startsWith("assets/")) assetPath = assetPath.substring("assets/".length());
        try {
            InputStream stream = getAssets().open(assetPath);
            String extension = MimeTypeMap.getFileExtensionFromUrl(assetPath);
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            if (mime == null) {
                if (assetPath.endsWith(".js")) mime = "text/javascript";
                else if (assetPath.endsWith(".css")) mime = "text/css";
                else if (assetPath.endsWith(".svg")) mime = "image/svg+xml";
                else if (assetPath.endsWith(".json")) mime = "application/json";
                else mime = "application/octet-stream";
            }
            String encoding = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") ? "UTF-8" : null;
            return new WebResourceResponse(mime, encoding, stream);
        } catch (Exception ignored) {
            return new WebResourceResponse(
                    "text/plain", "UTF-8", 404, "Not found", null,
                    new java.io.ByteArrayInputStream(new byte[0]));
        }
    }

    public boolean setSelectedIcon(String id, String theme) {
        if (!isValidIcon(id) || !isValidTheme(theme)) return false;
        PackageManager manager = getPackageManager();
        try {
            for (String icon : new String[]{"ember", "anvil", "split", "pulse", "orbit", "stamp"}) {
                for (String themeId : new String[]{"carbon", "dawn", "tide", "bone"}) {
                    String className = "app.brasa.timer.Launcher_" + icon + "_" + themeId;
                    manager.setComponentEnabledSetting(
                            new ComponentName(getPackageName(), className),
                            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                            PackageManager.DONT_KILL_APP);
                }
            }
            String selected = "app.brasa.timer.Launcher_" + id + "_" + theme;
            manager.setComponentEnabledSetting(
                    new ComponentName(getPackageName(), selected),
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP);
            // Force launcher to refresh icon + name
            try {
                Intent refresh = new Intent(Intent.ACTION_MAIN);
                refresh.addCategory(Intent.CATEGORY_HOME);
                refresh.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                sendBroadcast(refresh);
            } catch (Exception ignored) {}
            runOnUiThread(() -> {
                setThemeChrome(theme);
                try {
                    int resId = getResources().getIdentifier("name_" + id, "string", getPackageName());
                    String label = resId != 0 ? getString(resId) : "Brasa";
                    setTaskDescription(new android.app.ActivityManager.TaskDescription(label));
                    // Also update the activity title for good measure
                    setTitle(label);
                } catch (Exception ignored) {}
            });
            return true;
        } catch (Exception ignored) {
            runOnUiThread(() -> { setThemeChrome(theme); requestBatteryExemption(); });
            return false;
        }
    }

    private boolean isValidIcon(String id) {
        return "ember".equals(id) || "anvil".equals(id) || "split".equals(id)
                || "pulse".equals(id) || "orbit".equals(id) || "stamp".equals(id);
    }

    private boolean isValidTheme(String theme) {
        return "carbon".equals(theme) || "dawn".equals(theme) || "tide".equals(theme) || "bone".equals(theme);
    }

    
    private void requestBatteryExemption() {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        } catch (Exception ignored) {}
    }

    private void setThemeChrome(String theme) {
        int background = ("dawn".equals(theme) || "bone".equals(theme))
                ? Color.rgb(242, 242, 247) : Color.BLACK;
        Window window = getWindow();
        window.setStatusBarColor(background);
        window.setNavigationBarColor(background);
        int flags = 0;
        if ("dawn".equals(theme) || "bone".equals(theme)) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);
    }

    public boolean saveFile(String filename, String mimeType, String content) {
        if (filename == null || content == null) return false;
        pendingExportName = filename.replaceAll("[^A-Za-z0-9._-]", "-");
        pendingExportMime = mimeType == null ? "application/octet-stream" : mimeType.split(";", 2)[0];
        pendingExportContent = content;
        runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(pendingExportMime);
            intent.putExtra(Intent.EXTRA_TITLE, pendingExportName);
            try {
                startActivityForResult(intent, REQUEST_EXPORT);
            } catch (Exception error) {
                clearPendingExport();
                Toast.makeText(this, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show();
            }
        });
        return true;
    }

    private void clearPendingExport() {
        pendingExportName = null;
        pendingExportMime = null;
        pendingExportContent = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT) {
            if (fileChooserCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_EXPORT) {
            Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if (uri != null && pendingExportContent != null) {
                try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                    if (output == null) throw new IllegalStateException("No se pudo crear el archivo");
                    output.write(pendingExportContent.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Archivo guardado", Toast.LENGTH_SHORT).show();
                } catch (Exception error) {
                    Toast.makeText(this, "No se pudo guardar el archivo", Toast.LENGTH_LONG).show();
                }
            }
            clearPendingExport();
        }
    }

    public void showNotification(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotificationPermissionIfNeeded();
            return;
        }
        Notification notification = new Notification.Builder(this, NOTIFICATION_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "Brasa" : title)
                .setContentText(body == null ? "" : body)
                .setAutoCancel(true)
                .build();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), notification);
    }

    private void createNotificationChannel() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null || Build.VERSION.SDK_INT < 26) return;
        manager.createNotificationChannel(new NotificationChannel(
                NOTIFICATION_CHANNEL, "Recordatorios de Brasa", NotificationManager.IMPORTANCE_DEFAULT));
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    public void setKeepAwake(boolean enabled) {
        runOnUiThread(() -> {
            if (enabled) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    public void vibrate(String pattern) {
        BrasaBridge.vibrate(this, pattern);
    }

    public boolean speak(String text, String language, float volume, float rate, float pitch) {
        if (!speechReady || textToSpeech == null || text == null || text.trim().isEmpty()) return false;
        runOnUiThread(() -> {
            Locale locale = Locale.forLanguageTag(language == null ? "es-ES" : language);
            textToSpeech.setLanguage(locale);
            textToSpeech.setSpeechRate(Math.max(0.5f, Math.min(2f, rate)));
            textToSpeech.setPitch(Math.max(0.5f, Math.min(2f, pitch)));
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
            textToSpeech.speak(text, TextToSpeech.QUEUE_ADD, params, "brasa-" + System.currentTimeMillis());
        });
        return true;
    }

    public void stopSpeech() {
        runOnUiThread(() -> {
            if (textToSpeech != null) textToSpeech.stop();
        });
    }

    private void handleWidgetIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getStringExtra("brasa_widget_action");
        if (action != null) pendingWidgetAction = action;
    }

    private void dispatchWidgetAction() {
        if (pendingWidgetAction == null || webView == null) return;
        String action = pendingWidgetAction;
        pendingWidgetAction = null;
        webView.postDelayed(() -> webView.evaluateJavascript(
                "(function(){if(window.__brasaWidget){window.__brasaWidget('" + action + "');return true;}return false;})()",
                null), 650);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleWidgetIntent(intent);
        dispatchWidgetAction();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isVisible = true;
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        isVisible = false;
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript("(window.__brasaBack ? window.__brasaBack() : false)", result -> {
            if (!"true".equals(result)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        isVisible = false;
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("BrasaNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void ensureWidgetPayload() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("brasa_widget", MODE_PRIVATE);
            String existing = prefs.getString("payload", null);
            if (existing == null || existing.isEmpty() || "{}".equals(existing)) {
                String def = "{\"active\":false,\"title\":\"Brasa\",\"kicker\":\"BRASA\",\"detail\":\"Abre la app para empezar\",\"hero\":\"0\",\"actionLabel\":\"Abrir\",\"theme\":\"carbon\"}";
                prefs.edit().putString("payload", def).apply();
                BrasaWidgetProvider.updateAll(this);
            }
        } catch (Exception ignored) {}
    }

    private void requestActivityRecognitionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 4104);
        }
    }
}
