import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Editor } from "@/components/brasa/editor";
import { FocusScreen } from "@/components/brasa/focus";
import { Home } from "@/components/brasa/home";
import { Library } from "@/components/brasa/library";
import { Settings } from "@/components/brasa/settings";
import { Shell } from "@/components/brasa/shell";
import { Stats } from "@/components/brasa/stats";
import { StepsScreen } from "@/components/brasa/steps";
import { TimerScreen } from "@/components/brasa/timer";
import { useBrasa } from "@/lib/brasa/store";
import "@/styles.css";

function BrasaApp() {
  const screen = useBrasa((state) => state.screen);
  return (
    <Shell>
      {screen.name === "home" && <Home />}
      {screen.name === "library" && <Library />}
      {screen.name === "edit" && <Editor id={screen.id} />}
      {screen.name === "run" && <TimerScreen />}
      {screen.name === "stats" && <Stats />}
      {screen.name === "settings" && <Settings />}
      {screen.name === "steps" && <StepsScreen />}
      {screen.name === "focus" && <FocusScreen />}
    </Shell>
  );
}

const root = document.getElementById("root");
if (root) createRoot(root).render(<StrictMode><BrasaApp /></StrictMode>);
