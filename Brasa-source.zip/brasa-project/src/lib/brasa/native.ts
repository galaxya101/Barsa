import { formatClock, streaks } from "./engine";
import { kindLabel, t } from "./i18n";
import type { Lang, RunState, SessionLog } from "./types";

export type BrasaNative = {
  setIcon?: (id: string, theme?: string) => boolean;
  speak?: (text: string, language: string, volume: number, rate: number, pitch: number) => boolean;
  stopSpeech?: () => void;
  saveFile?: (filename: string, mimeType: string, content: string) => boolean;
  syncWidget?: (json: string) => void;
  syncReminders?: (json: string) => void;
  pinWidget?: () => boolean;
  notify?: (title: string, body: string) => void;
  keepAwake?: (on: boolean) => void;
  vibrate?: (pattern: string) => void;
  startStepTracking?: (goal: number, unit: string) => boolean;
  stopStepTracking?: () => void;
  stepSnapshot?: () => string;
};

export function brasaNative(): BrasaNative | undefined {
  if (typeof window === "undefined") return undefined;
  return (window as Window & { BrasaNative?: BrasaNative }).BrasaNative;
}

export function setNativeIcon(id: string, theme: string): boolean {
  const bridge = brasaNative();
  if (!bridge?.setIcon) return false;
  try {
    if (bridge.setIcon(id, theme)) return true;
  } catch {
    // Older Android wrappers expose only setIcon(id).
  }
  try {
    return bridge.setIcon(id);
  } catch {
    return false;
  }
}

type Segment = { endsAt: number; title: string; detail: string };

export function widgetPayload(lang: Lang, run: RunState | null, sessions: SessionLog[]) {
  const label = (key: "streak" | "widgetIdle" | "round" | "of" | "pause" | "resume" | "openApp" | "ready" | "widget" | "paused" | "widgetDone") =>
    t(lang, key);
  const active = Boolean(run && run.phase !== "done" && run.steps.length);
  const paused = run?.phase === "paused";
  const readyPhase = Boolean(active && run && (run.phase === "ready" || run.pausedFrom === "ready"));
  const step = active && run ? run.steps[run.index] : undefined;
  const segments: Segment[] = [];
  if (active && run) {
    const detailFor = (item: (typeof run.steps)[number]) =>
      `${kindLabel(lang, item.kind)} · ${label("round")} ${item.round} ${label("of")} ${item.rounds}`;
    if (readyPhase) {
      segments.push({
        endsAt: paused ? 0 : run.segmentEndsAt ?? 0,
        title: label("ready"),
        detail: run.workoutName,
      });
      if (!paused) {
        let cursor = run.segmentEndsAt ?? Date.now();
        for (const item of run.steps) {
          cursor += item.seconds * 1000;
          segments.push({ endsAt: cursor, title: item.name || run.workoutName, detail: detailFor(item) });
        }
      }
    } else {
      let cursor = run.segmentEndsAt ?? Date.now();
      run.steps.slice(run.index).forEach((item, offset) => {
        if (offset > 0 && !paused) cursor += item.seconds * 1000;
        segments.push({
          endsAt: paused ? 0 : offset === 0 ? (run.segmentEndsAt ?? cursor) : cursor,
          title: item.name || run.workoutName,
          detail: detailFor(item),
        });
      });
    }
  }
  const title = !active ? label("streak") : readyPhase ? label("ready") : step?.name || run?.workoutName || "Brasa";
  const detail = !active
    ? label("widgetIdle")
    : readyPhase
      ? run?.workoutName || ""
      : step
        ? `${kindLabel(lang, step.kind)} · ${label("round")} ${step.round} ${label("of")} ${step.rounds}`
        : "";
  const now = Date.now();
  return {
    active,
    paused: Boolean(paused),
    endsAt: active && run && !paused ? run.segmentEndsAt ?? 0 : 0,
    remainingMs: active && run ? (paused ? run.remainingMs : Math.max(0, (run.segmentEndsAt ?? now) - now)) : 0,
    hero: active && run ? formatClock(paused ? run.remainingMs : Math.max(0, (run.segmentEndsAt ?? now) - now)) : String(streaks(sessions).current),
    title,
    detail,
    action: !active ? "open" : paused ? "resume" : "pause",
    actionLabel: !active ? label("openApp") : paused ? label("resume") : label("pause"),
    kicker: active ? (paused ? label("paused") : label("widget")) : "BRASA",
    workoutName: run?.workoutName || "Brasa",
    doneDetail: label("widgetDone"),
    openLabel: label("openApp"),
    segments,
  };
}
