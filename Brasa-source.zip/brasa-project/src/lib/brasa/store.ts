import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import {
  catchUpPomo,
  choosePhase,
  creditTasks,
  defaultPomo,
  defaultSteps,
  normalizePomo,
  normalizeSteps,
  normalizeTasks,
  pausePomo,
  setPomoMinutes,
  skipPomo,
  startPomo,
  addSteps as addStepCount,
  type PomoEvent,
  type PomoPhase,
  type PomodoroState,
  type StepsState,
  type TaskItem,
} from "./day";
import { createRun, flatten, jumpTo, nudge, pauseRun, plannedSeconds, resumeRun, skipNext, skipPrev, tick, trainedMs } from "./engine";
import type { EngineEvent } from "./types";
import { builtinWorkouts, freshInterval, quickWorkout, relocalize } from "./samples";
import { t } from "./i18n";
import { APP_ICONS, THEMES } from "./types";
import type { Block, Lang, QuickKind, RunState, Screen, SessionLog, Settings, ThemeId, Workout } from "./types";
import { defaultColor, emptyNotes } from "./types";

export type RunOrigin = "home" | "library" | "edit";

type Toast = { id: string; text: string } | null;

type Backup = {
  app: "brasa";
  version: 1 | 2 | 3;
  workouts: Workout[];
  sessions: SessionLog[];
  settings: Settings;
  customCategories: string[];
  weekPlan?: (string | null)[];
  tasks?: TaskItem[];
  steps?: StepsState;
  pomo?: PomodoroState;
};

type Persisted = {
  workouts: Workout[];
  sessions: SessionLog[];
  settings: Settings;
  customCategories: string[];
  weekPlan: (string | null)[];
  run: RunState | null;
  tasks: TaskItem[];
  steps: StepsState;
  pomo: PomodoroState;
};

export type BrasaState = Persisted & {
  screen: Screen;
  runOrigin: RunOrigin;
  editReturn: "home" | "library";
  toast: Toast;
  dirty: boolean;
  hydrated: boolean;
  go: (screen: Screen) => void;
  toastTo: (text: string) => void;
  clearToast: () => void;
  setTheme: (theme: ThemeId) => void;
  setLang: (lang: Lang) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  startWorkout: (id: string) => EngineEvent[];
  quickStart: (kind: QuickKind) => EngineEvent[];
  tickRun: (now: number) => EngineEvent[];
  pause: () => void;
  resume: () => void;
  nudgeRun: (deltaMs: number) => void;
  jump: (index: number) => EngineEvent[];
  next: () => EngineEvent[];
  prev: () => EngineEvent[];
  leaveRun: () => void;
  savePartial: () => "saved" | "short" | "none";
  discardRun: () => void;
  updateLog: (patch: { rpe?: number | null; note?: string }) => void;
  dismissSummary: () => void;
  createWorkout: () => string;
  duplicateWorkout: (id: string) => string | null;
  deleteWorkout: (id: string) => void;
  toggleFavorite: (id: string) => void;
  updateWorkout: (id: string, updater: (workout: Workout) => Workout) => void;
  restoreSamples: () => void;
  addCategory: (name: string) => void;
  setWeekSlot: (index: number, workoutId: string | null) => void;
  deleteSession: (id: string) => void;
  exportBackup: () => Backup;
  importBackup: (data: unknown) => boolean;
  exportWorkout: (id: string) => Workout | null;
  importWorkout: (data: unknown) => boolean;
  addStep: () => void;
  setStepGoal: (goal: number) => void;
  setStepTracking: (tracking: boolean) => void;
  addTask: (title: string) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  selectPomoTask: (id: string | null) => void;
  setPomoLength: (phase: PomoPhase, minutes: number) => void;
  choosePomo: (phase: PomoPhase) => void;
  startFocus: () => void;
  pauseFocus: () => void;
  skipFocus: () => PomoEvent[];
  settlePomo: (now: number) => PomoEvent[];
};

const memoryStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

export const defaultSettings = (): Settings => ({
  theme: "carbon",
  lang: "es",
  appIcon: "ember",
  largeText: false,
  soundEnabled: true,
  soundPack: "bell",
  soundVolume: 0.8,
  voiceEnabled: true,
  voiceVolume: 1,
  voiceStyle: "energetic",
  ducking: true,
  ambience: false,
  ambienceKind: "rain",
  ambienceVolume: 0.55,
  vibration: true,
  keepAwake: true,
  countdown: true,
  announceNext: true,
  getReadySeconds: 5,
  metronomeBpm: 0,
  dailyGoalMinutes: 20,
  weeklyGoalSessions: 4,
  reminders: [],
});

function emptyWeek(): (string | null)[] {
  return [null, null, null, null, null, null, null];
}

function normalizePlan(value: unknown): (string | null)[] {
  const slots = Array.isArray(value) ? value.slice(0, 7) : [];
  while (slots.length < 7) slots.push(null);
  return slots.map((item) => (typeof item === "string" && item ? item : null));
}

function logSession(run: RunState, completed: boolean, now: number): SessionLog {
  return {
    id: uid(),
    workoutId: run.workoutId,
    workoutName: run.workoutName,
    category: run.category,
    startedAt: run.startedAt,
    endedAt: now,
    completed,
    elapsedSeconds: Math.max(1, Math.round(trainedMs(run, now) / 1000)),
    plannedSeconds: plannedSeconds(run.steps),
    note: "",
    rpe: null,
  };
}

function withLog(run: RunState, sessions: SessionLog[], completed: boolean, now: number): { run: RunState; sessions: SessionLog[] } {
  if (run.logged && run.sessionId) return { run, sessions };
  const elapsed = Math.max(0, Math.round(trainedMs(run, now) / 1000));
  if (!completed && elapsed < 5) return { run, sessions };
  const session = { ...logSession(run, completed, now), elapsedSeconds: Math.max(1, elapsed) };
  return { run: { ...run, logged: true, sessionId: session.id }, sessions: [session, ...sessions].slice(0, 500) };
}

function isWorkout(value: unknown): value is Workout {
  if (!value || typeof value !== "object") return false;
  const workout = value as Workout;
  return (
    typeof workout.id === "string" &&
    workout.id.trim().length > 0 &&
    typeof workout.name === "string" &&
    Array.isArray(workout.blocks) &&
    workout.blocks.every((block) => {
      if (!block || typeof block !== "object" || !Array.isArray(block.intervals)) return false;
      return block.intervals.every((interval) => {
        return Boolean(interval && typeof interval === "object" && Number.isFinite(interval.seconds));
      });
    })
  );
}

function isSessionLog(value: unknown): value is SessionLog {
  if (!value || typeof value !== "object") return false;
  const session = value as SessionLog;
  return (
    typeof session.id === "string" &&
    session.id.trim().length > 0 &&
    typeof session.workoutId === "string" &&
    typeof session.workoutName === "string" &&
    (typeof session.category === "string" || session.category == null) &&
    Number.isFinite(session.startedAt) &&
    Number.isFinite(session.endedAt) &&
    typeof session.completed === "boolean" &&
    Number.isFinite(session.elapsedSeconds) &&
    (Number.isFinite(session.plannedSeconds) || session.plannedSeconds == null) &&
    (typeof session.note === "string" || session.note == null) &&
    (session.rpe == null || (Number.isFinite(session.rpe) && session.rpe >= 1 && session.rpe <= 10))
  );
}

function normalizeImportedSettings(value: unknown): Settings {
  const base = defaultSettings();
  if (!value || typeof value !== "object") return base;
  const raw = value as Partial<Settings>;
  const reminders = Array.isArray(raw.reminders)
    ? raw.reminders.filter(
        (item) =>
          item &&
          typeof item.id === "string" &&
          typeof item.label === "string" &&
          Array.isArray(item.days) &&
          item.days.every((day) => Number.isInteger(day) && day >= 0 && day <= 6) &&
          Number.isInteger(item.hour) &&
          item.hour >= 0 &&
          item.hour <= 23 &&
          Number.isInteger(item.minute) &&
          item.minute >= 0 &&
          item.minute <= 59 &&
          typeof item.enabled === "boolean",
      )
    : base.reminders;
  return {
    ...base,
    ...raw,
    theme: THEMES.includes(raw.theme as (typeof THEMES)[number]) ? raw.theme! : base.theme,
    lang: raw.lang === "en" ? "en" : raw.lang === "es" ? "es" : base.lang,
    appIcon: APP_ICONS.includes(raw.appIcon as (typeof APP_ICONS)[number]) ? raw.appIcon! : base.appIcon,
    reminders,
  };
}

function normalizeImportedWorkout(workout: Workout, lang: Lang): Workout {
  const normalized = cloneWorkout(workout, lang);
  return {
    ...normalized,
    id: workout.id,
    builtinId: typeof workout.builtinId === "string" ? workout.builtinId : undefined,
    pristine: Boolean(workout.pristine),
    favorite: Boolean(workout.favorite),
    name: workout.name.trim() || t(lang, "untitled"),
    updatedAt: Number.isFinite(workout.updatedAt) ? workout.updatedAt : Date.now(),
  };
}

function cloneWorkout(workout: Workout, lang: BrasaState["settings"]["lang"]): Workout {
  return {
    ...structuredClone(workout),
    id: uid(),
    builtinId: undefined,
    pristine: false,
    favorite: false,
    name: `${workout.name.trim() || t(lang, "untitled")} ${t(lang, "copySuffix")}`,
    category: typeof workout.category === "string" && workout.category ? workout.category : "hiit",
    description: typeof workout.description === "string" ? workout.description : "",
    updatedAt: Date.now(),
    blocks: workout.blocks.map((block, blockIndex) => ({
      ...block,
      id: uid(),
      name: typeof block.name === "string" && block.name ? block.name : `${t(lang, "blockN")} ${blockIndex + 1}`,
      rounds: Number.isFinite(block.rounds) ? Math.max(1, Math.round(block.rounds)) : 1,
      intervals: block.intervals.map((item) => {
        const kind = item.kind === "rest" || item.kind === "warmup" ? item.kind : "work";
        return {
          ...item,
          id: uid(),
          kind,
          name: typeof item.name === "string" ? item.name : "",
          seconds: Number.isFinite(item.seconds) ? Math.max(0, Math.round(item.seconds)) : 30,
          color: typeof item.color === "string" ? item.color : defaultColor(kind),
          instruction: typeof item.instruction === "string" ? item.instruction : "",
          notes: { ...emptyNotes(), ...(item.notes ?? {}) },
        };
      }),
    })),
  };
}

export const useBrasa = create<BrasaState>()(
  persist(
    (set, get) => ({
      workouts: builtinWorkouts("es"),
      sessions: [],
      settings: defaultSettings(),
      customCategories: [],
      weekPlan: emptyWeek(),
      run: null,
      tasks: [],
      steps: defaultSteps(),
      pomo: defaultPomo(),
      screen: { name: "home" },
      runOrigin: "home",
      editReturn: "library",
      toast: null,
      dirty: false,
      hydrated: false,
      go: (screen) => set({ screen }),
      toastTo: (text) => set({ toast: { id: uid(), text } }),
      clearToast: () => set({ toast: null }),
      setTheme: (theme) => set({ dirty: true, settings: { ...get().settings, theme } }),
      setLang: (lang) =>
        set({
          dirty: true,
          settings: { ...get().settings, lang },
          workouts: get().workouts.map((workout) => relocalize(workout, lang)),
        }),
      patchSettings: (patch) => set({ dirty: true, settings: { ...get().settings, ...patch } }),
      startWorkout: (id) => {
        const workout = get().workouts.find((item) => item.id === id);
        const lang = get().settings.lang;
        if (!workout) return [];
        const steps = flatten(workout);
        if (!steps.length) {
          set({ toast: { id: uid(), text: t(lang, "noSteps") } });
          return [];
        }
        const origin = get().screen.name;
        const built = createRun(workout, steps, get().settings.getReadySeconds, Date.now());
        set({
          dirty: true,
          run: { ...built.run, workoutName: workout.name.trim() || t(lang, "untitled") },
          screen: { name: "run" },
          runOrigin: origin === "library" || origin === "edit" ? origin : "home",
        });
        return built.events;
      },
      quickStart: (kind) => {
        const lang = get().settings.lang;
        const workout = quickWorkout(kind, lang);
        const steps = flatten(workout);
        const built = createRun(workout, steps, get().settings.getReadySeconds, Date.now());
        const rest = get().workouts.filter((item) => item.id !== workout.id);
        set({
          dirty: true,
          workouts: [workout, ...rest],
          run: built.run,
          screen: { name: "run" },
          runOrigin: "home",
        });
        return built.events;
      },
      tickRun: (now) => {
        const run = get().run;
        if (!run || run.phase === "paused" || run.phase === "done") return [];
        const result = tick(run, now, {
          countdown: get().settings.countdown,
          announceNext: get().settings.announceNext,
        });
        let next = result.run;
        let sessions = get().sessions;
        if (next.phase === "done") {
          const settled = withLog(next, sessions, true, now);
          next = settled.run;
          sessions = settled.sessions;
        }
        set({ run: next, sessions, dirty: true });
        return result.events;
      },
      pause: () => {
        const run = get().run;
        if (!run) return;
        set({ dirty: true, run: pauseRun(run, Date.now()) });
      },
      resume: () => {
        const run = get().run;
        if (!run) return;
        set({ dirty: true, run: resumeRun(run, Date.now()) });
      },
      nudgeRun: (deltaMs) => {
        const run = get().run;
        if (!run) return;
        set({ dirty: true, run: nudge(run, deltaMs, Date.now()) });
      },
      jump: (index) => {
        const run = get().run;
        if (!run) return [];
        const now = Date.now();
        const result = jumpTo(run, index, now);
        let next = result.run;
        let sessions = get().sessions;
        if (next.phase === "done") {
          const settled = withLog(next, sessions, true, now);
          next = settled.run;
          sessions = settled.sessions;
        }
        set({ dirty: true, run: next, sessions });
        return result.events;
      },
      next: () => {
        const run = get().run;
        if (!run) return [];
        const now = Date.now();
        const result = skipNext(run, now);
        let next = result.run;
        let sessions = get().sessions;
        if (next.phase === "done") {
          const settled = withLog(next, sessions, true, now);
          next = settled.run;
          sessions = settled.sessions;
        }
        set({ dirty: true, run: next, sessions });
        return result.events;
      },
      prev: () => {
        const run = get().run;
        if (!run) return [];
        const result = skipPrev(run, Date.now());
        set({ dirty: true, run: result.run });
        return result.events;
      },
      leaveRun: () => {
        const origin = get().runOrigin;
        set({ screen: origin === "edit" && get().run ? { name: "edit", id: get().run!.workoutId } : { name: origin === "library" ? "library" : "home" } });
      },
      savePartial: () => {
        const run = get().run;
        if (!run) return "none";
        const now = Date.now();
        const live = run.phase === "paused" || run.phase === "done" ? run : pauseRun(run, now);
        const elapsed = Math.round(trainedMs(live, now) / 1000);
        if (elapsed < 5) {
          set({ run: null, screen: { name: "home" }, dirty: true, toast: { id: uid(), text: t(get().settings.lang, "tooShort") } });
          return "short";
        }
        const settled = withLog({ ...live, phase: "done", completedMs: trainedMs(live, now) }, get().sessions, false, now);
        set({
          dirty: true,
          run: settled.run,
          sessions: settled.sessions,
          screen: { name: "run" },
        });
        return "saved";
      },
      discardRun: () => {
        const { run, sessions } = get();
        const nextSessions = run?.sessionId ? sessions.filter((session) => session.id !== run.sessionId) : sessions;
        set({
          dirty: true,
          run: null,
          sessions: nextSessions,
          screen: { name: "home" },
          toast: { id: uid(), text: t(get().settings.lang, "sessionDropped") },
        });
      },
      updateLog: (patch) => {
        const run = get().run;
        if (!run) return;
        const now = Date.now();
        const settled = run.sessionId
          ? { run, sessions: get().sessions }
          : withLog({ ...run, phase: "done", completedMs: trainedMs(run, now) }, get().sessions, true, now);
        const id = settled.run.sessionId;
        if (!id) return;
        set({
          dirty: true,
          run: settled.run,
          sessions: settled.sessions.map((session) => (session.id === id ? { ...session, ...patch } : session)),
        });
      },
      dismissSummary: () => set({ run: null, screen: { name: "home" }, dirty: true }),
      createWorkout: () => {
        const lang = get().settings.lang;
        const workout: Workout = {
          id: uid(),
          name: t(lang, "newWorkout"),
          category: "hiit",
          description: "",
          favorite: false,
          pristine: false,
          updatedAt: Date.now(),
          blocks: [
            {
              id: uid(),
              name: `${t(lang, "blockN")} 1`,
              rounds: 3,
              intervals: [freshInterval("work", lang)],
            } satisfies Block,
          ],
        };
        set({
          dirty: true,
          workouts: [workout, ...get().workouts],
          screen: { name: "edit", id: workout.id },
          editReturn: get().screen.name === "home" ? "home" : "library",
        });
        return workout.id;
      },
      duplicateWorkout: (id) => {
        const workout = get().workouts.find((item) => item.id === id);
        if (!workout) return null;
        const copy = cloneWorkout(workout, get().settings.lang);
        set({ dirty: true, workouts: [copy, ...get().workouts] });
        return copy.id;
      },
      deleteWorkout: (id) => {
        const screen = get().screen;
        set({
          dirty: true,
          workouts: get().workouts.filter((item) => item.id !== id),
          weekPlan: get().weekPlan.map((slot) => (slot === id ? null : slot)),
          screen: screen.name === "edit" && screen.id === id ? { name: "library" } : screen,
        });
      },
      toggleFavorite: (id) =>
        set({
          dirty: true,
          workouts: get().workouts.map((item) => (item.id === id ? { ...item, favorite: !item.favorite, pristine: item.pristine && item.builtinId ? item.pristine : false, updatedAt: Date.now() } : item)),
        }),
      updateWorkout: (id, updater) =>
        set({
          dirty: true,
          workouts: get().workouts.map((item) => {
            if (item.id !== id) return item;
            const next = updater(item);
            return { ...next, pristine: false, updatedAt: Date.now() };
          }),
        }),
      restoreSamples: () => {
        const lang = get().settings.lang;
        const have = new Set(get().workouts.map((item) => item.builtinId).filter(Boolean));
        const missing = builtinWorkouts(lang).filter((item) => !have.has(item.builtinId));
        set({
          dirty: true,
          workouts: [...missing, ...get().workouts],
          toast: { id: uid(), text: t(lang, "restored") },
        });
      },
      addCategory: (name) => {
        const clean = name.trim();
        if (!clean) return;
        if (get().customCategories.includes(clean)) return;
        set({ dirty: true, customCategories: [...get().customCategories, clean] });
      },
      setWeekSlot: (index, workoutId) => {
        const weekPlan = normalizePlan(get().weekPlan);
        if (index < 0 || index > 6) return;
        weekPlan[index] = workoutId;
        set({ dirty: true, weekPlan });
      },
      deleteSession: (id) => set({ dirty: true, sessions: get().sessions.filter((session) => session.id !== id) }),
      exportBackup: () => ({
        app: "brasa",
        version: 3,
        workouts: get().workouts,
        sessions: get().sessions,
        settings: get().settings,
        customCategories: get().customCategories,
        weekPlan: get().weekPlan,
        tasks: get().tasks,
        steps: get().steps,
        pomo: get().pomo,
      }),
      importBackup: (data) => {
        if (!data || typeof data !== "object") return false;
        const file = data as Partial<Backup>;
        if (file.app !== "brasa" || !Array.isArray(file.workouts) || !file.workouts.every(isWorkout)) return false;
        if (file.version != null && ![1, 2, 3].includes(file.version)) return false;
        if (file.sessions != null && (!Array.isArray(file.sessions) || !file.sessions.every(isSessionLog))) return false;
        const settings = normalizeImportedSettings(file.settings);
        const importedWorkouts = file.workouts.map((workout) => normalizeImportedWorkout(workout, settings.lang));
        const workoutIds = importedWorkouts.map((workout) => workout.id);
        if (new Set(workoutIds).size !== workoutIds.length) return false;
        set({
          dirty: true,
          workouts: importedWorkouts,
          sessions: Array.isArray(file.sessions)
            ? file.sessions.map((session) => ({
                ...session,
                category: typeof session.category === "string" ? session.category : "hiit",
                plannedSeconds: Number.isFinite(session.plannedSeconds) ? session.plannedSeconds : 0,
                note: typeof session.note === "string" ? session.note : "",
                rpe: typeof session.rpe === "number" ? session.rpe : null,
              }))
            : get().sessions,
          settings,
          customCategories: Array.isArray(file.customCategories) ? file.customCategories.filter((item) => typeof item === "string") : get().customCategories,
          weekPlan: normalizePlan((file as { weekPlan?: unknown }).weekPlan ?? get().weekPlan),
          tasks: file.tasks ? normalizeTasks(file.tasks) : get().tasks,
          steps: file.steps ? normalizeSteps(file.steps) : get().steps,
          pomo: file.pomo ? normalizePomo(file.pomo) : get().pomo,
          toast: { id: uid(), text: t(settings.lang, "imported") },
        });
        return true;
      },
      exportWorkout: (id) => get().workouts.find((item) => item.id === id) ?? null,
      importWorkout: (data) => {
        if (!isWorkout(data)) return false;
        const workout = cloneWorkout(data, get().settings.lang);
        workout.name = data.name;
        set({ dirty: true, workouts: [workout, ...get().workouts], toast: { id: uid(), text: t(get().settings.lang, "imported") } });
        return true;
      },
      addStep: () => set({ dirty: true, steps: addStepCount(get().steps, 1) }),
      setStepGoal: (goal) => set({ dirty: true, steps: { ...get().steps, goal: Math.min(100000, Math.max(500, Math.round(goal))) } }),
      setStepTracking: (tracking) => set({ dirty: true, steps: { ...get().steps, tracking, sensor: tracking ? get().steps.sensor : "off" } }),
      addTask: (title) => {
        const clean = title.trim().slice(0, 140);
        if (!clean) return;
        const task: TaskItem = { id: uid(), title: clean, done: false, createdAt: Date.now(), pomodoros: 0 };
        set({ dirty: true, tasks: [task, ...get().tasks].slice(0, 80) });
      },
      toggleTask: (id) =>
        set({
          dirty: true,
          tasks: get().tasks.map((task) => (task.id === id ? { ...task, done: !task.done } : task)),
        }),
      deleteTask: (id) =>
        set({
          dirty: true,
          tasks: get().tasks.filter((task) => task.id !== id),
          pomo: get().pomo.taskId === id ? { ...get().pomo, taskId: null } : get().pomo,
        }),
      selectPomoTask: (id) => set({ dirty: true, pomo: { ...get().pomo, taskId: id } }),
      setPomoLength: (phase, minutes) => set({ dirty: true, pomo: setPomoMinutes(get().pomo, phase, minutes) }),
      choosePomo: (phase) => set({ dirty: true, pomo: choosePhase(get().pomo, phase, Date.now()) }),
      startFocus: () => set({ dirty: true, pomo: startPomo(get().pomo, Date.now()) }),
      pauseFocus: () => set({ dirty: true, pomo: pausePomo(get().pomo, Date.now()) }),
      skipFocus: () => {
        const { state, events } = skipPomo(get().pomo, Date.now());
        set({ dirty: true, pomo: state, tasks: creditTasks(get().tasks, events) });
        return events;
      },
      settlePomo: (now) => {
        const { state, events } = catchUpPomo(get().pomo, now);
        if (!events.length) return events;
        set({ dirty: true, pomo: state, tasks: creditTasks(get().tasks, events) });
        return events;
      },
    }),
    {
      name: "brasa-v1",
      skipHydration: true,
      storage: createJSONStorage(() => (typeof window === "undefined" ? memoryStorage : window.localStorage)),
      partialize: (state) => ({
        workouts: state.workouts,
        sessions: state.sessions,
        settings: state.settings,
        customCategories: state.customCategories,
        weekPlan: state.weekPlan,
        run: state.run,
        tasks: state.tasks,
        steps: state.steps,
        pomo: state.pomo,
      }),
      merge: (persisted, current) => {
        if (current.dirty) return { ...current, hydrated: true };
        const saved = (persisted ?? {}) as Partial<Persisted>;
        return {
          ...current,
          hydrated: true,
          workouts: saved.workouts?.length ? saved.workouts : current.workouts,
          sessions: saved.sessions ?? [],
          settings: { ...current.settings, ...(saved.settings ?? {}) },
          customCategories: saved.customCategories ?? [],
          weekPlan: normalizePlan(saved.weekPlan),
          run: saved.run ?? null,
          tasks: normalizeTasks(saved.tasks),
          steps: normalizeSteps(saved.steps),
          pomo: normalizePomo(saved.pomo),
        };
      },
      onRehydrateStorage: () => () => {
        useBrasa.setState({ hydrated: true });
      },
    },
  ),
);

export function launchWorkout(id: string) {
  const events = useBrasa.getState().startWorkout(id);
  return events;
}

export function launchQuick(kind: QuickKind) {
  return useBrasa.getState().quickStart(kind);
}
