import { announceText, nextText, t, voicePreviewText } from "./i18n";
import type { EngineEvent, RunState, Settings } from "./types";
import type { AmbienceKind } from "./types";

type Snap = { settings: Settings; run: RunState | null };

const VOICE_PROFILE = {
  energetic: { rate: 1.15, pitch: 1.12 },
  calm: { rate: 0.9, pitch: 0.92 },
  minimal: { rate: 1, pitch: 1 },
} satisfies Record<Settings["voiceStyle"], { rate: number; pitch: number }>;

class Bed {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private bedGain: GainNode | null = null;
  private bedKind: AmbienceKind | null = null;
  private bedSources: Array<OscillatorNode | AudioBufferSourceNode> = [];
  private bedExtras: AudioNode[] = [];
  private bedStops: Array<() => void> = [];
  private noise: AudioBuffer | null = null;
  private metro: number | null = null;
  private metroBpm = 0;
  private speaking = false;
  private bedOn = false;
  private speechTimer: number | null = null;
  private previewTimer: number | null = null;

  unlock() {
    const ctx = this.ensure();
    if (ctx.state === "suspended") void ctx.resume().catch(() => undefined);
  }

  private ensure(): AudioContext {
    if (!this.ctx) {
      const ctx = new AudioContext();
      const master = ctx.createGain();
      master.gain.value = 1;
      master.connect(ctx.destination);
      this.ctx = ctx;
      this.master = master;
    }
    return this.ctx;
  }

  beep(pack: Settings["soundPack"], tone: "tick" | "change" | "done", volume: number) {
    const ctx = this.ensure();
    if (ctx.state === "suspended") void ctx.resume().catch(() => undefined);
    const dest = this.master ?? ctx.destination;
    const now = ctx.currentTime;
    const table = {
      bell: { tick: 880, change: 660, done: 523 },
      click: { tick: 1500, change: 980, done: 420 },
      wood: { tick: 390, change: 280, done: 196 },
      soft: { tick: 640, change: 510, done: 380 },
    } as const;
    const play = (freq: number, at: number, dur: number, gain: number) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = pack === "click" ? "square" : pack === "wood" ? "triangle" : "sine";
      osc.frequency.setValueAtTime(freq, at);
      g.gain.setValueAtTime(0.0001, at);
      g.gain.exponentialRampToValueAtTime(Math.max(0.001, gain), at + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
      osc.connect(g);
      g.connect(dest);
      osc.start(at);
      osc.stop(at + dur + 0.02);
    };
    const base = Math.max(0.02, Math.min(1, volume));
    const loud = pack === "click" ? base * 0.12 : base * 0.22;
    play(table[pack][tone], now, tone === "done" ? 0.42 : 0.14, loud);
    if (tone === "done") play(table[pack][tone] * 1.5, now + 0.16, 0.38, loud * 0.8);
  }

  metroClick(volume: number) {
    const ctx = this.ensure();
    if (ctx.state === "suspended") void ctx.resume().catch(() => undefined);
    const dest = this.master ?? ctx.destination;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "square";
    osc.frequency.setValueAtTime(1200, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
    const loud = Math.max(0.2, Math.min(0.7, volume * 0.55));
    g.gain.setValueAtTime(loud, now);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);
    osc.connect(g);
    g.connect(dest);
    osc.start(now);
    osc.stop(now + 0.07);
  }

  speak(text: string, settings: Settings) {
    const native = bridge();
    const { rate, pitch } = VOICE_PROFILE[settings.voiceStyle];
    if (native?.speak?.(text, settings.lang, Math.max(0, Math.min(1, settings.voiceVolume)), rate, pitch)) {
      if (this.speechTimer != null) window.clearTimeout(this.speechTimer);
      this.speaking = true;
      this.applyBed(settings, this.currentRunPhase());
      this.speechTimer = window.setTimeout(() => {
        this.speaking = false;
        this.speechTimer = null;
        this.applyBed(settings, this.currentRunPhase());
      }, Math.min(12000, Math.max(1400, text.length * 75)));
      return;
    }
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = settings.lang === "es" ? "es-ES" : "en-US";
    utter.volume = Math.max(0, Math.min(1, settings.voiceVolume));
    utter.rate = rate;
    utter.pitch = pitch;
    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find((item) => item.lang.toLowerCase().startsWith(settings.lang === "es" ? "es" : "en"));
    if (voice) utter.voice = voice;
    utter.onstart = () => {
      this.speaking = true;
      this.applyBed(settings, this.currentRunPhase());
    };
    utter.onend = () => {
      this.speaking = false;
      this.applyBed(settings, this.currentRunPhase());
    };
    utter.onerror = () => {
      this.speaking = false;
      this.applyBed(settings, this.currentRunPhase());
    };
    native?.stopSpeech?.();
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  }

  isSpeaking() {
    return this.speaking;
  }

  private phase: RunState["phase"] | null = null;

  private currentRunPhase() {
    return this.phase;
  }

  sync(snap: Snap) {
    this.phase = snap.run?.phase ?? null;
    const run = snap.run;
    const settings = snap.settings;
    const working =
      !!run &&
      run.phase === "running" &&
      run.steps[run.index]?.kind === "work" &&
      settings.metronomeBpm > 0 &&
      settings.soundEnabled;
    if (!working) {
      this.stopMetro();
    } else if (this.metroBpm !== settings.metronomeBpm || this.metro == null) {
      this.startMetro(settings);
    }
    const wantBed = !!settings.ambience && !!run && run.phase !== "done";
    if (wantBed) this.startBed(settings, run?.phase ?? null);
    else this.stopBed();
  }

  private startMetro(settings: Settings) {
    this.stopMetro();
    this.metroBpm = settings.metronomeBpm;
    const interval = Math.max(180, Math.round(60000 / settings.metronomeBpm));
    const vol = Math.max(0.4, settings.soundVolume);
    const duck = settings.ducking;
    // Force context alive on the user-gesture path if possible
    const ctx = this.ensure();
    if (ctx.state === "suspended") void ctx.resume().catch(() => undefined);
    const tick = () => {
      if (this.metro == null) return;
      try {
        const c = this.ensure();
        if (c.state === "suspended") void c.resume().catch(() => undefined);
        const gain = vol * (this.speaking && duck ? 0.4 : 1);
        this.metroClick(gain);
        // Native vibration so the user feels the beat even if audio is blocked
        const native = bridge();
        native?.vibrate?.("25");
      } catch { /* ignore */ }
      this.metro = window.setTimeout(tick, interval);
    };
    this.metro = window.setTimeout(tick, 30);
  }

  private stopMetro() {
    if (this.metro != null) window.clearTimeout(this.metro);
    this.metro = null;
    this.metroBpm = 0;
  }

  private noiseBuffer(ctx: AudioContext): AudioBuffer {
    if (this.noise && this.noise.sampleRate === ctx.sampleRate) return this.noise;
    const length = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let brown = 0;
    for (let i = 0; i < length; i += 1) {
      const white = Math.random() * 2 - 1;
      brown = (brown + 0.02 * white) / 1.02;
      data[i] = brown * 3.2;
    }
    this.noise = buffer;
    return buffer;
  }

  private loopNoise(ctx: AudioContext): AudioBufferSourceNode {
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer(ctx);
    src.loop = true;
    src.start();
    this.bedSources.push(src);
    return src;
  }

  private tone(ctx: AudioContext, type: OscillatorType, freq: number): OscillatorNode {
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.value = freq;
    osc.start();
    this.bedSources.push(osc);
    return osc;
  }

  private lfo(ctx: AudioContext, freq: number): OscillatorNode {
    return this.tone(ctx, "sine", freq);
  }

  private disposeBed() {
    for (const stop of this.bedStops) stop();
    this.bedStops = [];
    for (const node of this.bedSources) {
      try {
        node.stop();
      } catch {
        /* already stopped */
      }
      node.disconnect();
    }
    for (const node of this.bedExtras) node.disconnect();
    this.bedSources = [];
    this.bedExtras = [];
    this.bedGain?.disconnect();
    this.bedGain = null;
    this.bedKind = null;
  }

  private buildBed(kind: AmbienceKind) {
    const ctx = this.ensure();
    const gain = ctx.createGain();
    gain.gain.value = 0.0001;
    gain.connect(this.master ?? ctx.destination);
    this.bedGain = gain;
    this.bedKind = kind;

    if (kind === "rain") {
      const hiss = this.loopNoise(ctx);
      const hp = ctx.createBiquadFilter();
      hp.type = "highpass";
      hp.frequency.value = 900;
      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 6400;
      const body = this.loopNoise(ctx);
      const bodyLp = ctx.createBiquadFilter();
      bodyLp.type = "lowpass";
      bodyLp.frequency.value = 240;
      const bodyGain = ctx.createGain();
      bodyGain.gain.value = 0.45;
      hiss.connect(hp);
      hp.connect(lp);
      lp.connect(gain);
      body.connect(bodyLp);
      bodyLp.connect(bodyGain);
      bodyGain.connect(gain);
      this.bedExtras.push(hp, lp, bodyLp, bodyGain);
      return;
    }

    if (kind === "ocean") {
      const src = this.loopNoise(ctx);
      const bp = ctx.createBiquadFilter();
      bp.type = "lowpass";
      bp.frequency.value = 520;
      bp.Q.value = 0.7;
      const amp = ctx.createGain();
      amp.gain.value = 0.62;
      const sway = this.lfo(ctx, 0.18);
      const swayAmt = ctx.createGain();
      swayAmt.gain.value = 260;
      sway.connect(swayAmt);
      swayAmt.connect(bp.frequency);
      const breath = this.lfo(ctx, 0.13);
      const breathAmt = ctx.createGain();
      breathAmt.gain.value = 0.28;
      breath.connect(breathAmt);
      breathAmt.connect(amp.gain);
      src.connect(bp);
      bp.connect(amp);
      amp.connect(gain);
      this.bedExtras.push(bp, amp, swayAmt, breathAmt);
      return;
    }

    if (kind === "ember") {
      const low = this.tone(ctx, "sine", 73);
      const mid = this.tone(ctx, "sine", 110);
      const warm = ctx.createBiquadFilter();
      warm.type = "lowpass";
      warm.frequency.value = 220;
      const warmGain = ctx.createGain();
      warmGain.gain.value = 0.28;
      low.connect(warm);
      mid.connect(warm);
      warm.connect(warmGain);
      warmGain.connect(gain);
      const crack = this.loopNoise(ctx);
      const chp = ctx.createBiquadFilter();
      chp.type = "highpass";
      chp.frequency.value = 1600;
      const crackGain = ctx.createGain();
      crackGain.gain.value = 0.0001;
      crack.connect(chp);
      chp.connect(crackGain);
      crackGain.connect(gain);
      const timer = window.setInterval(() => {
        if (!this.bedOn || !this.ctx) return;
        const now = this.ctx.currentTime;
        const burst = 0.05 + Math.random() * 0.22;
        crackGain.gain.cancelScheduledValues(now);
        crackGain.gain.setValueAtTime(0.0001, now);
        crackGain.gain.linearRampToValueAtTime(burst, now + 0.015);
        crackGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07 + Math.random() * 0.14);
      }, 240);
      this.bedStops.push(() => window.clearInterval(timer));
      this.bedExtras.push(warm, warmGain, chp, crackGain);
      return;
    }

    if (kind === "night") {
      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 740;
      const pad = ctx.createGain();
      pad.gain.value = 0.16;
      for (const freq of [196, 246.94, 293.66]) this.tone(ctx, "sine", freq).connect(lp);
      const air = this.loopNoise(ctx);
      const airHp = ctx.createBiquadFilter();
      airHp.type = "highpass";
      airHp.frequency.value = 2400;
      const airGain = ctx.createGain();
      airGain.gain.value = 0.07;
      const sweep = this.lfo(ctx, 0.05);
      const sweepAmt = ctx.createGain();
      sweepAmt.gain.value = 160;
      sweep.connect(sweepAmt);
      sweepAmt.connect(lp.frequency);
      lp.connect(pad);
      pad.connect(gain);
      air.connect(airHp);
      airHp.connect(airGain);
      airGain.connect(gain);
      this.bedExtras.push(lp, pad, airHp, airGain, sweepAmt);
      return;
    }

    const low = this.tone(ctx, "sine", 196);
    const high = this.tone(ctx, "sine", 311.13);
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 980;
    const pad = ctx.createGain();
    pad.gain.value = 0.22;
    const throb = this.lfo(ctx, 1);
    const depth = ctx.createGain();
    depth.gain.value = 0.1;
    throb.connect(depth);
    depth.connect(pad.gain);
    low.connect(lp);
    high.connect(lp);
    lp.connect(pad);
    pad.connect(gain);
    this.bedExtras.push(lp, pad, depth);
  }

  private startBed(settings: Settings, phase: RunState["phase"] | null) {
    const ctx = this.ensure();
    if (ctx.state === "suspended") void ctx.resume().catch(() => undefined);
    const kind = settings.ambienceKind ?? "rain";
    if (this.bedKind && this.bedKind !== kind) this.disposeBed();
    if (!this.bedGain) this.buildBed(kind);
    this.bedOn = true;
    this.applyBed(settings, phase);
  }

  private applyBed(settings: Settings, phase: RunState["phase"] | null) {
    if (!this.bedGain || !this.ctx) return;
    const base = settings.ambience ? settings.ambienceVolume : 0;
    const paused = phase === "paused" ? 0.35 : 1;
    const duck = this.speaking && settings.ducking ? 0.18 : 1;
    const target = Math.max(0.0001, base * 0.34 * paused * duck);
    this.bedGain.gain.cancelScheduledValues(this.ctx.currentTime);
    this.bedGain.gain.linearRampToValueAtTime(target, this.ctx.currentTime + 0.18);
  }

  private stopBed() {
    if (!this.bedOn && !this.bedGain) return;
    this.bedOn = false;
    if (this.bedGain && this.ctx) {
      this.bedGain.gain.cancelScheduledValues(this.ctx.currentTime);
      this.bedGain.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.22);
    }
  }

  previewAmbience(settings: Settings) {
    if (this.previewTimer != null) window.clearTimeout(this.previewTimer);
    const keep = settings.ambience && this.phase != null && this.phase !== "done";
    this.startBed({ ...settings, ambience: true }, this.currentRunPhase());
    this.previewTimer = window.setTimeout(() => {
      this.previewTimer = null;
      if (!keep) this.stopBed();
    }, 8000);
  }

  stopAll() {
    this.stopMetro();
    this.disposeBed();
    this.bedOn = false;
    if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
    bridge()?.stopSpeech?.();
    if (this.speechTimer != null && typeof window !== "undefined") window.clearTimeout(this.speechTimer);
    this.speechTimer = null;
    if (this.previewTimer != null && typeof window !== "undefined") window.clearTimeout(this.previewTimer);
    this.previewTimer = null;
    this.speaking = false;
  }
}

const bed = new Bed();

type NativeBridge = {
  keepAwake?: (on: boolean) => void;
  vibrate?: (pattern: string) => void;
  notify?: (title: string, body: string) => void;
  speak?: (text: string, language: string, volume: number, rate: number, pitch: number) => boolean;
  stopSpeech?: () => void;
};

function bridge(): NativeBridge | null {
  if (typeof window === "undefined") return null;
  return (window as Window & { BrasaNative?: NativeBridge }).BrasaNative ?? null;
}

export function unlockAudio() {
  if (typeof window === "undefined") return;
  bed.unlock();
}

function vibrate(kind: "tick" | "change" | "done") {
  const pattern = kind === "tick" ? [18] : kind === "change" ? [24, 40, 24] : [30, 50, 30, 50, 90];
  const native = bridge();
  if (native?.vibrate) {
    native.vibrate(pattern.join(","));
    return;
  }
  if (typeof navigator === "undefined" || typeof navigator.vibrate !== "function") return;
  navigator.vibrate(pattern);
}

export function playEvents(events: EngineEvent[], snap: Snap) {
  if (typeof window === "undefined") return;
  const { settings, run } = snap;
  for (const event of events) {
    if (event.type === "beep" && settings.soundEnabled) {
      const speakingSoon =
        settings.voiceEnabled &&
        events.some((item) => item.type === "announce" || item.type === "announceNext");
      const duck = settings.ducking && (bed.isSpeaking() || speakingSoon);
      bed.beep(settings.soundPack, event.tone, settings.soundVolume * (duck ? 0.22 : 1));
    }
    if (event.type === "vibrate" && settings.vibration) vibrate(event.kind);
    if (event.type === "announce" && settings.voiceEnabled && run) {
      const step = run.steps[event.index];
      if (step) bed.speak(announceText(settings.lang, settings.voiceStyle, step), settings);
    }
    if (event.type === "announceNext" && settings.voiceEnabled && settings.announceNext && run) {
      const step = run.steps[event.index];
      if (step) bed.speak(nextText(settings.lang, step), settings);
    }
  }
  bed.sync(snap);
}

export function previewSound(settings: Settings) {
  unlockAudio();
  if (settings.soundEnabled) bed.beep(settings.soundPack, "change", settings.soundVolume);
}

export function chime(settings: Settings, tone: "tick" | "change" | "done" = "done") {
  if (typeof window === "undefined") return;
  unlockAudio();
  if (settings.soundEnabled) bed.beep(settings.soundPack, tone, settings.soundVolume);
  if (settings.vibration) vibrate(tone);
}

export function previewAmbience(settings: Settings) {
  if (typeof window === "undefined") return;
  bed.unlock();
  bed.previewAmbience(settings);
}

export function previewVoice(settings: Settings) {
  unlockAudio();
  bed.speak(voicePreviewText(settings.lang, settings.voiceStyle), settings);
}

export function syncBed(snap: Snap) {
  if (typeof window === "undefined") return;
  bed.sync(snap);
}

export function stopAudio() {
  bed.stopAll();
}

export async function pingNotification(body: string): Promise<"sent" | "denied" | "unavailable"> {
  const native = bridge();
  if (native?.notify) {
    native.notify("Brasa", body);
    return "sent";
  }
  if (typeof window === "undefined" || typeof Notification === "undefined") return "unavailable";
  let permission = Notification.permission;
  if (permission === "default") permission = await Notification.requestPermission();
  if (permission !== "granted") return "denied";
  new Notification("Brasa", { body });
  return "sent";
}

export async function requestWakeLock(): Promise<{ release: () => Promise<unknown> } | null> {
  const native = bridge();
  if (native?.keepAwake) {
    native.keepAwake(true);
    return {
      release: async () => {
        native.keepAwake?.(false);
      },
    };
  }
  try {
    if (!("wakeLock" in navigator)) return null;
    return await navigator.wakeLock.request("screen");
  } catch {
    return null;
  }
}
