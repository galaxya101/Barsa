import assert from "node:assert/strict";
import test from "node:test";
import { addSteps, catchUpPomo, defaultPomo, defaultSteps, rollDay, sampleStep, skipPomo, startPomo, weekSeries } from "./day.ts";

test("steps roll into history on a new day and keep counting", () => {
  const monday = new Date(2026, 10, 16, 9, 0, 0);
  const tuesday = new Date(2026, 10, 17, 8, 0, 0);
  const started = addSteps(defaultSteps(monday), 1200, monday);
  const rolled = rollDay(started, tuesday);
  assert.equal(rolled.today, 0);
  assert.equal(rolled.history.at(-1)?.steps, 1200);
  const walked = addSteps(rolled, 40, tuesday);
  assert.equal(walked.today, 40);
  const week = weekSeries(walked, tuesday);
  assert.equal(week.length, 7);
  assert.equal(week.at(-1)?.steps, 40);
  assert.equal(week.at(-2)?.steps, 1200);
});

test("step peaks need a rise and a gap so noise does not count", () => {
  let peak = { armed: true, lastAt: 0 };
  const first = sampleStep(14, 1_000, peak);
  assert.equal(first.step, true);
  peak = first.peak;
  const bounce = sampleStep(15, 1_100, peak);
  assert.equal(bounce.step, false);
  peak = sampleStep(9, 1_400, bounce.peak).peak;
  const second = sampleStep(13, 1_800, peak);
  assert.equal(second.step, true);
});

test("a finished focus starts the break, and a missed break lands idle", () => {
  const now = 1_000_000;
  const running = startPomo(defaultPomo(), now);
  const mid = catchUpPomo(running, now + 60_000);
  assert.equal(mid.events.length, 0);
  assert.equal(mid.state.phase, "focus");
  const done = catchUpPomo(running, now + 25 * 60 * 1000 + 10);
  assert.equal(done.events[0]?.phase, "focus");
  assert.equal(done.state.phase, "short");
  assert.equal(done.state.status, "running");
  const away = catchUpPomo(running, now + 40 * 60 * 1000);
  assert.equal(away.state.phase, "focus");
  assert.equal(away.state.status, "idle");
  assert.equal(away.events.length, 2);
});

test("the fourth focus opens the long break", () => {
  let state = { ...defaultPomo(), cycle: 3 };
  state = startPomo(state, 0);
  const done = catchUpPomo(state, 25 * 60 * 1000 + 5);
  assert.equal(done.state.phase, "long");
  assert.equal(done.state.cycle, 0);
});

test("the long break keeps its configured length and returns to focus", () => {
  const longMin = 12;
  const started = startPomo({ ...defaultPomo(), cycle: 3, longMin }, 0);
  const focused = catchUpPomo(started, 25 * 60 * 1000 + 10);
  assert.equal(focused.state.phase, "long");
  assert.equal(focused.state.remainingMs, longMin * 60 * 1000 - 10);
  assert.equal(focused.state.status, "running");

  const rested = catchUpPomo(focused.state, focused.state.endsAt!);
  assert.equal(rested.state.phase, "focus");
  assert.equal(rested.state.status, "idle");
  assert.equal(rested.state.cycle, 0);
});

test("skip from idle focus moves to the break without starting the clock", () => {
  const skipped = skipPomo(defaultPomo(), 50);
  assert.equal(skipped.state.phase, "short");
  assert.equal(skipped.state.status, "idle");
  assert.equal(skipped.events.length, 1);
});
