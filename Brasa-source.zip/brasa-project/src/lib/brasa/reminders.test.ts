import assert from "node:assert/strict";
import test from "node:test";
import { resolveReminderLabel } from "./reminders.ts";

test("uses the custom reminder text after trimming whitespace", () => {
  assert.equal(resolveReminderLabel("  Beber agua  ", "Hora de entrenar"), "Beber agua");
});

test("uses the localized default when the reminder text is empty", () => {
  assert.equal(resolveReminderLabel("   ", "Hora de entrenar"), "Hora de entrenar");
});
