import assert from "node:assert/strict";
import test from "node:test";
import { appIconLabel, voicePreviewText } from "./i18n.ts";

test("launcher name follows the selected icon and app language", () => {
  assert.equal(appIconLabel("es", "orbit"), "Órbita");
  assert.equal(appIconLabel("en", "orbit"), "Orbit");
});

test("voice preview phrases reflect each selected style", () => {
  const energetic = voicePreviewText("es", "energetic");
  const calm = voicePreviewText("es", "calm");
  const minimal = voicePreviewText("es", "minimal");
  assert.notEqual(energetic, calm);
  assert.notEqual(calm, minimal);
  assert.equal(minimal, "Correr");
});
