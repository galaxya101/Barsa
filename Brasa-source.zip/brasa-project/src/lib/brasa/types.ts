export type Lang = "es" | "en";
export type ThemeId = "carbon" | "dawn" | "tide" | "bone";
export type AppIconId = "ember" | "anvil" | "split" | "pulse" | "orbit" | "stamp";
export type SoundPack = "bell" | "click" | "wood" | "soft";
export type AmbienceKind = "rain" | "ocean" | "ember" | "night" | "pulse";
export type VoiceStyle = "energetic" | "calm" | "minimal";
export type IntervalKind = "work" | "rest" | "warmup";
export type ColorKey = "ember" | "copper" | "gold" | "sage" | "tide" | "rose" | "lime" | "slate";
export type CategoryId = "hiit" | "strength" | "cardio" | "boxing" | "core" | "mobility";
export type QuickKind = "tabata" | "emom" | "ladder" | "core" | "pyramid" | "shadow";

export type Notes = {
  speed: string;
  incline: string;
  resistance: string;
  difficulty: string;
  custom: string;
};

export type Interval = {
  id: string;
  kind: IntervalKind;
  name: string;
  seconds: number;
  color: ColorKey;
  instruction: string;
  notes: Notes;
};

export type Block = {
  id: string;
  name: string;
  rounds: number;
  intervals: Interval[];
};

export type Workout = {
  id: string;
  builtinId?: string;
  pristine?: boolean;
  name: string;
  category: string;
  description: string;
  favorite: boolean;
  blocks: Block[];
  updatedAt: number;
};

export type Step = {
  key: string;
  blockName: string;
  round: number;
  rounds: number;
  kind: IntervalKind;
  name: string;
  seconds: number;
  color: ColorKey;
  instruction: string;
  notes: Notes;
  firstOfRound: boolean;
};

export type SessionLog = {
  id: string;
  workoutId: string;
  workoutName: string;
  category: string;
  startedAt: number;
  endedAt: number;
  completed: boolean;
  elapsedSeconds: number;
  plannedSeconds: number;
  note: string;
  rpe: number | null;
};

export type Reminder = {
  id: string;
  label: string;
  days: number[];
  hour: number;
  minute: number;
  enabled: boolean;
};

export type Settings = {
  theme: ThemeId;
  lang: Lang;
  appIcon: AppIconId;
  largeText: boolean;
  soundEnabled: boolean;
  soundPack: SoundPack;
  soundVolume: number;
  voiceEnabled: boolean;
  voiceVolume: number;
  voiceStyle: VoiceStyle;
  ducking: boolean;
  ambience: boolean;
  ambienceKind: AmbienceKind;
  ambienceVolume: number;
  vibration: boolean;
  keepAwake: boolean;
  countdown: boolean;
  announceNext: boolean;
  getReadySeconds: number;
  metronomeBpm: number;
  dailyGoalMinutes: number;
  weeklyGoalSessions: number;
  reminders: Reminder[];
};

export type RunPhase = "ready" | "running" | "paused" | "done";

export type RunState = {
  workoutId: string;
  workoutName: string;
  category: string;
  steps: Step[];
  index: number;
  phase: RunPhase;
  pausedFrom: "ready" | "running" | null;
  remainingMs: number;
  segmentDurationMs: number;
  segmentEndsAt: number | null;
  startedAt: number;
  completedMs: number;
  logged: boolean;
  sessionId: string | null;
  lastWarn: number | null;
  announcedNext: boolean;
};

export type EngineEvent =
  | { type: "beep"; tone: "tick" | "change" | "done" }
  | { type: "vibrate"; kind: "tick" | "change" | "done" }
  | { type: "announce"; index: number }
  | { type: "announceNext"; index: number }
  | { type: "complete" };

export type Screen =
  | { name: "home" }
  | { name: "library" }
  | { name: "edit"; id: string }
  | { name: "run" }
  | { name: "stats" }
  | { name: "settings" }
  | { name: "steps" }
  | { name: "focus" };

export type ScreenName = Screen["name"];

export const COLOR_KEYS: ColorKey[] = ["ember", "copper", "gold", "sage", "tide", "rose", "lime", "slate"];
export const APP_ICONS: AppIconId[] = ["ember", "anvil", "split", "pulse", "orbit", "stamp"];
export const THEMES: ThemeId[] = ["carbon", "dawn", "tide", "bone"];
export const CATEGORIES: CategoryId[] = ["hiit", "strength", "cardio", "boxing", "core", "mobility"];

export const THEME_HEX: Record<ThemeId, { canvas: string; accent: string }> = {
  carbon: { canvas: "#000000", accent: "#ff7a3c" },
  dawn: { canvas: "#f2f2f7", accent: "#ff5a1f" },
  tide: { canvas: "#000000", accent: "#64d2ff" },
  bone: { canvas: "#f2f2f7", accent: "#ff6b3d" },
};

export function emptyNotes(): Notes {
  return { speed: "", incline: "", resistance: "", difficulty: "", custom: "" };
}

export function defaultColor(kind: IntervalKind): ColorKey {
  if (kind === "rest") return "tide";
  if (kind === "warmup") return "gold";
  return "ember";
}
