import { cn } from "@/lib/utils";
import type { AppIconId } from "./types";

function Glyph({ id }: { id: AppIconId }) {
  if (id === "ember") {
    return (
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M24 9c.4 4.2-2.2 7.2-4.2 10.2-1.5 2.2-2.6 4.4-2.6 7.1 0 3.7 2.9 6.7 6.8 6.7s6.8-3 6.8-6.7c0-2.7-1.1-4.9-2.6-7.1C26.2 16.2 23.6 13.2 24 9Zm0 10.2c1.2 1.8 2.6 3 2.6 4.8a2.6 2.6 0 0 1-5.2 0c0-1.8 1.4-3 2.6-4.8Z"
      />
    );
  }
  if (id === "anvil") {
    return <path fill="currentColor" d="M9 16h30v5H31v3h5v4H27v6h-6v-6H12v-4h5v-3H9v-5Z" />;
  }
  if (id === "split") {
    return (
      <path
        fill="currentColor"
        d="M14 13h8.2L16.4 24l5.8 11H14l-6-11 6-11Zm12.2 0H34l6 11-6 11h-7.8l5.8-11-5.8-11Z"
      />
    );
  }
  if (id === "pulse") {
    return (
      <g fill="currentColor">
        <rect x="8" y="22" width="5" height="12" rx="1.5" />
        <rect x="16.5" y="12" width="5" height="22" rx="1.5" />
        <rect x="25" y="17" width="5" height="17" rx="1.5" />
        <rect x="33.5" y="20" width="5" height="14" rx="1.5" />
      </g>
    );
  }
  if (id === "orbit") {
    return (
      <g fill="none" stroke="currentColor" strokeWidth="4">
        <circle cx="24" cy="24" r="10" />
        <circle cx="35" cy="15" r="3.2" fill="currentColor" stroke="none" />
      </g>
    );
  }
  return (
    <g fill="none" stroke="currentColor" strokeWidth="3.5">
      <rect x="12" y="12" width="24" height="24" rx="4" />
      <path d="M17 31 31 17" strokeLinecap="round" />
      <circle cx="24" cy="24" r="2.4" fill="currentColor" stroke="none" />
    </g>
  );
}

export function AppMark({ id, className }: { id: AppIconId; className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("text-accent drop-shadow-md", className)} aria-hidden="true">
      <defs>
        <linearGradient id="glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="white" stopOpacity="0.35" />
          <stop offset="45%" stopColor="white" stopOpacity="0.05" />
          <stop offset="100%" stopColor="black" stopOpacity="0.08" />
        </linearGradient>
      </defs>
      <rect width="48" height="48" rx="16" className="fill-raised" />
      <rect width="48" height="48" rx="16" fill="url(#glass)" />
      <Glyph id={id} />
    </svg>
  );
}

export function faviconSvg(id: AppIconId, accent = "#e4572e", tile = "#1c1915"): string {
  const glyph =
    id === "ember"
      ? `<path fill="${accent}" d="M24 9c.4 4.2-2.2 7.2-4.2 10.2-1.5 2.2-2.6 4.4-2.6 7.1 0 3.7 2.9 6.7 6.8 6.7s6.8-3 6.8-6.7c0-2.7-1.1-4.9-2.6-7.1C26.2 16.2 23.6 13.2 24 9Z"/>`
      : id === "anvil"
        ? `<path fill="${accent}" d="M9 16h30v5H31v3h5v4H27v6h-6v-6H12v-4h5v-3H9v-5Z"/>`
        : id === "split"
          ? `<path fill="${accent}" d="M14 13h8.2L16.4 24l5.8 11H14l-6-11 6-11Zm12.2 0H34l6 11-6 11h-7.8l5.8-11-5.8-11Z"/>`
          : id === "pulse"
            ? `<g fill="${accent}"><rect x="8" y="22" width="5" height="12" rx="1.5"/><rect x="16.5" y="12" width="5" height="22" rx="1.5"/><rect x="25" y="17" width="5" height="17" rx="1.5"/><rect x="33.5" y="20" width="5" height="14" rx="1.5"/></g>`
            : id === "orbit"
              ? `<circle cx="24" cy="24" r="10" fill="none" stroke="${accent}" stroke-width="4"/><circle cx="35" cy="15" r="3.2" fill="${accent}"/>`
              : `<rect x="12" y="12" width="24" height="24" rx="4" fill="none" stroke="${accent}" stroke-width="3.5"/><path d="M17 31 31 17" stroke="${accent}" stroke-width="3.5" stroke-linecap="round"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" rx="14" fill="${tile}"/>${glyph}</svg>`;
}
