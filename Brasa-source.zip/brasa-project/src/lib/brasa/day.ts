export type PomoPhase = "focus" | "short" | "long";
export type PomoStatus = "idle" | "running" | "paused";

export type PomodoroState = {
  phase: PomoPhase;
  status: PomoStatus;
  focusMin: number;
  shortMin: number;
  longMin: number;
  cycle: number;
  endsAt: number | null;
  remainingMs: number;
  taskId: string | null;
};

export type TaskItem = {
  id: string;
  title: string;
  done: boolean;
  createdAt: number;
  pomodoros: number;
};

export type StepDay = { date: string; steps: number };

export type SensorMode = "off" | "waiting" | "motion" | "hardware" | "denied" | "none";

export type StepsState = {
  goal: number;
  today: number;
  date: string;
  history: StepDay[];
  tracking: boolean;
  sensor: SensorMode;
};

export type PomoEvent = {
  phase: PomoPhase;
  taskId: string | null;
  next: PomoPhase;
};

export type Peak = { armed: boolean; lastAt: number };

const FOCUS_CAP = 90;
const SHORT_CAP = 30;
const LONG_CAP = 45;

export function dayKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function defaultSteps(now = new Date()): StepsState {
  return { goal: 8000, today: 0, date: dayKey(now), history: [], tracking: false, sensor: "off" };
}

export function defaultPomo(): PomodoroState {
  return {
    phase: "focus",
    status: "idle",
    focusMin: 25,
    shortMin: 5,
    longMin: 15,
    cycle: 0,
    endsAt: null,
    remainingMs: 25 * 60 * 1000,
    taskId: null,
  };
}

export function clampMin(phase: PomoPhase, value: number): number {
  const cap = phase === "focus" ? FOCUS_CAP : phase === "short" ? SHORT_CAP : LONG_CAP;
  if (!Number.isFinite(value)) return phase === "focus" ? 25 : phase === "short" ? 5 : 15;
  return Math.min(cap, Math.max(1, Math.round(value)));
}

export function phaseMs(state: PomodoroState, phase: PomoPhase = state.phase): number {
  const min = phase === "focus" ? state.focusMin : phase === "short" ? state.shortMin : state.longMin;
  return clampMin(phase, min) * 60 * 1000;
}

export function rollDay(state: StepsState, now = new Date()): StepsState {
  const date = dayKey(now);
  if (state.date === date) return state;
  const history = [...state.history.filter((item) => item.date !== state.date && item.date !== date), { date: state.date, steps: state.today }].slice(-21);
  return { ...state, date, today: 0, history };
}

export function addSteps(state: StepsState, count: number, now = new Date()): StepsState {
  const rolled = rollDay(state, now);
  const next = Math.max(0, rolled.today + Math.max(0, Math.round(count)));
  return { ...rolled, today: next };
}

export function applyHardwareSteps(state: StepsState, steps: number, date: string, now = new Date()): StepsState {
  const rolled = rollDay(state, now);
  if (date !== rolled.date) return { ...rolled, sensor: "hardware" };
  return { ...rolled, today: Math.max(0, Math.round(steps)), sensor: "hardware" };
}

export function weekSeries(state: StepsState, now = new Date()): { date: string; steps: number }[] {
  const rolled = rollDay(state, now);
  const map = new Map(rolled.history.map((item) => [item.date, item.steps]));
  map.set(rolled.date, rolled.today);
  const out: { date: string; steps: number }[] = [];
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = new Date(now.getFullYear(), now.getMonth(), now.getDate() - offset, 12, 0, 0, 0);
    const key = dayKey(date);
    out.push({ date: key, steps: map.get(key) ?? 0 });
  }
  return out;
}

export function sampleStep(mag: number, now: number, peak: Peak): { peak: Peak; step: boolean } {
  const high = 12;
  const low = 10;
  if (!Number.isFinite(mag)) return { peak, step: false };
  if (mag > high && peak.armed && now - peak.lastAt >= 320) {
    return { peak: { armed: false, lastAt: now }, step: true };
  }
  if (mag < low) return { peak: { ...peak, armed: true }, step: false };
  return { peak, step: false };
}

function armPhase(state: PomodoroState, phase: PomoPhase, now: number, status: PomoStatus): PomodoroState {
  const ms = phaseMs(state, phase);
  if (status === "running") return { ...state, phase, status, remainingMs: ms, endsAt: now + ms };
  return { ...state, phase, status, remainingMs: ms, endsAt: null };
}

export function setPomoMinutes(state: PomodoroState, phase: PomoPhase, minutes: number): PomodoroState {
  const next = { ...state };
  const value = clampMin(phase, minutes);
  if (phase === "focus") next.focusMin = value;
  if (phase === "short") next.shortMin = value;
  if (phase === "long") next.longMin = value;
  if (next.status === "idle" && next.phase === phase) next.remainingMs = phaseMs(next, phase);
  return next;
}

export function choosePhase(state: PomodoroState, phase: PomoPhase, now: number): PomodoroState {
  if (state.status === "running") return state;
  return armPhase(state, phase, now, "idle");
}

export function startPomo(state: PomodoroState, now: number): PomodoroState {
  if (state.status === "running") return state;
  if (state.status === "paused" && state.remainingMs > 0) {
    return { ...state, status: "running", endsAt: now + state.remainingMs };
  }
  return armPhase(state, state.phase, now, "running");
}

export function pausePomo(state: PomodoroState, now: number): PomodoroState {
  if (state.status !== "running" || state.endsAt == null) return state;
  return { ...state, status: "paused", remainingMs: Math.max(0, state.endsAt - now), endsAt: null };
}

export function catchUpPomo(state: PomodoroState, now: number): { state: PomodoroState; events: PomoEvent[] } {
  if (state.status !== "running" || state.endsAt == null) return { state, events: [] };
  if (now < state.endsAt) {
    const remainingMs = state.endsAt - now;
    if (remainingMs === state.remainingMs) return { state, events: [] };
    return { state: { ...state, remainingMs }, events: [] };
  }
  const events: PomoEvent[] = [];
  const endedAt = state.endsAt;
  if (state.phase === "focus") {
    const cycle = (state.cycle + 1) % 4;
    const next: PomoPhase = cycle === 0 ? "long" : "short";
    events.push({ phase: "focus", taskId: state.taskId, next });
    const breakMs = phaseMs(state, next);
    const breakEnds = endedAt + breakMs;
    if (now < breakEnds) {
      return {
        state: { ...state, phase: next, cycle, status: "running", endsAt: breakEnds, remainingMs: breakEnds - now },
        events,
      };
    }
    events.push({ phase: next, taskId: null, next: "focus" });
    return {
      state: { ...state, phase: "focus", cycle, status: "idle", endsAt: null, remainingMs: phaseMs(state, "focus") },
      events,
    };
  }
  events.push({ phase: state.phase, taskId: null, next: "focus" });
  return {
    state: { ...state, phase: "focus", status: "idle", endsAt: null, remainingMs: phaseMs(state, "focus") },
    events,
  };
}

export function skipPomo(state: PomodoroState, now: number): { state: PomodoroState; events: PomoEvent[] } {
  if (state.status === "idle") {
    const next: PomoPhase = state.phase === "focus" ? ((state.cycle + 1) % 4 === 0 ? "long" : "short") : "focus";
    const cycle = state.phase === "focus" ? (state.cycle + 1) % 4 : state.cycle;
    const events: PomoEvent[] = state.phase === "focus" ? [{ phase: "focus", taskId: state.taskId, next }] : [];
    return { state: armPhase({ ...state, cycle }, next, now, "idle"), events };
  }
  const running = state.status === "paused" ? { ...state, status: "running" as const, endsAt: now - 1 } : { ...state, endsAt: now - 1 };
  return catchUpPomo(running, now);
}

export function creditTasks(tasks: TaskItem[], events: PomoEvent[]): TaskItem[] {
  let next = tasks;
  for (const event of events) {
    if (event.phase !== "focus" || !event.taskId) continue;
    next = next.map((task) => (task.id === event.taskId ? { ...task, pomodoros: task.pomodoros + 1 } : task));
  }
  return next;
}

export function normalizeTasks(value: unknown): TaskItem[] {
  if (!Array.isArray(value)) return [];
  const tasks: TaskItem[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const task = item as Partial<TaskItem>;
    if (typeof task.id !== "string" || typeof task.title !== "string") continue;
    const title = task.title.trim();
    if (!title) continue;
    tasks.push({
      id: task.id,
      title: title.slice(0, 140),
      done: Boolean(task.done),
      createdAt: typeof task.createdAt === "number" ? task.createdAt : Date.now(),
      pomodoros: typeof task.pomodoros === "number" && task.pomodoros > 0 ? Math.round(task.pomodoros) : 0,
    });
  }
  return tasks.slice(0, 80);
}

export function normalizeSteps(value: unknown, now = new Date()): StepsState {
  const base = defaultSteps(now);
  if (!value || typeof value !== "object") return base;
  const raw = value as Partial<StepsState>;
  const history = Array.isArray(raw.history)
    ? raw.history
        .filter((item): item is StepDay => Boolean(item) && typeof item.date === "string" && typeof item.steps === "number")
        .map((item) => ({ date: item.date, steps: Math.max(0, Math.round(item.steps)) }))
        .slice(-21)
    : [];
  return rollDay(
    {
      ...base,
      goal: typeof raw.goal === "number" && raw.goal > 0 ? Math.min(100000, Math.round(raw.goal)) : base.goal,
      today: typeof raw.today === "number" && raw.today > 0 ? Math.round(raw.today) : 0,
      date: typeof raw.date === "string" ? raw.date : base.date,
      history,
      tracking: Boolean(raw.tracking),
      sensor: "off",
    },
    now,
  );
}

export function normalizePomo(value: unknown): PomodoroState {
  const base = defaultPomo();
  if (!value || typeof value !== "object") return base;
  const raw = value as Partial<PomodoroState>;
  const phase: PomoPhase = raw.phase === "short" || raw.phase === "long" || raw.phase === "focus" ? raw.phase : "focus";
  const status: PomoStatus = raw.status === "running" || raw.status === "paused" || raw.status === "idle" ? raw.status : "idle";
  const next: PomodoroState = {
    ...base,
    phase,
    status,
    focusMin: clampMin("focus", typeof raw.focusMin === "number" ? raw.focusMin : base.focusMin),
    shortMin: clampMin("short", typeof raw.shortMin === "number" ? raw.shortMin : base.shortMin),
    longMin: clampMin("long", typeof raw.longMin === "number" ? raw.longMin : base.longMin),
    cycle: typeof raw.cycle === "number" ? Math.min(3, Math.max(0, Math.round(raw.cycle))) : 0,
    endsAt: typeof raw.endsAt === "number" ? raw.endsAt : null,
    remainingMs: typeof raw.remainingMs === "number" && raw.remainingMs > 0 ? raw.remainingMs : phaseMs(base, phase),
    taskId: typeof raw.taskId === "string" ? raw.taskId : null,
  };
  if (next.status !== "running") next.endsAt = null;
  return next;
}
