import { applyHardwareSteps, sampleStep, type Peak, type SensorMode } from "./day";
import { brasaNative } from "./native";
import { useBrasa } from "./store";

type AccelerometerLike = {
  x: number;
  y: number;
  z: number;
  start: () => void;
  stop: () => void;
  addEventListener: (type: "reading", listener: () => void) => void;
};

type HardwareSnap = {
  active?: boolean;
  steps?: number;
  date?: string;
  source?: string;
  permission?: string;
};

let audio: AudioContext | null = null;
let oscillator: OscillatorNode | null = null;

function holdAudio(on: boolean) {
  if (!on) {
    oscillator?.stop();
    oscillator = null;
    void audio?.close().catch(() => undefined);
    audio = null;
    return;
  }
  if (audio) return;
  const Ctx = window.AudioContext || (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  const ctx = new Ctx();
  const gain = ctx.createGain();
  gain.gain.value = 0.0008;
  const osc = ctx.createOscillator();
  osc.frequency.value = 28;
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  audio = ctx;
  oscillator = osc;
  void ctx.resume().catch(() => undefined);
}

function setSensor(sensor: SensorMode) {
  const current = useBrasa.getState().steps.sensor;
  if (current !== sensor) useBrasa.setState({ steps: { ...useBrasa.getState().steps, sensor } });
}

function readHardware(): HardwareSnap | null {
  const native = brasaNative();
  if (!native?.stepSnapshot) return null;
  try {
    const parsed = JSON.parse(native.stepSnapshot()) as HardwareSnap;
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

function applySnap(snap: HardwareSnap) {
  if (typeof snap.steps !== "number" || typeof snap.date !== "string") return;
  const current = useBrasa.getState().steps;
  const next = applyHardwareSteps(current, snap.steps, snap.date);
  if (next.today === current.today && next.date === current.date && current.sensor === "hardware" && current.tracking) return;
  useBrasa.setState({ dirty: true, steps: { ...next, tracking: true, sensor: "hardware" } });
}

function watchMotion(onStep: () => void): () => void {
  let peak: Peak = { armed: true, lastAt: 0 };
  let stopped = false;
  let acc: AccelerometerLike | null = null;
  const take = (x: number, y: number, z: number) => {
    if (stopped) return;
    const result = sampleStep(Math.hypot(x, y, z), Date.now(), peak);
    peak = result.peak;
    if (!result.step) return;
    if (useBrasa.getState().steps.sensor !== "motion") setSensor("motion");
    onStep();
  };
  const onMotion = (event: DeviceMotionEvent) => {
    const reading = event.accelerationIncludingGravity;
    if (!reading || reading.x == null || reading.y == null || reading.z == null) return;
    take(reading.x, reading.y, reading.z);
  };
  const start = () => {
    const Ctor = (window as Window & { Accelerometer?: new (opts: { frequency: number }) => AccelerometerLike }).Accelerometer;
    if (typeof Ctor === "function") {
      try {
        acc = new Ctor({ frequency: 20 });
        acc.addEventListener("reading", () => {
          if (acc) take(acc.x, acc.y, acc.z);
        });
        acc.start();
        setSensor("waiting");
        holdAudio(true);
        return;
      } catch {
        acc = null;
      }
    }
    if (typeof window.DeviceMotionEvent === "undefined") {
      setSensor("none");
      return;
    }
    window.addEventListener("devicemotion", onMotion);
    setSensor("waiting");
    holdAudio(true);
  };
  start();
  return () => {
    stopped = true;
    acc?.stop();
    window.removeEventListener("devicemotion", onMotion);
    holdAudio(false);
  };
}

export async function enableStepSensor(): Promise<SensorMode> {
  const native = brasaNative();
  if (native?.startStepTracking) {
    const goal = useBrasa.getState().steps.goal;
    const unit = useBrasa.getState().settings.lang === "es" ? "pasos" : "steps";
    native.startStepTracking(goal, unit);
    const snap = readHardware();
    if (snap?.permission === "denied") {
      useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "denied" } });
      return "denied";
    }
    if (snap?.permission === "missing") {
      useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "none" } });
      return "none";
    }
    if (snap && typeof snap.steps === "number" && typeof snap.date === "string") applySnap(snap);
    useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: true, sensor: "hardware" } });
    return "hardware";
  }
  const request = (DeviceMotionEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission;
  if (typeof request === "function") {
    try {
      const result = await request();
      if (result !== "granted") {
        useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "denied" } });
        return "denied";
      }
    } catch {
      useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "denied" } });
      return "denied";
    }
  }
  if (typeof window.DeviceMotionEvent === "undefined" && typeof (window as Window & { Accelerometer?: unknown }).Accelerometer === "undefined") {
    useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "none" } });
    return "none";
  }
  useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: true, sensor: "waiting" } });
  if (typeof Notification !== "undefined" && Notification.permission === "default") {
    void Notification.requestPermission().catch(() => undefined);
  }
  return "waiting";
}

export function disableStepSensor() {
  brasaNative()?.stopStepTracking?.();
  holdAudio(false);
  useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "off" } });
}

export function bindStepSensor(): () => void {
  const native = brasaNative();
  if (native?.stepSnapshot) {
    const goal = useBrasa.getState().steps.goal;
    const unit = useBrasa.getState().settings.lang === "es" ? "pasos" : "steps";
    native.startStepTracking?.(goal, unit);
    const pull = () => {
      const snap = readHardware();
      if (!snap) return;
      if (snap.permission === "denied") {
        useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "denied" } });
        return;
      }
      if (snap.permission === "missing") {
        useBrasa.setState({ dirty: true, steps: { ...useBrasa.getState().steps, tracking: false, sensor: "none" } });
        return;
      }
      if (typeof snap.steps === "number" && typeof snap.date === "string") applySnap(snap);
    };
    pull();
    const id = window.setInterval(pull, 2000);
    const onVis = () => {
      if (document.visibilityState === "visible") pull();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pageshow", pull);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pageshow", pull);
    };
  }
  let lastNote = 0;
  const stop = watchMotion(() => {
    useBrasa.getState().addStep();
    const { steps, settings } = useBrasa.getState();
    if (document.visibilityState === "visible") return;
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const now = Date.now();
    if (now - lastNote < 20000) return;
    lastNote = now;
    const body = settings.lang === "es" ? `${steps.today} pasos hoy` : `${steps.today} steps today`;
    try {
      new Notification("Brasa", { body, tag: "brasa-steps", silent: true });
    } catch {
      /* notification already showing */
    }
  });
  return stop;
}
