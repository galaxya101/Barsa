import assert from "node:assert/strict";
import test from "node:test";
import { bests, categoryMinutes, createRun, flatten, formatClock, recentDays, skipNext, streaks, tick, trainedMs, weekSeconds } from "./engine.ts";
import { builtinWorkouts } from "./samples.ts";

test("mobility sample has no rest and ladder changes duration", () => {
  const mob = builtinWorkouts("es").find((workout) => workout.builtinId === "mob");
  assert.ok(mob);
  const steps = flatten(mob);
  assert.equal(steps.length, 4);
  assert.equal(steps.every((step) => step.kind !== "rest"), true);
  const ladder = builtinWorkouts("es").find((workout) => workout.builtinId === "ladder");
  assert.ok(ladder);
  const durations = flatten(ladder).map((step) => step.seconds);
  assert.deepEqual(durations, [20, 30, 40, 50, 25, 40, 30, 20]);
});

test("rounds multiply and the clock formats", () => {
  const tabata = builtinWorkouts("en").find((workout) => workout.builtinId === "tabata");
  assert.ok(tabata);
  const steps = flatten(tabata);
  assert.equal(steps.length, 16);
  assert.equal(steps[2].round, 2);
  assert.equal(formatClock(20_000), "00:20");
  assert.equal(formatClock(3_600_000), "1:00:00");
});

test("tick advances on the wall clock and can catch up", () => {
  const workout = builtinWorkouts("es")[0];
  const steps = flatten(workout).slice(0, 3);
  const started = createRun({ ...workout, blocks: workout.blocks }, steps, 0, 1_000);
  assert.equal(started.run.phase, "running");
  const first = tick(started.run, 1_000 + 19_000, { countdown: true, announceNext: false });
  assert.equal(first.run.index, 0);
  assert.equal(first.events.some((event) => event.type === "beep"), true);
  const crossed = tick(started.run, 1_000 + 20_000, { countdown: false, announceNext: false });
  assert.equal(crossed.run.index, 1);
  assert.equal(crossed.run.phase, "running");
  const landed = tick(started.run, 1_000 + 20_000 + 10_000 + 5_000, { countdown: false, announceNext: false });
  assert.equal(landed.run.index, 2);
  assert.ok(trainedMs(landed.run, 1_000 + 35_000) >= 30_000);
});

test("skip finishes the last step and streaks count today", () => {
  const workout = builtinWorkouts("es")[0];
  const steps = flatten(workout).slice(0, 1);
  const started = createRun(workout, steps, 0, 5_000);
  const done = skipNext(started.run, 6_000);
  assert.equal(done.run.phase, "done");
  const now = Date.now();
  const score = streaks(
    [
      { endedAt: now - 86_400_000, elapsedSeconds: 60 },
      { endedAt: now, elapsedSeconds: 60 },
    ],
    now,
  );
  assert.equal(score.current, 2);
});

test("records, categories and a 28-day series stay stable", () => {
  const now = Date.UTC(2026, 5, 10, 12);
  const sessions = [
    { id: "a", workoutId: "w", workoutName: "Tabata", category: "hiit", startedAt: now, endedAt: now, completed: true, elapsedSeconds: 120, plannedSeconds: 120, note: "", rpe: null },
    { id: "b", workoutId: "w", workoutName: "Core", category: "core", startedAt: now - 86_400_000, endedAt: now - 86_400_000, completed: false, elapsedSeconds: 60, plannedSeconds: 90, note: "", rpe: null },
  ];
  const marks = bests(sessions);
  assert.equal(marks.longest?.workoutName, "Tabata");
  assert.equal(marks.bestDaySeconds, 120);
  assert.equal(marks.completion, 0.5);
  assert.equal(categoryMinutes(sessions)[0]?.category, "hiit");
  assert.equal(recentDays(sessions, 28, now).length, 28);
  assert.equal(weekSeconds([], now), 0);
});
