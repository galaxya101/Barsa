export function resolveReminderLabel(label: string, fallback: string): string {
  return label.trim() || fallback;
}
