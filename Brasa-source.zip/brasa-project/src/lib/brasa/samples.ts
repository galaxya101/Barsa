function uid(): string {
  return crypto.randomUUID();
}
import type { Block, Interval, IntervalKind, Lang, Notes, QuickKind, Workout } from "./types.ts";
import { emptyNotes } from "./types.ts";

function notes(partial: Partial<Notes> = {}): Notes {
  return { ...emptyNotes(), ...partial };
}

function interval(
  id: string,
  partial: Omit<Interval, "id" | "notes"> & { notes?: Partial<Notes> },
): Interval {
  return {
    id,
    kind: partial.kind,
    name: partial.name,
    seconds: partial.seconds,
    color: partial.color,
    instruction: partial.instruction,
    notes: notes(partial.notes),
  };
}

function block(id: string, name: string, rounds: number, intervals: Interval[]): Block {
  return { id, name, rounds, intervals };
}

const copy = {
  es: {
    tabataName: "Tabata clásico",
    tabataDesc: "Ocho rondas de veinte y diez. Sin adornos.",
    effort: "Esfuerzo máximo",
    effortCue: "Ritmo que no podrías conversar.",
    rest: "Descanso",
    breathe: "Respira por la nariz si puedes.",
    fullName: "Circuito completo",
    fullDesc: "Calientas y luego tres vueltas de fuerza. Descanso solo entre ejercicios.",
    mobility: "Movilidad",
    joints: "Articulaciones",
    jointsCue: "Círculos lentos. Sin dolor.",
    activation: "Activación",
    circuit: "Circuito",
    squat: "Sentadilla",
    squatCue: "Talón pegado al suelo.",
    push: "Flexiones",
    pushCue: "Cuerpo en una pieza.",
    row: "Remo de mochila",
    rowCue: "Codo hacia la cadera.",
    emomName: "EMOM 12",
    emomDesc: "Cuarenta segundos de trabajo. El resto cierra el minuto.",
    minute: "Trabajo del minuto",
    close: "Cierra el minuto",
    boxName: "Asaltos",
    boxDesc: "Cuerda corta y seis rounds de tres minutos.",
    rope: "Comba suave",
    round: "Asalto",
    corner: "Esquina",
    guard: "Guardia alta, pies vivos.",
    mobName: "Movilidad continua",
    mobDesc: "Una sola serie, sin descanso obligatorio.",
    cat: "Gato-camello",
    hip: "Apertura de cadera",
    tspine: "Torácica",
    breath: "Respiración",
    coreName: "Core seguido",
    coreDesc: "Tres ejercicios pegados y un descanso al final de la vuelta.",
    crunch: "Encogimiento",
    plank: "Plancha",
    bike: "Bicicleta",
    plankCue: "Empuja el suelo. No hundas la lumbar.",
    ladName: "Escalera",
    ladDesc: "Sube y baja la duración, sin descanso entre picos.",
    peak: "Pico",
    quickTabata: "Tabata rápido",
    quickEmom: "EMOM rápido",
    quickLadder: "Escalera rápida",
    quickCore: "Core rápido",
    quickPyramid: "Pirámide rápida",
    quickShadow: "Sombra rápida",
    shadowWork: "Sombra",
    shadowBreath: "Respiro",
    hiitBlock: "Tabata",
    work: "Trabajo",
  },
  en: {
    tabataName: "Classic Tabata",
    tabataDesc: "Eight rounds of twenty and ten. Nothing extra.",
    effort: "Max effort",
    effortCue: "A pace you could not talk through.",
    rest: "Rest",
    breathe: "Nasal breath if you can.",
    fullName: "Full circuit",
    fullDesc: "Warm up, then three strength laps. Rest only between moves.",
    mobility: "Mobility",
    joints: "Joints",
    jointsCue: "Slow circles. No pain.",
    activation: "Activation",
    circuit: "Circuit",
    squat: "Squat",
    squatCue: "Heels stay down.",
    push: "Push-ups",
    pushCue: "One long line.",
    row: "Backpack row",
    rowCue: "Elbow toward the hip.",
    emomName: "EMOM 12",
    emomDesc: "Forty seconds of work. The rest closes the minute.",
    minute: "Minute work",
    close: "Close the minute",
    boxName: "Rounds",
    boxDesc: "A short rope, then six three-minute rounds.",
    rope: "Easy rope",
    round: "Round",
    corner: "Corner",
    guard: "Hands high, feet alive.",
    mobName: "Unbroken mobility",
    mobDesc: "One sequence. No mandatory rest.",
    cat: "Cat-camel",
    hip: "Hip opener",
    tspine: "T-spine",
    breath: "Breathing",
    coreName: "Straight core",
    coreDesc: "Three moves back to back, then rest at the end of the lap.",
    crunch: "Curl-up",
    plank: "Plank",
    bike: "Bicycle",
    plankCue: "Push the floor. Don't dump the low back.",
    ladName: "Ladder",
    ladDesc: "Duration climbs and comes back down, with no rest between peaks.",
    peak: "Peak",
    quickTabata: "Quick Tabata",
    quickEmom: "Quick EMOM",
    quickLadder: "Quick ladder",
    quickCore: "Quick core",
    quickPyramid: "Quick pyramid",
    quickShadow: "Quick shadow",
    shadowWork: "Shadow",
    shadowBreath: "Breath",
    hiitBlock: "Tabata",
    work: "Work",
  },
} as const;

function stamp(workout: Omit<Workout, "updatedAt" | "favorite" | "pristine"> & { favorite?: boolean }): Workout {
  return { ...workout, favorite: workout.favorite ?? false, pristine: true, updatedAt: 1 };
}

export function builtinWorkouts(lang: Lang): Workout[] {
  const c = copy[lang];
  return [
    stamp({
      id: "builtin-tabata",
      builtinId: "tabata",
      name: c.tabataName,
      category: "hiit",
      description: c.tabataDesc,
      favorite: true,
      blocks: [
        block("tabata-b", c.hiitBlock, 8, [
          interval("tabata-w", { kind: "work", name: c.effort, seconds: 20, color: "ember", instruction: c.effortCue, notes: { difficulty: "9" } }),
          interval("tabata-r", { kind: "rest", name: c.rest, seconds: 10, color: "tide", instruction: c.breathe }),
        ]),
      ],
    }),
    stamp({
      id: "builtin-full",
      builtinId: "full",
      name: c.fullName,
      category: "strength",
      description: c.fullDesc,
      blocks: [
        block("full-w", c.mobility, 1, [
          interval("full-j", { kind: "warmup", name: c.joints, seconds: 45, color: "gold", instruction: c.jointsCue }),
          interval("full-a", { kind: "warmup", name: c.activation, seconds: 30, color: "gold", instruction: "" }),
        ]),
        block("full-c", c.circuit, 3, [
          interval("full-s", { kind: "work", name: c.squat, seconds: 40, color: "ember", instruction: c.squatCue, notes: { speed: "controlled", resistance: "bodyweight", difficulty: "6" } }),
          interval("full-sr", { kind: "rest", name: c.rest, seconds: 20, color: "tide", instruction: "" }),
          interval("full-p", { kind: "work", name: c.push, seconds: 40, color: "copper", instruction: c.pushCue, notes: { difficulty: "7" } }),
          interval("full-pr", { kind: "rest", name: c.rest, seconds: 20, color: "tide", instruction: "" }),
          interval("full-r", { kind: "work", name: c.row, seconds: 40, color: "rose", instruction: c.rowCue, notes: { resistance: "backpack", difficulty: "6" } }),
          interval("full-rr", { kind: "rest", name: c.rest, seconds: 20, color: "tide", instruction: "" }),
        ]),
      ],
    }),
    stamp({
      id: "builtin-emom",
      builtinId: "emom",
      name: c.emomName,
      category: "cardio",
      description: c.emomDesc,
      blocks: [
        block("emom-b", "EMOM", 12, [
          interval("emom-w", { kind: "work", name: c.minute, seconds: 40, color: "ember", instruction: c.effortCue, notes: { difficulty: "7" } }),
          interval("emom-r", { kind: "rest", name: c.close, seconds: 20, color: "tide", instruction: "" }),
        ]),
      ],
    }),
    stamp({
      id: "builtin-box",
      builtinId: "box",
      name: c.boxName,
      category: "boxing",
      description: c.boxDesc,
      blocks: [
        block("box-w", c.mobility, 1, [interval("box-rope", { kind: "warmup", name: c.rope, seconds: 90, color: "gold", instruction: "" })]),
        block("box-r", c.round, 6, [
          interval("box-work", { kind: "work", name: c.round, seconds: 180, color: "rose", instruction: c.guard, notes: { difficulty: "8" } }),
          interval("box-rest", { kind: "rest", name: c.corner, seconds: 60, color: "tide", instruction: c.breathe }),
        ]),
      ],
    }),
    stamp({
      id: "builtin-mob",
      builtinId: "mob",
      name: c.mobName,
      category: "mobility",
      description: c.mobDesc,
      blocks: [
        block("mob-b", c.mobility, 1, [
          interval("mob-1", { kind: "warmup", name: c.cat, seconds: 40, color: "gold", instruction: "" }),
          interval("mob-2", { kind: "warmup", name: c.hip, seconds: 40, color: "sage", instruction: "" }),
          interval("mob-3", { kind: "warmup", name: c.tspine, seconds: 40, color: "lime", instruction: "" }),
          interval("mob-4", { kind: "warmup", name: c.breath, seconds: 50, color: "tide", instruction: c.breathe }),
        ]),
      ],
    }),
    stamp({
      id: "builtin-core",
      builtinId: "core",
      name: c.coreName,
      category: "core",
      description: c.coreDesc,
      blocks: [
        block("core-b", "Core", 4, [
          interval("core-1", { kind: "work", name: c.crunch, seconds: 30, color: "ember", instruction: "" }),
          interval("core-2", { kind: "work", name: c.plank, seconds: 30, color: "copper", instruction: c.plankCue, notes: { difficulty: "6" } }),
          interval("core-3", { kind: "work", name: c.bike, seconds: 30, color: "rose", instruction: "" }),
          interval("core-4", { kind: "rest", name: c.rest, seconds: 20, color: "tide", instruction: "" }),
        ]),
      ],
    }),
    stamp({
      id: "builtin-ladder",
      builtinId: "ladder",
      name: c.ladName,
      category: "hiit",
      description: c.ladDesc,
      blocks: [
        block("lad-b", c.ladName, 1, [
          interval("lad-1", { kind: "work", name: `${c.peak} 20`, seconds: 20, color: "ember", instruction: "" }),
          interval("lad-2", { kind: "work", name: `${c.peak} 30`, seconds: 30, color: "copper", instruction: "" }),
          interval("lad-3", { kind: "work", name: `${c.peak} 40`, seconds: 40, color: "rose", instruction: "" }),
          interval("lad-4", { kind: "work", name: `${c.peak} 50`, seconds: 50, color: "gold", instruction: "", notes: { difficulty: "8" } }),
          interval("lad-r", { kind: "rest", name: c.rest, seconds: 25, color: "tide", instruction: "" }),
          interval("lad-5", { kind: "work", name: `${c.peak} 40`, seconds: 40, color: "rose", instruction: "" }),
          interval("lad-6", { kind: "work", name: `${c.peak} 30`, seconds: 30, color: "copper", instruction: "" }),
          interval("lad-7", { kind: "work", name: `${c.peak} 20`, seconds: 20, color: "ember", instruction: "" }),
        ]),
      ],
    }),
  ];
}

export function relocalize(workout: Workout, lang: Lang): Workout {
  if (!workout.builtinId || !workout.pristine) return workout;
  const fresh = builtinWorkouts(lang).find((item) => item.builtinId === workout.builtinId);
  if (!fresh) return workout;
  return { ...fresh, id: workout.id, favorite: workout.favorite, pristine: true };
}

export function quickWorkout(kind: QuickKind, lang: Lang): Workout {
  const c = copy[lang];
  const base = { pristine: false, favorite: false, updatedAt: Date.now(), description: "" };
  if (kind === "tabata") {
    return {
      ...base,
      id: "quick-tabata",
      name: c.quickTabata,
      category: "hiit",
      blocks: [
        block("q-tabata", c.hiitBlock, 8, [
          interval("q-tabata-w", { kind: "work", name: c.effort, seconds: 20, color: "ember", instruction: c.effortCue }),
          interval("q-tabata-r", { kind: "rest", name: c.rest, seconds: 10, color: "tide", instruction: "" }),
        ]),
      ],
    };
  }
  if (kind === "emom") {
    return {
      ...base,
      id: "quick-emom",
      name: c.quickEmom,
      category: "cardio",
      blocks: [
        block("emom-b", "EMOM", 10, [
          interval("q-emom-w", { kind: "work", name: c.minute, seconds: 40, color: "ember", instruction: "" }),
          interval("q-emom-r", { kind: "rest", name: c.close, seconds: 20, color: "tide", instruction: "" }),
        ]),
      ],
    };
  }
  if (kind === "ladder") {
    return {
      ...base,
      id: "quick-ladder",
      name: c.quickLadder,
      category: "hiit",
      blocks: [
        block(
          "q-lad",
          c.ladName,
          1,
          [20, 30, 40, 30, 20].map((seconds, index) =>
            interval(`q-lad-${index}`, {
              kind: "work",
              name: `${c.peak} ${seconds}`,
              seconds,
              color: index % 2 ? "copper" : "ember",
              instruction: "",
            }),
          ),
        ),
      ],
    };
  }
  if (kind === "pyramid") {
    return {
      ...base,
      id: "quick-pyramid",
      name: c.quickPyramid,
      category: "hiit",
      blocks: [
        block(
          "q-pyr",
          c.ladName,
          1,
          [20, 40, 60, 40, 20].map((seconds, index) =>
            interval(`q-pyr-${index}`, {
              kind: "work",
              name: `${c.peak} ${seconds}`,
              seconds,
              color: index === 2 ? "gold" : index % 2 ? "copper" : "ember",
              instruction: "",
            }),
          ),
        ),
      ],
    };
  }
  if (kind === "shadow") {
    return {
      ...base,
      id: "quick-shadow",
      name: c.quickShadow,
      category: "boxing",
      blocks: [
        block("q-sh", c.round, 4, [
          interval("q-sh-w", { kind: "work", name: c.shadowWork, seconds: 40, color: "rose", instruction: c.guard }),
          interval("q-sh-r", { kind: "rest", name: c.shadowBreath, seconds: 20, color: "tide", instruction: "" }),
        ]),
      ],
    };
  }
  return {
    ...base,
    id: "quick-core",
    name: c.quickCore,
    category: "core",
    blocks: [
      block("q-core", "Core", 3, [
        interval("q-core-1", { kind: "work", name: c.crunch, seconds: 30, color: "ember", instruction: "" }),
        interval("q-core-2", { kind: "work", name: c.plank, seconds: 30, color: "copper", instruction: c.plankCue }),
        interval("q-core-3", { kind: "work", name: c.bike, seconds: 30, color: "rose", instruction: "" }),
      ]),
    ],
  };
}

export function freshInterval(kind: IntervalKind, lang: Lang): Interval {
  const c = copy[lang];
  const name = kind === "rest" ? c.rest : kind === "warmup" ? c.activation : c.work;
  return interval(uid(), {
    kind,
    name,
    seconds: kind === "rest" ? 20 : 40,
    color: kind === "rest" ? "tide" : kind === "warmup" ? "gold" : "ember",
    instruction: "",
  });
}
