import { playEvents, previewSound, previewVoice, stopAudio, syncBed, unlockAudio } from "./audio";
import type { EngineEvent, QuickKind } from "./types";
import { useBrasa } from "./store";

function audible(events: EngineEvent[]) {
  const snap = useBrasa.getState();
  playEvents(events, { settings: snap.settings, run: snap.run });
  syncBed({ settings: snap.settings, run: snap.run });
}

export function beginWorkout(id: string) {
  unlockAudio();
  stopAudio();
  audible(useBrasa.getState().startWorkout(id));
}

export function beginQuick(kind: QuickKind) {
  unlockAudio();
  stopAudio();
  audible(useBrasa.getState().quickStart(kind));
}

export function hear(events: EngineEvent[]) {
  unlockAudio();
  audible(events);
}

export { previewSound, previewVoice };
