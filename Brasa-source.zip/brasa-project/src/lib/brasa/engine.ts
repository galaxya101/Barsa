import type { EngineEvent, RunState, SessionLog, Step, Workout } from "./types.ts";

export function flatten(workout: Workout): Step[] {
  const steps: Step[] = [];
  for (const block of workout.blocks) {
    const rounds = Math.max(1, Math.floor(block.rounds) || 1);
    const intervals = block.intervals.filter((item) => item.seconds > 0);
    if (!intervals.length) continue;
    for (let round = 1; round <= rounds; round += 1) {
      intervals.forEach((item, idx) => {
        steps.push({
          key: `${block.id}:${round}:${item.id}`,
          blockName: block.name,
          round,
          rounds,
          kind: item.kind,
          name: item.name,
          seconds: item.seconds,
          color: item.color,
          instruction: item.instruction,
          notes: item.notes,
          firstOfRound: idx === 0,
        });
      });
    }
  }
  return steps;
}

export function plannedSeconds(steps: Step[]): number {
  return steps.reduce((sum, step) => sum + step.seconds, 0);
}

export function formatClock(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  const mm = String(minutes).padStart(2, "0");
  const ss = String(seconds).padStart(2, "0");
  if (hours > 0) return `${hours}:${mm}:${ss}`;
  return `${mm}:${ss}`;
}

export function formatSpan(seconds: number): string {
  const safe = Math.max(0, Math.round(seconds));
  if (safe < 60) return `${safe} s`;
  const hours = Math.floor(safe / 3600);
  const minutes = Math.round((safe % 3600) / 60);
  if (hours <= 0) return `${minutes} min`;
  if (minutes <= 0) return `${hours} h`;
  return `${hours} h ${minutes} min`;
}

export function createRun(workout: Workout, steps: Step[], readySeconds: number, now: number): { run: RunState; events: EngineEvent[] } {
  const ready = Math.max(0, Math.floor(readySeconds));
  const first = steps[0];
  const duration = (ready > 0 ? ready : first.seconds) * 1000;
  const run: RunState = {
    workoutId: workout.id,
    workoutName: workout.name.trim() || workout.name,
    category: workout.category,
    steps,
    index: 0,
    phase: ready > 0 ? "ready" : "running",
    pausedFrom: null,
    remainingMs: duration,
    segmentDurationMs: duration,
    segmentEndsAt: now + duration,
    startedAt: now,
    completedMs: 0,
    logged: false,
    sessionId: null,
    lastWarn: null,
    announcedNext: false,
  };
  const events: EngineEvent[] = [{ type: "vibrate", kind: "change" }];
  if (ready === 0) events.unshift({ type: "announce", index: 0 });
  return { run, events };
}

function liveRemaining(run: RunState, now: number): number {
  if (run.segmentEndsAt == null) return Math.max(0, run.remainingMs);
  return Math.max(0, run.segmentEndsAt - now);
}

export function trainedMs(run: RunState, now: number): number {
  if (run.phase === "done") return run.completedMs;
  const active = run.phase === "paused" ? run.pausedFrom : run.phase;
  if (active !== "running") return run.completedMs;
  const rem = liveRemaining(run, now);
  const elapsed = Math.min(run.segmentDurationMs, Math.max(0, run.segmentDurationMs - rem));
  return run.completedMs + elapsed;
}

function arm(run: RunState, index: number, durationMs: number, at: number, announce: boolean, completedMs: number): { run: RunState; events: EngineEvent[] } {
  const events: EngineEvent[] = [];
  if (announce) events.push({ type: "announce", index });
  events.push({ type: "beep", tone: "change" }, { type: "vibrate", kind: "change" });
  return {
    run: {
      ...run,
      index,
      phase: "running",
      pausedFrom: null,
      remainingMs: durationMs,
      segmentDurationMs: durationMs,
      segmentEndsAt: at + durationMs,
      completedMs,
      lastWarn: null,
      announcedNext: false,
    },
    events,
  };
}

function advance(run: RunState, endTime: number, announce: boolean): { run: RunState; events: EngineEvent[] } {
  if (run.phase === "ready") {
    const duration = run.steps[0].seconds * 1000;
    const armed = arm(run, 0, duration, endTime, announce, run.completedMs);
    return armed;
  }
  const completedMs = run.completedMs + run.segmentDurationMs;
  const next = run.index + 1;
  if (next >= run.steps.length) {
    return {
      run: {
        ...run,
        completedMs,
        phase: "done",
        pausedFrom: null,
        remainingMs: 0,
        segmentEndsAt: null,
        lastWarn: null,
        announcedNext: false,
      },
      events: [
        { type: "complete" },
        { type: "beep", tone: "done" },
        { type: "vibrate", kind: "done" },
      ],
    };
  }
  return arm(run, next, run.steps[next].seconds * 1000, endTime, announce, completedMs);
}

export function tick(
  run: RunState,
  now: number,
  opts: { countdown: boolean; announceNext: boolean },
): { run: RunState; events: EngineEvent[] } {
  if (run.phase === "paused" || run.phase === "done" || run.segmentEndsAt == null) {
    return { run, events: [] };
  }
  let current = run;
  const events: EngineEvent[] = [];
  let crossed = 0;
  let guard = 0;
  while (guard < 800) {
    guard += 1;
    const end = current.segmentEndsAt;
    if (end == null || current.phase === "done") break;
    const remaining = end - now;
    if (remaining > 0) {
      const sec = Math.ceil(remaining / 1000);
      let lastWarn = current.lastWarn;
      let announcedNext = current.announcedNext;
      if (opts.countdown && sec >= 1 && sec <= 3 && sec !== lastWarn) {
        events.push({ type: "beep", tone: "tick" }, { type: "vibrate", kind: "tick" });
        lastWarn = sec;
      }
      const longEnough = current.segmentDurationMs >= 12_000;
      if (
        current.phase === "running" &&
        opts.announceNext &&
        !announcedNext &&
        longEnough &&
        remaining <= 5000 &&
        current.index + 1 < current.steps.length
      ) {
        events.push({ type: "announceNext", index: current.index + 1 });
        announcedNext = true;
      }
      current = { ...current, remainingMs: remaining, lastWarn, announcedNext };
      break;
    }
    const behind = now - end > 900;
    const quiet = behind || crossed > 0;
    const stepped = advance(current, end, !quiet);
    events.push(...stepped.events);
    current = stepped.run;
    crossed += 1;
  }
  if (crossed > 1) {
    const kept: EngineEvent[] = [];
    const announce = [...events].reverse().find((event) => event.type === "announce");
    if (current.phase === "running" && announce) kept.push(announce);
    if (events.some((event) => event.type === "complete")) {
      kept.push({ type: "complete" }, { type: "beep", tone: "done" }, { type: "vibrate", kind: "done" });
    } else if (current.phase === "running") {
      kept.push({ type: "beep", tone: "change" });
    }
    return { run: current, events: kept };
  }
  return { run: current, events };
}

export function pauseRun(run: RunState, now: number): RunState {
  if (run.phase !== "running" && run.phase !== "ready") return run;
  return {
    ...run,
    phase: "paused",
    pausedFrom: run.phase,
    remainingMs: liveRemaining(run, now),
    segmentEndsAt: null,
  };
}

export function resumeRun(run: RunState, now: number): RunState {
  if (run.phase !== "paused" || !run.pausedFrom) return run;
  return {
    ...run,
    phase: run.pausedFrom,
    pausedFrom: null,
    segmentEndsAt: now + Math.max(0, run.remainingMs),
  };
}

export function nudge(run: RunState, deltaMs: number, now: number): RunState {
  if (run.phase === "done") return run;
  const rem = liveRemaining(run, now);
  const next = Math.min(60 * 60 * 1000, Math.max(1000, rem + deltaMs));
  const diff = next - rem;
  return {
    ...run,
    remainingMs: next,
    segmentDurationMs: Math.max(1000, run.segmentDurationMs + diff),
    segmentEndsAt: run.phase === "paused" || run.segmentEndsAt == null ? null : now + next,
  };
}

export function jumpTo(run: RunState, index: number, now: number): { run: RunState; events: EngineEvent[] } {
  if (!run.steps.length) return { run, events: [] };
  const clamped = Math.max(0, Math.min(run.steps.length - 1, index));
  const active = run.phase === "paused" ? run.pausedFrom : run.phase;
  const completedMs = active === "running" ? trainedMs(run, now) : run.completedMs;
  return arm({ ...run, phase: "running" }, clamped, run.steps[clamped].seconds * 1000, now, true, completedMs);
}

export function skipNext(run: RunState, now: number): { run: RunState; events: EngineEvent[] } {
  if (run.phase === "ready" || (run.phase === "paused" && run.pausedFrom === "ready")) {
    return jumpTo({ ...run, phase: "running", pausedFrom: null, completedMs: run.completedMs }, 0, now);
  }
  if (run.index >= run.steps.length - 1) {
    const completedMs = trainedMs(run, now);
    return {
      run: {
        ...run,
        completedMs,
        phase: "done",
        pausedFrom: null,
        remainingMs: 0,
        segmentEndsAt: null,
      },
      events: [
        { type: "complete" },
        { type: "beep", tone: "done" },
        { type: "vibrate", kind: "done" },
      ],
    };
  }
  return jumpTo(run, run.index + 1, now);
}

export function skipPrev(run: RunState, now: number): { run: RunState; events: EngineEvent[] } {
  if (run.phase === "ready") return jumpTo(run, 0, now);
  const target = run.index <= 0 ? 0 : run.index - 1;
  return jumpTo(run, target, now);
}

export function dayKey(ts: number): string {
  const date = new Date(ts);
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export function dayStart(ts: number): number {
  const date = new Date(ts);
  date.setHours(0, 0, 0, 0);
  return date.getTime();
}

export function streaks(sessions: Pick<SessionLog, "endedAt" | "elapsedSeconds">[], now = Date.now()): { current: number; best: number } {
  const days = new Set<number>();
  for (const session of sessions) {
    if (session.elapsedSeconds < 20) continue;
    days.add(dayStart(session.endedAt));
  }
  const sorted = [...days].sort((a, b) => a - b);
  let best = 0;
  let run = 0;
  let prev: number | null = null;
  for (const day of sorted) {
    if (prev != null && day - prev === 86_400_000) run += 1;
    else run = 1;
    prev = day;
    if (run > best) best = run;
  }
  const today = dayStart(now);
  const cursorStart = days.has(today) ? today : today - 86_400_000;
  let current = 0;
  if (days.has(cursorStart)) {
    let cursor = cursorStart;
    while (days.has(cursor)) {
      current += 1;
      cursor -= 86_400_000;
    }
  }
  return { current, best };
}

export function sumOnDay(sessions: SessionLog[], now = Date.now()): number {
  const key = dayKey(now);
  return sessions.filter((session) => dayKey(session.endedAt) === key).reduce((sum, session) => sum + session.elapsedSeconds, 0);
}

export function weekBounds(now = Date.now()): { start: number; end: number } {
  const date = new Date(now);
  const mondayOffset = (date.getDay() + 6) % 7;
  const startDate = new Date(date);
  startDate.setHours(0, 0, 0, 0);
  startDate.setDate(startDate.getDate() - mondayOffset);
  return { start: startDate.getTime(), end: startDate.getTime() + 7 * 86_400_000 };
}

export function sessionsThisWeek(sessions: SessionLog[], now = Date.now()): SessionLog[] {
  const { start, end } = weekBounds(now);
  return sessions.filter((session) => session.endedAt >= start && session.endedAt < end && session.elapsedSeconds >= 20);
}

export function last7Days(sessions: SessionLog[], now = Date.now()): { label: string; minutes: number; key: string }[] {
  return recentDays(sessions, 7, now);
}

export function recentDays(sessions: SessionLog[], days: number, now = Date.now()): { label: string; minutes: number; key: string }[] {
  const count = Math.max(1, Math.min(42, Math.floor(days) || 7));
  const start = dayStart(now) - (count - 1) * 86_400_000;
  const buckets: { label: string; minutes: number; key: string }[] = [];
  for (let i = 0; i < count; i += 1) {
    const ts = start + i * 86_400_000;
    const key = dayKey(ts);
    const label = count > 10 ? String(new Date(ts).getDate()) : new Date(ts).toLocaleDateString(undefined, { weekday: "narrow" });
    const seconds = sessions.filter((session) => dayKey(session.endedAt) === key).reduce((sum, session) => sum + session.elapsedSeconds, 0);
    buckets.push({ key, label, minutes: Math.round(seconds / 60) });
  }
  return buckets;
}

export function weekSeconds(sessions: SessionLog[], now = Date.now(), offsetWeeks = 0): number {
  const { start } = weekBounds(now);
  const from = start + offsetWeeks * 7 * 86_400_000;
  const to = from + 7 * 86_400_000;
  return sessions
    .filter((session) => session.endedAt >= from && session.endedAt < to)
    .reduce((sum, session) => sum + session.elapsedSeconds, 0);
}

export function categoryMinutes(sessions: SessionLog[]): { category: string; minutes: number }[] {
  const totals = new Map<string, number>();
  for (const session of sessions) {
    const key = session.category || "hiit";
    totals.set(key, (totals.get(key) ?? 0) + session.elapsedSeconds);
  }
  return [...totals.entries()]
    .map(([category, seconds]) => ({ category, minutes: Math.round(seconds / 60) }))
    .sort((a, b) => b.minutes - a.minutes);
}

export function bests(sessions: SessionLog[]): { longest: SessionLog | null; bestDaySeconds: number; completion: number } {
  let longest: SessionLog | null = null;
  const days = new Map<string, number>();
  let done = 0;
  for (const session of sessions) {
    if (!longest || session.elapsedSeconds > longest.elapsedSeconds) longest = session;
    if (session.completed) done += 1;
    const key = dayKey(session.endedAt);
    days.set(key, (days.get(key) ?? 0) + session.elapsedSeconds);
  }
  let bestDaySeconds = 0;
  for (const seconds of days.values()) if (seconds > bestDaySeconds) bestDaySeconds = seconds;
  return { longest, bestDaySeconds, completion: sessions.length ? done / sessions.length : 0 };
}

export function cueSecond(run: RunState | null, countdown: boolean): number | null {
  if (!run || !countdown) return null;
  if (run.phase !== "running" && run.phase !== "ready") return null;
  if (run.remainingMs <= 0 || run.remainingMs > 3200) return null;
  const sec = Math.ceil(run.remainingMs / 1000);
  return sec >= 1 && sec <= 3 ? sec : null;
}
