import { useEffect, useState } from "react";
import { Flame, Footprints, Play, RotateCcw, Timer } from "lucide-react";
import { AppMark } from "@/lib/brasa/icons";
import { beginQuick, beginWorkout } from "@/lib/brasa/launch";
import { flatten, formatSpan, sessionsThisWeek, streaks, sumOnDay } from "@/lib/brasa/engine";
import { categoryLabel, greeting } from "@/lib/brasa/i18n";
import { useBrasa } from "@/lib/brasa/store";
import type { QuickKind } from "@/lib/brasa/types";
import { cn } from "@/lib/utils";
import { Modal, PrimaryButton, Ring, useI18n, useMounted } from "./ui";

const QUICK: QuickKind[] = ["tabata", "emom", "pyramid", "shadow", "ladder", "core"];
const DAY_KEYS = ["day1", "day2", "day3", "day4", "day5", "day6", "day0"] as const;

export function Home() {
  const { t, lang } = useI18n();
  const mounted = useMounted();
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    if (mounted) setNow(new Date());
  }, [mounted]);
  const icon = useBrasa((state) => state.settings.appIcon);
  const workouts = useBrasa((state) => state.workouts);
  const sessions = useBrasa((state) => state.sessions);
  const settings = useBrasa((state) => state.settings);
  const run = useBrasa((state) => state.run);
  const weekPlan = useBrasa((state) => state.weekPlan);
  const stepsToday = useBrasa((state) => state.steps.today);
  const pomo = useBrasa((state) => state.pomo);
  const openTasks = useBrasa((state) => state.tasks.filter((task) => !task.done).length);
  const setWeekSlot = useBrasa((state) => state.setWeekSlot);
  const go = useBrasa((state) => state.go);
  const resume = useBrasa((state) => state.resume);
  const [planDay, setPlanDay] = useState<number | null>(null);

  const todayIndex = now ? (now.getDay() + 6) % 7 : -1;
  const planned = todayIndex >= 0 ? workouts.find((item) => item.id === weekPlan[todayIndex]) : undefined;
  const hero = (run ? workouts.find((item) => item.id === run.workoutId) : null) ?? planned ?? workouts.find((item) => item.favorite) ?? workouts[0];
  const steps = hero ? flatten(hero) : [];
  const blocks = hero?.blocks.length ?? 0;
  const roundCount = hero?.blocks.reduce((sum, block) => sum + block.rounds, 0) ?? 0;
  const streak = mounted ? streaks(sessions) : { current: 0, best: 0 };
  const todaySeconds = mounted ? sumOnDay(sessions) : 0;
  const weekCount = mounted ? sessionsThisWeek(sessions).length : 0;
  const daily = Math.min(1, todaySeconds / Math.max(1, settings.dailyGoalMinutes * 60));
  const favorites = workouts.filter((item) => item.favorite);
  const row = favorites.length ? favorites : workouts.slice(0, 3);
  const recent = mounted ? sessions.slice(0, 4) : [];
  const last = recent.find((session) => workouts.some((item) => item.id === session.workoutId));

  const label = run && run.phase !== "done" ? t("inProgress") : run?.phase === "done" ? t("pendingSummary") : planned && hero?.id === planned.id ? t("planToday") : t("nextUp");
  const button = run && run.phase !== "done" ? t("resume") : run?.phase === "done" ? t("seeSummary") : t("start");

  const start = () => {
    if (run && run.phase !== "done") {
      if (run.phase === "paused") resume();
      go({ name: "run" });
      return;
    }
    if (run?.phase === "done") {
      go({ name: "run" });
      return;
    }
    if (!hero) {
      beginQuick("tabata");
      return;
    }
    beginWorkout(hero.id);
  };

  return (
    <div className="mx-auto grid w-full min-w-0 max-w-5xl grid-cols-1 gap-5 px-4 py-6 md:grid-cols-[minmax(0,1.4fr)_minmax(0,0.8fr)] md:px-8 md:py-8">
      <header className="flex min-w-0 items-center justify-between md:col-span-2">
        <div className="flex items-center gap-3">
          <AppMark id={icon} className="size-12 md:hidden" />
          <div>
            <p className="text-[13px] font-semibold text-muted">Brasa</p>
            <h1 className="display text-4xl leading-none text-balance">{now ? greeting(lang, now) : t("hello")}</h1>
          </div>
        </div>
        <div className="glass-chip flex items-center gap-2 px-3 py-2">
          <Flame className="size-4 text-accent" />
          <span className="text-sm font-semibold tabular-nums">{streak.current}</span>
          <span className="text-sm text-muted">{t("days")}</span>
        </div>
      </header>

      <section className="panel relative min-w-0 overflow-hidden p-5 md:p-7">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted">{label}</p>
        <h2 className="display mt-3 text-5xl text-balance md:text-7xl">{hero?.name ?? t("tabata")}</h2>
        <p className="mt-3 text-muted">
          {hero ? (
            <>
              {formatSpan(steps.reduce((sum, step) => sum + step.seconds, 0))}
              {" · "}
              {blocks} {blocks === 1 ? t("block") : t("blocks")}
              {" · "}
              {roundCount} {t("rounds")}
            </>
          ) : (
            t("tagline")
          )}
        </p>
        {hero?.description ? <p className="mt-2 max-w-xl text-sm text-muted">{hero.description}</p> : null}
        <div className="mt-6 grid min-w-0 gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
          <PrimaryButton testId="start-workout" onClick={start}>
            <Play className="size-5 fill-current" />
            {button}
          </PrimaryButton>
          {last && !(run && run.phase !== "done") ? (
            <button
              type="button"
              className="inline-flex h-14 items-center justify-center gap-2 rounded-full border border-line bg-surface px-5 text-sm font-semibold"
              onClick={() => beginWorkout(last.workoutId)}
            >
              <RotateCcw className="size-4" />
              {t("repeatLast")}
            </button>
          ) : null}
        </div>
      </section>

      <section className="grid min-w-0 gap-3">
        <article className="panel flex items-center gap-4 p-4">
          <Ring value={daily} />
          <div>
            <p className="text-xs uppercase tracking-widest text-muted">{t("today")}</p>
            <p className="text-2xl font-semibold tabular-nums">
              {Math.round(todaySeconds / 60)}
              <span className="text-base font-medium text-muted">/{settings.dailyGoalMinutes} {t("minutesShort")}</span>
            </p>
            <p className="text-sm text-muted">
              {t("week")} {weekCount}/{settings.weeklyGoalSessions}
            </p>
            {daily >= 1 ? <p className="mt-1 text-sm font-semibold text-good">{t("goalMet")}</p> : null}
          </div>
        </article>
        <article className="panel p-4">
          <p className="text-xs uppercase tracking-widest text-muted">{streak.current ? t("streak") : t("startStreak")}</p>
          <p className="display mt-2 text-5xl tabular-nums">{streak.current}</p>
          <p className="text-sm text-muted">{t("bestStreak")} {streak.best}</p>
          <button type="button" className="mt-3 text-sm font-semibold text-accent" onClick={() => go({ name: "stats" })}>
            {t("openStats")}
          </button>
        </article>
      </section>

      <section className="grid min-w-0 grid-cols-2 gap-3 md:col-span-2">
        <button type="button" data-testid="home-steps" className="panel p-4 text-left" onClick={() => go({ name: "steps" })}>
          <Footprints className="size-4 text-accent" />
          <p className="mt-3 text-xs font-semibold uppercase tracking-widest text-muted">{t("stepsNav")}</p>
          <p className="display mt-1 text-4xl tabular-nums">{mounted ? stepsToday : 0}</p>
        </button>
        <button type="button" data-testid="home-focus" className="panel p-4 text-left" onClick={() => go({ name: "focus" })}>
          <Timer className="size-4 text-accent" />
          <p className="mt-3 text-xs font-semibold uppercase tracking-widest text-muted">{t("focusNav")}</p>
          <p className="mt-1 text-lg font-semibold">
            {pomo.status === "running" ? t(pomo.phase === "focus" ? "pomoFocus" : pomo.phase === "long" ? "pomoLong" : "pomoShort") : t("tasksTitle")}
          </p>
          <p className="text-sm text-muted">{openTasks}</p>
        </button>
      </section>

      <section className="min-w-0 md:col-span-2">
        <h3 className="mb-3 text-sm font-semibold uppercase tracking-widest text-muted">{t("quick")}</h3>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {QUICK.map((kind) => (
            <button
              key={kind}
              type="button"
              data-testid={`quick-${kind}`}
              onClick={() => beginQuick(kind)}
              className="panel flex h-24 flex-col items-start justify-between p-4 text-left transition active:scale-95"
            >
              <Play className="size-4 text-accent" />
              <span className="text-lg font-semibold">{t(kind)}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="panel min-w-0 p-4 md:col-span-2">
        <h3 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("plan")}</h3>
        <p className="mt-1 text-sm text-muted">{t("planHelp")}</p>
        <div className="mt-3 grid grid-cols-7 gap-1">
          {DAY_KEYS.map((key, index) => {
            const assigned = workouts.find((item) => item.id === weekPlan[index]);
            const isToday = todayIndex === index;
            return (
              <button
                key={key}
                type="button"
                data-testid={`plan-day-${index}`}
                title={assigned?.name ?? t("planFree")}
                onClick={() => setPlanDay(index)}
                className={cn(
                  "flex h-16 flex-col items-center justify-center rounded-2xl border text-xs font-semibold",
                  isToday ? "border-accent bg-raised text-ink" : "border-line bg-surface text-muted",
                )}
              >
                <span>{t(key)}</span>
                <span className={cn("mt-2 size-2 rounded-full", assigned ? "bg-accent" : "bg-line")} />
              </button>
            );
          })}
        </div>
      </section>

      <section className="min-w-0 md:col-span-2">
        <div className="mb-3 flex items-baseline justify-between">
          <h3 className="text-sm font-semibold uppercase tracking-widest text-muted">{favorites.length ? t("favorites") : t("suggested")}</h3>
          <button type="button" className="text-sm font-semibold text-accent" onClick={() => go({ name: "library" })}>
            {t("library")}
          </button>
        </div>
        {row.length === 0 ? <p className="text-muted">{t("favEmpty")}</p> : null}
        <div className="grid w-full min-w-0 max-w-full grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {row.map((workout) => {
            const total = flatten(workout).reduce((sum, step) => sum + step.seconds, 0);
            return (
              <button
                key={workout.id}
                type="button"
                onClick={() => beginWorkout(workout.id)}
                className="panel min-w-0 w-full p-4 text-left"
              >
                <p className="text-xs uppercase tracking-widest text-muted">{categoryLabel(lang, workout.category)}</p>
                <p className="mt-2 text-xl font-semibold text-balance">{workout.name}</p>
                <p className="mt-3 text-sm text-muted">{formatSpan(total)}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="panel min-w-0 p-4 md:col-span-2">
        <h3 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("recent")}</h3>
        {recent.length === 0 ? (
          <p className="mt-3 text-muted">{t("recentEmpty")}</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {recent.map((session) => (
              <li key={session.id} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold">{session.workoutName}</p>
                  <p className="text-sm text-muted">
                    {session.completed ? t("completed") : t("partial")}
                    {session.rpe != null ? ` · RPE ${session.rpe}` : ""}
                  </p>
                  {session.note ? <p className="mt-1 text-sm text-balance">{session.note}</p> : null}
                </div>
                <p className="shrink-0 tabular-nums text-muted">{formatSpan(session.elapsedSeconds)}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
      {planDay != null ? (
        <Modal title={t("planPick")} body={t(DAY_KEYS[planDay])} onClose={() => setPlanDay(null)}>
          <div className="max-h-72 overflow-y-auto">
            {workouts.map((workout) => (
              <button
                key={workout.id}
                type="button"
                className="flex h-12 w-full items-center justify-between rounded-2xl px-2 text-left font-semibold hover:bg-raised"
                onClick={() => {
                  setWeekSlot(planDay, workout.id);
                  setPlanDay(null);
                }}
              >
                <span className="truncate">{workout.name}</span>
                <span className="ml-3 shrink-0 text-xs font-medium text-muted">{categoryLabel(lang, workout.category)}</span>
              </button>
            ))}
          </div>
          <button
            type="button"
            className="h-12 rounded-full border border-line font-semibold"
            onClick={() => {
              setWeekSlot(planDay, null);
              setPlanDay(null);
            }}
          >
            {t("planClear")}
          </button>
        </Modal>
      ) : null}
    </div>
  );
}
