import { useMemo, useState } from "react";
import { Trash2 } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { bests, categoryMinutes, dayKey, formatSpan, recentDays, streaks, sumOnDay, weekSeconds } from "@/lib/brasa/engine";
import { categoryLabel } from "@/lib/brasa/i18n";
import { useBrasa } from "@/lib/brasa/store";
import { Modal, useI18n, useMounted } from "./ui";

export function Stats() {
  const { t, lang } = useI18n();
  const mounted = useMounted();
  const sessions = useBrasa((state) => state.sessions);
  const settings = useBrasa((state) => state.settings);
  const patch = useBrasa((state) => state.patchSettings);
  const removeSession = useBrasa((state) => state.deleteSession);
  const [cursor, setCursor] = useState(() => new Date());
  const [selected, setSelected] = useState<string | null>(null);
  const [range, setRange] = useState<7 | 28>(7);
  const [pending, setPending] = useState<string | null>(null);

  const streak = streaks(sessions);
  const total = sessions.reduce((sum, session) => sum + session.elapsedSeconds, 0);
  const done = sessions.filter((session) => session.completed).length;
  const weekSecondsNow = mounted ? weekSeconds(sessions, Date.now(), 0) : weekSeconds(sessions);
  const prevWeek = mounted ? weekSeconds(sessions, Date.now(), -1) : 0;
  const deltaMin = Math.round((weekSecondsNow - prevWeek) / 60);
  const marks = bests(sessions);
  const categories = categoryMinutes(sessions);
  const maxCategory = Math.max(1, ...categories.map((item) => item.minutes));
  const avg = sessions.length ? total / sessions.length : 0;
  const chart = useMemo(() => (mounted ? recentDays(sessions, range) : []), [mounted, sessions, range]);
  const month = cursor.getMonth();
  const year = cursor.getFullYear();
  const first = new Date(year, month, 1);
  const pad = (first.getDay() + 6) % 7;
  const days = new Date(year, month + 1, 0).getDate();
  const marked = new Set(sessions.map((session) => dayKey(session.endedAt)));
  const selectedSessions = sessions.filter((session) => selected && dayKey(session.endedAt) === selected);
  const feedbacks = sessions
    .filter((session) => (typeof session.note === "string" && session.note.trim()) || session.rpe != null)
    .sort((left, right) => right.endedAt - left.endedAt)
    .slice(0, 12);
  const monthLabel = mounted
    ? cursor.toLocaleDateString(lang === "es" ? "es" : "en", { month: "long", year: "numeric" })
    : "";

  return (
    <div className="mx-auto w-full min-w-0 max-w-full px-4 py-6 md:max-w-5xl md:px-8 md:py-8">
      <h1 className="display text-5xl">{t("stats")}</h1>
      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          [t("totalTime"), formatSpan(total)],
          [t("doneCount"), String(done)],
          [t("streak"), String(streak.current)],
          [t("bestStreak"), String(streak.best)],
          [t("weekMinutes"), String(Math.round(weekSecondsNow / 60))],
          [t("avg"), formatSpan(avg)],
          [t("today"), formatSpan(sumOnDay(sessions))],
          [t("sessions"), String(sessions.length)],
        ].map(([label, value]) => (
          <article key={label} className="panel p-4">
            <p className="text-xs uppercase tracking-widest text-muted">{label}</p>
            <p className="mt-2 text-2xl font-semibold tabular-nums">{value}</p>
          </article>
        ))}
      </div>

      <section className="panel mt-4 p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("feedbacks")}</h2>
          <span className="text-xs tabular-nums text-muted">{feedbacks.length}</span>
        </div>
        {feedbacks.length === 0 ? <p className="mt-2 text-sm text-muted">{t("noFeedback")}</p> : null}
        <ul className="mt-2 divide-y divide-line">
          {feedbacks.map((session) => (
            <li key={session.id} className="py-3">
              <div className="flex items-baseline justify-between gap-3">
                <p className="truncate font-semibold">{session.workoutName}</p>
                {session.rpe != null ? <span className="shrink-0 rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-onaccent">RPE {session.rpe}</span> : null}
              </div>
              {session.note?.trim() ? <p className="mt-1 text-sm text-balance">{session.note}</p> : null}
              <p className="mt-1 text-xs text-muted">
                {mounted ? new Date(session.endedAt).toLocaleDateString(lang === "es" ? "es" : "en") : ""}
                {mounted ? " · " : ""}
                {formatSpan(session.elapsedSeconds)}
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section className="panel mt-4 p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("chart")}</h2>
          <div className="flex gap-2">
            {([7, 28] as const).map((days) => (
              <button
                key={days}
                type="button"
                onClick={() => setRange(days)}
                className={`h-10 rounded-full px-3 text-sm font-semibold ${range === days ? "bg-accent text-onaccent" : "border border-line"}`}
              >
                {days === 7 ? t("range7") : t("range28")}
              </button>
            ))}
          </div>
        </div>
        <p className="mt-2 text-sm text-muted">
          {deltaMin > 0 ? "+" : ""}
          {deltaMin} {t("minutesShort")} {t("vsLast")}
        </p>
        <div className="mt-3 h-52">
          {mounted ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}>
                <XAxis dataKey="label" stroke="var(--line)" tick={{ fill: "var(--muted)", fontSize: 12 }} />
                <YAxis hide />
                <Tooltip
                  cursor={{ fill: "transparent" }}
                  contentStyle={{ background: "var(--surface)", border: "1px solid var(--line)", borderRadius: 12, color: "var(--ink)" }}
                />
                <Bar dataKey="minutes" fill="var(--accent)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : null}
        </div>
      </section>

      <section className="mt-4 grid gap-3 md:grid-cols-2">
        <article className="panel p-4">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("records")}</h2>
          {sessions.length === 0 ? <p className="mt-3 text-sm text-muted">{t("noMarks")}</p> : null}
          {marks.longest ? (
            <div className="mt-3 grid gap-3">
              <p>
                <span className="block text-xs uppercase tracking-widest text-muted">{t("longest")}</span>
                <span className="font-semibold">{marks.longest.workoutName}</span>
                <span className="text-muted"> · {formatSpan(marks.longest.elapsedSeconds)}</span>
              </p>
              <p>
                <span className="block text-xs uppercase tracking-widest text-muted">{t("bestDay")}</span>
                <span className="text-2xl font-semibold tabular-nums">{formatSpan(marks.bestDaySeconds)}</span>
              </p>
              <p>
                <span className="block text-xs uppercase tracking-widest text-muted">{t("finishRate")}</span>
                <span className="text-2xl font-semibold tabular-nums">{Math.round(marks.completion * 100)}%</span>
              </p>
            </div>
          ) : null}
        </article>
        <article className="panel p-4">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("byCategory")}</h2>
          {categories.length === 0 ? <p className="mt-3 text-sm text-muted">{t("noMarks")}</p> : null}
          <div className="mt-3 grid gap-3">
            {categories.map((item) => (
              <div key={item.category}>
                <div className="flex items-baseline justify-between gap-3 text-sm">
                  <span className="font-semibold">{categoryLabel(lang, item.category)}</span>
                  <span className="tabular-nums text-muted">
                    {item.minutes} {t("minutesShort")}
                  </span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-raised">
                  <div className="h-full rounded-full bg-accent" style={{ width: `${Math.max(6, (item.minutes / maxCategory) * 100)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="panel mt-4 p-4">
        <div className="flex min-w-0 flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("calendar")}</h2>
          <div className="flex min-w-0 flex-1 items-center justify-end gap-1 sm:flex-none sm:gap-2">
            <button type="button" className="h-10 w-10 shrink-0 rounded-full border border-line px-0" onClick={() => setCursor(new Date(year, month - 1, 1))} aria-label="-">
              ‹
            </button>
            <p className="grid min-w-0 flex-1 place-items-center px-1 text-center text-xs font-semibold capitalize sm:min-w-32 sm:text-sm">{monthLabel}</p>
            <button type="button" className="h-10 w-10 shrink-0 rounded-full border border-line px-0" onClick={() => setCursor(new Date(year, month + 1, 1))} aria-label="+">
              ›
            </button>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-7 gap-1 text-center text-xs text-muted">
          {[1, 2, 3, 4, 5, 6, 0].map((day) => (
            <span key={day}>{t(day === 0 ? "day0" : day === 1 ? "day1" : day === 2 ? "day2" : day === 3 ? "day3" : day === 4 ? "day4" : day === 5 ? "day5" : "day6")}</span>
          ))}
        </div>
        <div className="mt-1 grid grid-cols-7 gap-1">
          {Array.from({ length: pad }).map((_, index) => (
            <span key={`pad-${index}`} />
          ))}
          {Array.from({ length: days }, (_, index) => {
            const day = index + 1;
            const key = dayKey(new Date(year, month, day).getTime());
            const active = marked.has(key);
            return (
              <button
                key={key}
                type="button"
                onClick={() => setSelected(key)}
                className={`grid h-11 place-items-center rounded-xl text-sm tabular-nums ${selected === key ? "bg-accent text-onaccent" : active ? "bg-raised font-semibold text-accent" : ""}`}
              >
                {day}
              </button>
            );
          })}
        </div>
        <div className="mt-3">
          {selectedSessions.length === 0 ? <p className="text-sm text-muted">{t("noDay")}</p> : null}
          {selectedSessions.map((session) => (
            <p key={session.id} className="py-1 text-sm">
              <span className="font-semibold">{session.workoutName}</span>
              <span className="text-muted"> · {formatSpan(session.elapsedSeconds)}{session.rpe != null ? ` · RPE ${session.rpe}` : ""}{session.note ? ` · ${session.note}` : ""}</span>
            </p>
          ))}
        </div>
      </section>

      <section className="panel mt-4 grid gap-4 p-4 md:grid-cols-2">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted md:col-span-2">{t("goals")}</h2>
        <label>
          <span className="text-sm text-muted">{t("dailyGoal")}</span>
          <input className="field mt-1" inputMode="numeric" value={settings.dailyGoalMinutes} onChange={(event) => patch({ dailyGoalMinutes: Math.max(5, Math.min(300, Number(event.target.value) || 0)) })} />
        </label>
        <label>
          <span className="text-sm text-muted">{t("weeklyGoal")}</span>
          <input className="field mt-1" inputMode="numeric" value={settings.weeklyGoalSessions} onChange={(event) => patch({ weeklyGoalSessions: Math.max(1, Math.min(21, Number(event.target.value) || 0)) })} />
        </label>
      </section>

      <section className="panel mt-4 p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("history")}</h2>
        {sessions.length === 0 ? <p className="mt-2 text-muted">{t("noHistory")}</p> : null}
        <ul className="mt-2 divide-y divide-line">
          {sessions.slice(0, 20).map((session) => (
            <li key={session.id} className="flex items-center justify-between gap-3 py-3">
              <div className="min-w-0">
                <p className="truncate font-semibold">{session.workoutName}</p>
                <p className="text-sm text-muted">
                  {session.completed ? t("completed") : t("partial")}
                  {session.rpe != null ? ` · RPE ${session.rpe}` : ""}
                </p>
                {session.note ? <p className="text-sm text-balance">{session.note}</p> : null}
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <p className="tabular-nums">{formatSpan(session.elapsedSeconds)}</p>
                <button type="button" aria-label={t("removeLog")} className="grid size-11 place-items-center rounded-full border border-line text-danger" onClick={() => setPending(session.id)}>
                  <Trash2 className="size-4" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </section>
      {pending ? (
        <Modal title={t("confirmLog")} onClose={() => setPending(null)}>
          <button
            type="button"
            className="h-12 rounded-full bg-danger font-semibold text-canvas"
            onClick={() => {
              removeSession(pending);
              setPending(null);
            }}
          >
            {t("removeLog")}
          </button>
          <button type="button" className="h-12 rounded-full border border-line font-semibold" onClick={() => setPending(null)}>
            {t("cancel")}
          </button>
        </Modal>
      ) : null}
    </div>
  );
}
