import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { ColorKey } from "@/lib/brasa/types";
import { t, tf, type Key } from "@/lib/brasa/i18n";
import { useBrasa } from "@/lib/brasa/store";

export const FILL: Record<ColorKey, string> = {
  ember: "bg-ember",
  copper: "bg-copper",
  gold: "bg-gold",
  sage: "bg-sage",
  tide: "bg-tide",
  rose: "bg-rose",
  lime: "bg-lime",
  slate: "bg-slate",
};

export const INK: Record<ColorKey, string> = {
  ember: "text-ember",
  copper: "text-copper",
  gold: "text-gold",
  sage: "text-sage",
  tide: "text-tide",
  rose: "text-rose",
  lime: "text-lime",
  slate: "text-slate",
};

export const STROKE: Record<ColorKey, string> = {
  ember: "stroke-ember",
  copper: "stroke-copper",
  gold: "stroke-gold",
  sage: "stroke-sage",
  tide: "stroke-tide",
  rose: "stroke-rose",
  lime: "stroke-lime",
  slate: "stroke-slate",
};

export function useI18n() {
  const lang = useBrasa((state) => state.settings.lang);
  return {
    lang,
    t: (key: Key) => t(lang, key),
    tf: (key: Key, vars: Record<string, string | number>) => tf(lang, key, vars),
  };
}

export function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}

export function PrimaryButton({
  children,
  onClick,
  testId,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  testId?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      data-testid={testId}
      disabled={disabled}
      onClick={onClick}
      className="ios-fill inline-flex h-14 w-full items-center justify-center gap-2 rounded-full px-6 text-lg font-semibold text-onaccent transition active:scale-[0.98] disabled:opacity-40"
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  onClick,
  testId,
}: {
  children: ReactNode;
  onClick?: () => void;
  testId?: string;
}) {
  return (
    <button
      type="button"
      data-testid={testId}
      onClick={onClick}
      className="glass-chip inline-flex h-12 items-center justify-center gap-2 px-4 text-sm font-semibold text-ink transition active:scale-[0.98]"
    >
      {children}
    </button>
  );
}

export function IconButton({
  label,
  onClick,
  children,
  active,
}: {
  label: string;
  onClick?: () => void;
  children: ReactNode;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn(
        "glass-chip inline-flex size-12 items-center justify-center text-ink transition active:scale-95",
        active && "border-accent text-accent",
      )}
    >
      {children}
    </button>
  );
}

export function Modal({
  title,
  body,
  onClose,
  children,
}: {
  title: string;
  body?: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/45 p-3 backdrop-blur-md sm:items-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className="glass-sheet max-h-[min(88dvh,40rem)] w-full max-w-md overflow-y-auto p-5">
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-muted/40 sm:hidden" />
        <h2 className="text-xl font-semibold text-balance">{title}</h2>
        {body ? <p className="mt-2 text-muted">{body}</p> : null}
        <div className="mt-5 grid gap-2">{children}</div>
      </div>
    </div>
  );
}

export function Ring({ value, className }: { value: number; className?: string }) {
  const radius = 28;
  const circ = 2 * Math.PI * radius;
  const offset = circ * (1 - Math.max(0, Math.min(1, value)));
  return (
    <svg viewBox="0 0 72 72" className={cn("size-16", className)} aria-hidden="true">
      <circle cx="36" cy="36" r={radius} className="stroke-line" strokeWidth="6" fill="none" />
      <circle
        cx="36"
        cy="36"
        r={radius}
        className="stroke-accent"
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        transform="rotate(-90 36 36)"
      />
    </svg>
  );
}
