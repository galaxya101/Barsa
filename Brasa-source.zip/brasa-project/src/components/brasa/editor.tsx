import { ChevronDown, ChevronLeft, ChevronUp, Copy, Plus, Trash2 } from "lucide-react";
import { beginWorkout } from "@/lib/brasa/launch";
import { flatten, formatSpan } from "@/lib/brasa/engine";
import { freshInterval } from "@/lib/brasa/samples";
import { useBrasa } from "@/lib/brasa/store";
import { CATEGORIES, COLOR_KEYS, defaultColor, type Block, type Interval, type IntervalKind, type Workout } from "@/lib/brasa/types";
import { categoryLabel } from "@/lib/brasa/i18n";
import { uid } from "@/lib/utils";
import { FILL, IconButton, useI18n } from "./ui";

function move<T>(list: T[], index: number, dir: -1 | 1): T[] {
  const next = index + dir;
  if (next < 0 || next >= list.length) return list;
  const copy = list.slice();
  const [item] = copy.splice(index, 1);
  copy.splice(next, 0, item);
  return copy;
}

export function Editor({ id }: { id: string }) {
  const { t, lang } = useI18n();
  const workout = useBrasa((state) => state.workouts.find((item) => item.id === id));
  const update = useBrasa((state) => state.updateWorkout);
  const addCategory = useBrasa((state) => state.addCategory);
  const custom = useBrasa((state) => state.customCategories);
  const go = useBrasa((state) => state.go);
  const ret = useBrasa((state) => state.editReturn);

  if (!workout) {
    return (
      <div className="p-6">
        <button type="button" className="text-accent" onClick={() => go({ name: "library" })}>
          {t("back")}
        </button>
      </div>
    );
  }

  const patch = (updater: (current: Workout) => Workout) => update(workout.id, updater);
  const patchBlock = (blockId: string, updater: (block: Block) => Block) =>
    patch((current) => ({ ...current, blocks: current.blocks.map((block) => (block.id === blockId ? updater(block) : block)) }));
  const patchInterval = (blockId: string, intervalId: string, updater: (interval: Interval) => Interval) =>
    patchBlock(blockId, (block) => ({ ...block, intervals: block.intervals.map((interval) => (interval.id === intervalId ? updater(interval) : interval)) }));

  const categories = [...CATEGORIES, ...custom.filter((item) => !CATEGORIES.includes(item as (typeof CATEGORIES)[number]))];
  const totalSeconds = flatten(workout).reduce((sum, step) => sum + step.seconds, 0);

  return (
    <div className="mx-auto w-full min-w-0 max-w-full px-4 py-5 md:max-w-3xl md:px-8 md:py-8">
      <div className="flex items-center gap-2">
        <IconButton label={t("back")} onClick={() => go(ret === "home" ? { name: "home" } : { name: "library" })}>
          <ChevronLeft className="size-5" />
        </IconButton>
        <p className="text-sm text-muted">
          {t("saved")} · {t("totalLabel")} {formatSpan(totalSeconds)}
        </p>
        <button type="button" className="ml-auto h-12 rounded-full bg-accent px-5 font-semibold text-onaccent" onClick={() => beginWorkout(workout.id)}>
          {t("try")}
        </button>
      </div>

      <label className="mt-5 block">
        <span className="text-sm text-muted">{t("name")}</span>
        <input className="field mt-1 text-xl font-semibold" value={workout.name} onChange={(event) => patch((current) => ({ ...current, name: event.target.value }))} />
      </label>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <label>
          <span className="text-sm text-muted">{t("category")}</span>
          <select
            className="field mt-1"
            value={categories.includes(workout.category as (typeof categories)[number]) ? workout.category : workout.category}
            onChange={(event) => patch((current) => ({ ...current, category: event.target.value }))}
          >
            {categories.map((item) => (
              <option key={item} value={item}>
                {categoryLabel(lang, item)}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="text-sm text-muted">{t("newCategory")}</span>
          <input
            className="field mt-1"
            placeholder={t("newCategory")}
            onKeyDown={(event) => {
              if (event.key !== "Enter") return;
              const value = event.currentTarget.value.trim();
              if (!value) return;
              addCategory(value);
              patch((current) => ({ ...current, category: value }));
              event.currentTarget.value = "";
            }}
          />
        </label>
      </div>

      <label className="mt-4 block">
        <span className="text-sm text-muted">{t("description")}</span>
        <textarea className="field mt-1 min-h-20" value={workout.description} onChange={(event) => patch((current) => ({ ...current, description: event.target.value }))} />
      </label>

      <div className="mt-6 grid gap-4">
        {workout.blocks.map((block, blockIndex) => (
          <article key={block.id} className="panel p-4">
            <div className="flex flex-wrap items-center gap-2">
              <input
                aria-label={t("blockName")}
                className="field min-w-0 flex-1 font-semibold"
                value={block.name}
                onChange={(event) => patchBlock(block.id, (current) => ({ ...current, name: event.target.value }))}
              />
              <IconButton label={t("moveUp")} onClick={() => patch((current) => ({ ...current, blocks: move(current.blocks, blockIndex, -1) }))}>
                <ChevronUp className="size-5" />
              </IconButton>
              <IconButton label={t("moveDown")} onClick={() => patch((current) => ({ ...current, blocks: move(current.blocks, blockIndex, 1) }))}>
                <ChevronDown className="size-5" />
              </IconButton>
              <IconButton
                label={t("duplicateBlock")}
                onClick={() =>
                  patch((current) => {
                    const copy: Block = {
                      ...structuredClone(block),
                      id: uid(),
                      intervals: block.intervals.map((interval) => ({ ...interval, id: uid() })),
                    };
                    const blocks = current.blocks.slice();
                    blocks.splice(blockIndex + 1, 0, copy);
                    return { ...current, blocks };
                  })
                }
              >
                <Copy className="size-5" />
              </IconButton>
              <IconButton
                label={t("deleteBlock")}
                onClick={() => patch((current) => ({ ...current, blocks: current.blocks.filter((item) => item.id !== block.id) }))}
              >
                <Trash2 className="size-5" />
              </IconButton>
            </div>

            <div className="mt-3 flex items-center justify-between gap-3">
              <span className="text-sm text-muted">{t("roundsLabel")}</span>
              <div className="flex items-center gap-2">
                <button type="button" className="grid size-11 place-items-center rounded-full border border-line" onClick={() => patchBlock(block.id, (current) => ({ ...current, rounds: Math.max(1, current.rounds - 1) }))} aria-label="-">
                  −
                </button>
                <span className="w-8 text-center text-xl font-semibold tabular-nums">{block.rounds}</span>
                <button type="button" className="grid size-11 place-items-center rounded-full border border-line" onClick={() => patchBlock(block.id, (current) => ({ ...current, rounds: Math.min(99, current.rounds + 1) }))} aria-label="+">
                  +
                </button>
              </div>
            </div>

            <div className="mt-3 grid gap-3">
              {block.intervals.map((interval, intervalIndex) => (
                <div key={interval.id} className="rounded-2xl border border-line bg-raised p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`size-3 rounded-full ${FILL[interval.color]}`} />
                    {(["work", "rest", "warmup"] as IntervalKind[]).map((kind) => (
                      <button
                        key={kind}
                        type="button"
                        onClick={() => patchInterval(block.id, interval.id, (current) => ({ ...current, kind, color: defaultColor(kind) }))}
                        className={`h-9 rounded-full px-3 text-sm font-semibold ${interval.kind === kind ? "bg-accent text-onaccent" : "text-muted"}`}
                      >
                        {t(kind === "warmup" ? "addWarm" : kind === "rest" ? "addRest" : "addWork")}
                      </button>
                    ))}
                    <span className="ml-auto flex gap-1">
                      <button type="button" aria-label={t("moveUp")} className="grid size-10 place-items-center" onClick={() => patchBlock(block.id, (current) => ({ ...current, intervals: move(current.intervals, intervalIndex, -1) }))}>
                        <ChevronUp className="size-4" />
                      </button>
                      <button type="button" aria-label={t("moveDown")} className="grid size-10 place-items-center" onClick={() => patchBlock(block.id, (current) => ({ ...current, intervals: move(current.intervals, intervalIndex, 1) }))}>
                        <ChevronDown className="size-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={t("duplicateInterval")}
                        className="grid size-10 place-items-center"
                        onClick={() =>
                          patchBlock(block.id, (current) => {
                            const intervals = current.intervals.slice();
                            intervals.splice(intervalIndex + 1, 0, { ...interval, id: uid() });
                            return { ...current, intervals };
                          })
                        }
                      >
                        <Copy className="size-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={t("deleteInterval")}
                        className="grid size-10 place-items-center"
                        onClick={() => patchBlock(block.id, (current) => ({ ...current, intervals: current.intervals.filter((item) => item.id !== interval.id) }))}
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </span>
                  </div>
                  <input aria-label={t("intervalName")} className="field mt-2" value={interval.name} onChange={(event) => patchInterval(block.id, interval.id, (current) => ({ ...current, name: event.target.value }))} />
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    <label>
                      <span className="text-xs text-muted">{t("minutes")}</span>
                      <input
                        className="field mt-1"
                        inputMode="numeric"
                        value={Math.floor(interval.seconds / 60)}
                        onChange={(event) => {
                          const mins = Math.max(0, Math.min(180, Number(event.target.value) || 0));
                          const secs = interval.seconds % 60;
                          patchInterval(block.id, interval.id, (current) => ({ ...current, seconds: Math.max(5, mins * 60 + secs) }));
                        }}
                      />
                    </label>
                    <label>
                      <span className="text-xs text-muted">{t("seconds")}</span>
                      <input
                        className="field mt-1"
                        inputMode="numeric"
                        value={interval.seconds % 60}
                        onChange={(event) => {
                          const secs = Math.max(0, Math.min(59, Number(event.target.value) || 0));
                          const mins = Math.floor(interval.seconds / 60);
                          patchInterval(block.id, interval.id, (current) => ({ ...current, seconds: Math.max(5, mins * 60 + secs) }));
                        }}
                      />
                    </label>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {[10, 15, 20, 30, 45, 60, 90, 180].map((seconds) => (
                      <button key={seconds} type="button" className="h-9 rounded-full border border-line px-3 text-sm tabular-nums" onClick={() => patchInterval(block.id, interval.id, (current) => ({ ...current, seconds }))}>
                        {seconds >= 60 ? `${seconds / 60}m` : `${seconds}s`}
                      </button>
                    ))}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label={t("color")}>
                    {COLOR_KEYS.map((color) => (
                      <button
                        key={color}
                        type="button"
                        aria-label={color}
                        onClick={() => patchInterval(block.id, interval.id, (current) => ({ ...current, color }))}
                        className={`size-8 rounded-full ${FILL[color]} ${interval.color === color ? "ring-2 ring-ink ring-offset-2 ring-offset-raised" : ""}`}
                      />
                    ))}
                  </div>
                  <label className="mt-3 block">
                    <span className="text-xs text-muted">{t("instruction")}</span>
                    <input className="field mt-1" placeholder={t("instructionPh")} value={interval.instruction} onChange={(event) => patchInterval(block.id, interval.id, (current) => ({ ...current, instruction: event.target.value }))} />
                  </label>
                  <p className="mt-3 text-xs font-semibold uppercase tracking-widest text-muted">{t("intensity")}</p>
                  <div className="mt-2 grid gap-2 md:grid-cols-2">
                    {([
                      ["speed", t("speed"), t("speedPh")],
                      ["incline", t("incline"), t("inclinePh")],
                      ["resistance", t("resistance"), t("resistancePh")],
                      ["custom", t("custom"), t("customPh")],
                    ] as const).map(([key, label, placeholder]) => (
                      <label key={key}>
                        <span className="text-xs text-muted">{label}</span>
                        <input
                          className="field mt-1"
                          placeholder={placeholder}
                          value={interval.notes[key]}
                          onChange={(event) =>
                            patchInterval(block.id, interval.id, (current) => ({
                              ...current,
                              notes: { ...current.notes, [key]: event.target.value },
                            }))
                          }
                        />
                      </label>
                    ))}
                  </div>
                  <div className="mt-2">
                    <span className="text-xs text-muted">{t("difficulty")}</span>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {Array.from({ length: 10 }, (_, index) => String(index + 1)).map((level) => (
                        <button
                          key={level}
                          type="button"
                          onClick={() =>
                            patchInterval(block.id, interval.id, (current) => ({
                              ...current,
                              notes: { ...current.notes, difficulty: current.notes.difficulty === level ? "" : level },
                            }))
                          }
                          className={`grid size-9 place-items-center rounded-full text-sm font-semibold ${interval.notes.difficulty === level ? "bg-accent text-onaccent" : "border border-line"}`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {(["work", "rest", "warmup"] as IntervalKind[]).map((kind) => (
                <button
                  key={kind}
                  type="button"
                  className="inline-flex h-11 items-center gap-2 rounded-full border border-line px-3 text-sm font-semibold"
                  onClick={() => patchBlock(block.id, (current) => ({ ...current, intervals: [...current.intervals, freshInterval(kind, lang)] }))}
                >
                  <Plus className="size-4" />
                  {t(kind === "warmup" ? "addWarm" : kind === "rest" ? "addRest" : "addWork")}
                </button>
              ))}
            </div>
          </article>
        ))}
      </div>

      <button
        type="button"
        className="mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full border border-dashed border-line font-semibold"
        onClick={() =>
          patch((current) => ({
            ...current,
            blocks: [
              ...current.blocks,
              { id: uid(), name: `${t("blockN")} ${current.blocks.length + 1}`, rounds: 1, intervals: [freshInterval("work", lang)] },
            ],
          }))
        }
      >
        <Plus className="size-4" />
        {t("addBlock")}
      </button>
    </div>
  );
}
