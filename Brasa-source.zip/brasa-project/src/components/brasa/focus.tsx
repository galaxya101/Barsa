import { useEffect, useState } from "react";
import { Check, Minus, Plus, Trash2 } from "lucide-react";
import { formatClock } from "@/lib/brasa/engine";
import { chime } from "@/lib/brasa/audio";
import type { PomoPhase } from "@/lib/brasa/day";
import { phaseMs } from "@/lib/brasa/day";
import { useBrasa } from "@/lib/brasa/store";
import { cn } from "@/lib/utils";
import { PrimaryButton, useI18n, useMounted } from "./ui";

const PHASES: { id: PomoPhase; key: "pomoFocus" | "pomoShort" | "pomoLong" }[] = [
  { id: "focus", key: "pomoFocus" },
  { id: "short", key: "pomoShort" },
  { id: "long", key: "pomoLong" },
];

export function FocusScreen() {
  const { t, tf } = useI18n();
  const mounted = useMounted();
  const pomo = useBrasa((state) => state.pomo);
  const tasks = useBrasa((state) => state.tasks);
  const [draft, setDraft] = useState("");
  const [now, setNow] = useState(0);

  useEffect(() => {
    if (!mounted) return;
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 200);
    return () => window.clearInterval(id);
  }, [mounted]);

  const left = pomo.status === "running" && pomo.endsAt && now ? Math.max(0, pomo.endsAt - now) : pomo.remainingMs;
  const linked = tasks.find((task) => task.id === pomo.taskId) ?? null;
  const open = tasks.filter((task) => !task.done);
  const done = tasks.filter((task) => task.done);
  const running = pomo.status === "running";

  const start = () => {
    if (running) useBrasa.getState().pauseFocus();
    else useBrasa.getState().startFocus();
    chime(useBrasa.getState().settings, "tick");
  };

  const add = () => {
    useBrasa.getState().addTask(draft);
    setDraft("");
  };

  return (
    <div data-testid="focus-screen" className="mx-auto grid w-full min-w-0 max-w-3xl gap-5 px-4 py-6 md:px-8 md:py-8">
      <header>
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-muted">Brasa</p>
        <h1 className="display mt-2 text-5xl">{t("focusTitle")}</h1>
      </header>

      <section className="panel p-5 md:p-7">
        <div className="grid grid-cols-3 gap-2">
          {PHASES.map((phase) => (
            <button
              key={phase.id}
              type="button"
              disabled={running}
              onClick={() => useBrasa.getState().choosePomo(phase.id)}
              className={cn(
                "h-11 rounded-full border text-sm font-semibold",
                pomo.phase === phase.id ? "border-accent bg-raised text-ink" : "border-line text-muted",
              )}
            >
              {t(phase.key)}
            </button>
          ))}
        </div>
        <p className="timer-digits mt-6 text-center tabular-nums" data-testid="pomo-clock">
          {formatClock(left)}
        </p>
        <p className="mt-2 text-center text-sm text-muted">
          {tf("pomoCycle", { n: pomo.phase === "focus" ? pomo.cycle + 1 : pomo.cycle || 4 })}
          {" · "}
          {linked ? linked.title : t("taskNone")}
        </p>
        <div className="mt-4 flex justify-center gap-2">
          {[0, 1, 2, 3].map((dot) => (
            <span key={dot} className={cn("size-2.5 rounded-full", dot < pomo.cycle ? "bg-accent" : "bg-line")} />
          ))}
        </div>
        <div className="mt-6 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
          <PrimaryButton testId="pomo-toggle" onClick={start}>
            {running ? t("pause") : pomo.status === "paused" ? t("resume") : t("pomoStart")}
          </PrimaryButton>
          <button
            type="button"
            data-testid="pomo-skip"
            className="h-14 rounded-full border border-line px-5 text-sm font-semibold"
            onClick={() => {
              const events = useBrasa.getState().skipFocus();
              if (!events.length) return;
              const settings = useBrasa.getState().settings;
              chime(settings, "change");
            }}
          >
            {t("pomoSkip")}
          </button>
        </div>
        {!running ? (
          <div className="mt-5 grid gap-2">
            {PHASES.map((phase) => {
              const minutes = phase.id === "focus" ? pomo.focusMin : phase.id === "short" ? pomo.shortMin : pomo.longMin;
              return (
                <div key={phase.id} className="flex items-center justify-between gap-3">
                  <span className="text-sm font-semibold">{t(phase.key)}</span>
                  <span className="flex items-center gap-2">
                    <button
                      type="button"
                      aria-label={`${t(phase.key)} −`}
                      className="inline-flex size-11 items-center justify-center rounded-full border border-line"
                      onClick={() => useBrasa.getState().setPomoLength(phase.id, minutes - 1)}
                    >
                      <Minus className="size-4" />
                    </button>
                    <span className="w-14 text-center font-semibold tabular-nums">
                      {minutes} {t("minutesShort")}
                    </span>
                    <button
                      type="button"
                      aria-label={`${t(phase.key)} +`}
                      className="inline-flex size-11 items-center justify-center rounded-full border border-line"
                      onClick={() => useBrasa.getState().setPomoLength(phase.id, minutes + 1)}
                    >
                      <Plus className="size-4" />
                    </button>
                  </span>
                </div>
              );
            })}
          </div>
        ) : null}
        <p className="sr-only">{Math.round(phaseMs(pomo) / 1000)}</p>
      </section>

      <section className="panel p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-muted">{t("tasksTitle")}</h2>
        <form
          className="mt-3 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            add();
          }}
        >
          <input
            data-testid="task-input"
            className="field min-w-0 flex-1"
            value={draft}
            placeholder={t("taskPh")}
            onChange={(event) => setDraft(event.target.value)}
          />
          <button type="submit" data-testid="task-add" className="h-12 shrink-0 rounded-full bg-accent px-4 font-semibold text-onaccent">
            {t("taskAdd")}
          </button>
        </form>
        {tasks.length === 0 ? <p className="mt-4 text-sm text-muted">{t("taskEmpty")}</p> : null}
        <ul className="mt-3 grid gap-2">
          {open.map((task) => (
            <TaskRow key={task.id} id={task.id} title={task.title} done={false} pomodoros={task.pomodoros} selected={pomo.taskId === task.id} />
          ))}
        </ul>
        {done.length ? (
          <div className="mt-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted">{t("taskDone")}</p>
            <ul className="mt-2 grid gap-2">
              {done.map((task) => (
                <TaskRow key={task.id} id={task.id} title={task.title} done pomodoros={task.pomodoros} selected={false} />
              ))}
            </ul>
          </div>
        ) : null}
      </section>
    </div>
  );
}

function TaskRow({
  id,
  title,
  done,
  pomodoros,
  selected,
}: {
  id: string;
  title: string;
  done: boolean;
  pomodoros: number;
  selected: boolean;
}) {
  const { t, tf } = useI18n();
  return (
    <li className={cn("flex items-center gap-2 rounded-2xl border px-2 py-1", selected ? "border-accent bg-raised" : "border-line")}>
      <button
        type="button"
        role="checkbox"
        aria-checked={done}
        data-testid={`task-check-${id}`}
        aria-label={done ? t("taskUncheck") : t("taskCheck")}
        className={cn(
          "inline-flex size-11 shrink-0 items-center justify-center rounded-full border",
          done ? "border-accent bg-accent text-onaccent" : "border-line",
        )}
        onClick={() => useBrasa.getState().toggleTask(id)}
      >
        {done ? <Check className="size-5" /> : null}
      </button>
      <button
        type="button"
        className="min-w-0 flex-1 py-2 text-left"
        onClick={() => useBrasa.getState().selectPomoTask(selected ? null : id)}
      >
        <span className={cn("block truncate font-semibold", done && "text-muted line-through")}>{title}</span>
        <span className="text-xs text-muted">{selected ? t("taskPick") : tf("taskPomos", { n: pomodoros })}</span>
      </button>
      <button
        type="button"
        aria-label={t("taskDelete")}
        className="inline-flex size-11 items-center justify-center rounded-full text-muted"
        onClick={() => useBrasa.getState().deleteTask(id)}
      >
        <Trash2 className="size-4" />
      </button>
    </li>
  );
}
