import { useEffect, useRef, useState, type ReactNode } from "react";
import { Footprints, House, Library, Settings, Timer } from "lucide-react";
import { AppMark, faviconSvg } from "@/lib/brasa/icons";
import { chime, playEvents, syncBed } from "@/lib/brasa/audio";
import { formatClock, trainedMs } from "@/lib/brasa/engine";
import { t as translate } from "@/lib/brasa/i18n";
import { bindStepSensor } from "@/lib/brasa/sensor";
import { appIconLabel } from "@/lib/brasa/i18n";
import { THEME_HEX } from "@/lib/brasa/types";
import { useBrasa } from "@/lib/brasa/store";
import { cn } from "@/lib/utils";
import { hear } from "@/lib/brasa/launch";
import { brasaNative, setNativeIcon, widgetPayload } from "@/lib/brasa/native";
import { useI18n } from "./ui";

const NAV = [
  { id: "home", key: "home", icon: House },
  { id: "steps", key: "stepsNav", icon: Footprints },
  { id: "focus", key: "focusNav", icon: Timer },
  { id: "library", key: "library", icon: Library },
  { id: "settings", key: "settings", icon: Settings },
] as const;

function NativeSync() {
  const hydrated = useBrasa((state) => state.hydrated);
  const run = useBrasa((state) => state.run);
  const appIcon = useBrasa((state) => state.settings.appIcon);
  const theme = useBrasa((state) => state.settings.theme);
  const lang = useBrasa((state) => state.settings.lang);
  const reminders = useBrasa((state) => state.settings.reminders);
  const sessions = useBrasa((state) => state.sessions);

  useEffect(() => {
    const host = window as Window & { __brasaWidget?: (action: string) => void };
    host.__brasaWidget = (action) => {
      if (action === "pause") controlRun("pause");
      else if (action === "resume") controlRun("resume");
      else if (action === "open") {
        const state = useBrasa.getState();
        if (state.run && state.run.phase !== "done") state.go({ name: "run" });
        else state.go({ name: "home" });
      }
    };
    return () => {
      delete host.__brasaWidget;
    };
  }, []);

  const synced = useRef("");

  useEffect(() => {
    if (!hydrated) return;
    setNativeIcon(appIcon, theme);
  }, [hydrated, appIcon, theme]);

  useEffect(() => {
    if (!hydrated) return;
    brasaNative()?.syncReminders?.(JSON.stringify(reminders));
  }, [hydrated, reminders]);

  useEffect(() => {
    if (!hydrated) return;
    const bridge = brasaNative();
    if (!bridge?.syncWidget) return;
    const payload = { ...widgetPayload(lang, run, sessions), theme };
    const sig = JSON.stringify({ ...payload, remainingMs: payload.paused ? payload.remainingMs : 0, hero: payload.active ? "" : payload.hero });
    if (synced.current === sig) return;
    synced.current = sig;
    bridge.syncWidget(JSON.stringify(payload));
  }, [hydrated, run, sessions, lang, theme]);

  return null;
}

function BrandSync() {
  const theme = useBrasa((state) => state.settings.theme);
  const icon = useBrasa((state) => state.settings.appIcon);
  const lang = useBrasa((state) => state.settings.lang);
  const large = useBrasa((state) => state.settings.largeText);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.large = large ? "1" : "0";
    document.documentElement.lang = lang;
    document.title = appIconLabel(lang, icon);
    const themeMeta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (themeMeta) themeMeta.content = THEME_HEX[theme].canvas;
    const href = `data:image/svg+xml,${encodeURIComponent(faviconSvg(icon, THEME_HEX[theme].accent, THEME_HEX[theme].canvas))}`;
    let link = document.querySelector<HTMLLinkElement>("link[rel='icon']");
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.href = href;
  }, [theme, icon, lang, large]);
  return null;
}

function StepEngine() {
  const hydrated = useBrasa((state) => state.hydrated);
  const tracking = useBrasa((state) => state.steps.tracking);
  useEffect(() => {
    if (!hydrated || !tracking) return undefined;
    return bindStepSensor();
  }, [hydrated, tracking]);
  return null;
}

function PomoEngine() {
  const hydrated = useBrasa((state) => state.hydrated);
  const status = useBrasa((state) => state.pomo.status);
  useEffect(() => {
    if (!hydrated) return undefined;
    const pump = () => {
      const events = useBrasa.getState().settlePomo(Date.now());
      if (!events.length) return;
      const settings = useBrasa.getState().settings;
      chime(settings, "done");
      const last = events[events.length - 1];
      const text = last && last.phase === "focus" ? translate(settings.lang, "pomoFocusDone") : translate(settings.lang, "pomoBreakDone");
      useBrasa.getState().toastTo(text);
      if (typeof Notification !== "undefined" && Notification.permission === "granted" && document.visibilityState !== "visible") {
        try {
          new Notification("Brasa", { body: text });
        } catch {
          /* already showing */
        }
      }
    };
    pump();
    if (status !== "running") return undefined;
    const id = window.setInterval(pump, 250);
    document.addEventListener("visibilitychange", pump);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", pump);
    };
  }, [hydrated, status]);
  return null;
}

function RunEngine() {
  const phase = useBrasa((state) => state.run?.phase ?? "idle");
  useEffect(() => {
    const pump = () => {
      const events = useBrasa.getState().tickRun(Date.now());
      const snap = useBrasa.getState();
      if (events.length) playEvents(events, { settings: snap.settings, run: snap.run });
      else syncBed({ settings: snap.settings, run: snap.run });
    };
    if (phase === "running" || phase === "ready") {
      const id = window.setInterval(pump, 200);
      const onVis = () => {
        if (document.visibilityState === "visible") pump();
      };
      document.addEventListener("visibilitychange", onVis);
      return () => {
        window.clearInterval(id);
        document.removeEventListener("visibilitychange", onVis);
      };
    }
    syncBed({ settings: useBrasa.getState().settings, run: useBrasa.getState().run });
    return undefined;
  }, [phase]);
  return null;
}

function ReminderEngine() {
  useEffect(() => {
    const check = () => {
      const native = (window as Window & { BrasaNative?: { notify?: (title: string, body: string) => void } }).BrasaNative;
      const webOk = typeof Notification !== "undefined" && Notification.permission === "granted";
      if (!native?.notify && !webOk) return;
      const { settings } = useBrasa.getState();
      const now = new Date();
      let fired: string[] = [];
      try {
        fired = JSON.parse(localStorage.getItem("brasa-fired") || "[]") as string[];
      } catch {
        fired = [];
      }
      for (const reminder of settings.reminders) {
        if (!reminder.enabled) continue;
        if (!reminder.days.includes(now.getDay())) continue;
        if (now.getHours() !== reminder.hour || now.getMinutes() !== reminder.minute) continue;
        const key = `${reminder.id}-${now.toDateString()}`;
        if (fired.includes(key)) continue;
        fired.push(key);
        localStorage.setItem("brasa-fired", JSON.stringify(fired.slice(-40)));
        const body = reminder.label || (settings.lang === "es" ? "Hora de entrenar" : "Time to train");
        if (native?.notify) native.notify("Brasa", body);
        else new Notification("Brasa", { body });
      }
    };
    check();
    const id = window.setInterval(check, 15000);
    return () => window.clearInterval(id);
  }, []);
  return null;
}

function NavButton({ id, label, icon: Icon, stacked }: { id: (typeof NAV)[number]["id"]; label: string; icon: typeof House; stacked?: boolean }) {
  const screen = useBrasa((state) => state.screen.name);
  const active = screen === id;
  return (
    <button
      type="button"
      onClick={() => useBrasa.getState().go({ name: id })}
      className={cn(
        "relative flex items-center gap-2 rounded-2xl px-3 py-2 text-base font-medium transition active:scale-[0.98]",
        stacked ? "min-w-0 flex-1 flex-col gap-0.5 rounded-2xl px-1 py-1.5 text-xs font-semibold" : "w-full",
        active ? "text-accent" : "text-muted",
      )}
      aria-current={active ? "page" : undefined}
    >
      {active ? <span className="lg-lens absolute inset-0 rounded-2xl" /> : null}
      <Icon className={cn("relative size-5 shrink-0", stacked && "size-6")} strokeWidth={active ? 2.4 : 1.8} />
      <span className={cn("relative", stacked ? "w-full truncate text-center leading-none" : undefined)}>{label}</span>
    </button>
  );
}

function SessionWidget() {
  const { t } = useI18n();
  const run = useBrasa((state) => state.run);
  const screen = useBrasa((state) => state.screen.name);
  const go = useBrasa((state) => state.go);
  const pause = useBrasa((state) => state.pause);
  const resume = useBrasa((state) => state.resume);
  if (!run || screen === "run" || run.phase === "done") return null;
  const step = run.steps[run.index];
  const label = run.phase === "ready" ? t("ready") : step?.name ?? "";
  return (
    <div className="glass-bar fixed inset-x-3 bottom-28 z-40 flex items-center gap-3 rounded-full px-3 py-2 md:bottom-6 md:left-auto md:right-6 md:w-96">
      <button type="button" className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => go({ name: "run" })}>
        <span className="motion-safe:animate-pulse size-2 shrink-0 rounded-full bg-accent" />
        <span className="min-w-0">
          <span className="block text-xs uppercase tracking-widest text-muted">{t("widget")}</span>
          <span className="block truncate font-semibold">{label}</span>
        </span>
        <span className="display ml-auto text-3xl">{formatClock(run.remainingMs)}</span>
      </button>
      <button
        type="button"
        className="h-11 rounded-full px-4 text-sm font-semibold text-onaccent ios-fill"
        onClick={() => {
          if (run.phase === "paused") resume();
          else pause();
          syncBed({ settings: useBrasa.getState().settings, run: useBrasa.getState().run });
        }}
      >
        {run.phase === "paused" ? t("resume") : t("pause")}
      </button>
      <span className="sr-only">{formatClock(trainedMs(run, Date.now()))}</span>
    </div>
  );
}

function FocusWidget() {
  const { t } = useI18n();
  const pomo = useBrasa((state) => state.pomo);
  const screen = useBrasa((state) => state.screen.name);
  const run = useBrasa((state) => state.run);
  const [now, setNow] = useState(0);
  useEffect(() => {
    if (pomo.status !== "running") return undefined;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [pomo.status]);
  if (screen === "focus" || pomo.status === "idle") return null;
  const left = pomo.status === "running" && pomo.endsAt ? Math.max(0, pomo.endsAt - now) : pomo.remainingMs;
  const lifted = Boolean(run && run.phase !== "done" && screen !== "run");
  return (
    <button
      type="button"
      onClick={() => useBrasa.getState().go({ name: "focus" })}
      className={cn(
        "glass-bar fixed inset-x-3 z-40 flex items-center gap-3 rounded-full px-4 py-2 md:left-auto md:right-6 md:w-80",
        lifted ? "bottom-[10.5rem]" : "bottom-28 md:bottom-6",
      )}
    >
      <Timer className="size-4 text-accent" />
      <span className="min-w-0 flex-1 truncate text-left text-sm font-semibold">
        {pomo.phase === "focus" ? t("pomoFocus") : pomo.phase === "long" ? t("pomoLong") : t("pomoShort")}
      </span>
      <span className="display text-3xl">{formatClock(left)}</span>
    </button>
  );
}

function Toast() {
  const toast = useBrasa((state) => state.toast);
  const clear = useBrasa((state) => state.clearToast);
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => {
      if (useBrasa.getState().toast?.id === toast.id) clear();
    }, 2600);
    return () => window.clearTimeout(id);
  }, [toast, clear]);
  if (!toast) return null;
  return (
    <div className="glass-chip fixed bottom-28 left-1/2 z-50 max-w-xs -translate-x-1/2 px-4 py-2 text-center text-sm font-medium text-ink md:bottom-8">
      {toast.text}
    </div>
  );
}

function AndroidBack() {
  useEffect(() => {
    const host = window as Window & { __brasaBack?: () => boolean };
    host.__brasaBack = () => {
      const state = useBrasa.getState();
      if (state.screen.name === "run") {
        state.leaveRun();
        return true;
      }
      if (state.screen.name === "edit") {
        state.go({ name: "library" });
        return true;
      }
      if (state.screen.name !== "home") {
        state.go({ name: "home" });
        return true;
      }
      return false;
    };
    return () => {
      delete host.__brasaBack;
    };
  }, []);
  return null;
}

export function Shell({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const icon = useBrasa((state) => state.settings.appIcon);
  const immersive = useBrasa((state) => state.screen.name === "run");
  useEffect(() => {
    void useBrasa.persist.rehydrate();
  }, []);
  return (
    <div className="ios-app relative min-h-dvh w-full min-w-0 max-w-full overflow-x-hidden text-ink">
      <div className="ios-wallpaper" aria-hidden="true" />
      <BrandSync />
      <RunEngine />
      <PomoEngine />
      <StepEngine />
      <ReminderEngine />
      <AndroidBack />
      <NativeSync />
      <div className="relative z-10 mx-auto flex min-h-dvh w-full min-w-0 max-w-6xl" style={{ paddingTop: "var(--brasa-safe-t, env(safe-area-inset-top, 0px))" }}>
        {!immersive ? (
          <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col p-4 md:flex">
            <div className="glass-bar flex h-full flex-col rounded-[1.75rem] p-4">
            <button type="button" className="mb-8 flex items-center gap-3 px-2 text-left" onClick={() => useBrasa.getState().go({ name: "home" })}>
              <AppMark id={icon} className="size-11" />
              <span>
                <span className="display block text-3xl">Brasa</span>
                <span className="text-xs text-muted">{t("tagline")}</span>
              </span>
            </button>
            <nav className="grid gap-1">
              {NAV.map((item) => (
                <NavButton key={item.id} id={item.id} label={t(item.key)} icon={item.icon} />
              ))}
            </nav>
            </div>
          </aside>
        ) : null}
        <div className="relative flex min-w-0 flex-1 flex-col">
          <main key={useBrasa((s) => s.screen.name)} className={cn("min-w-0 w-full max-w-full flex-1 ios27-rise", !immersive && "pb-32 md:pb-10")}>{children}</main>
          {!immersive ? (
            <nav className="fixed inset-x-3 z-30 md:hidden" style={{ bottom: "max(0.7rem, env(safe-area-inset-bottom, 0px), var(--brasa-safe-b, 0px))" }}>
              <div className="glass-bar ios-dock mx-auto flex max-w-lg items-stretch">
                {NAV.map((item) => (
                  <NavButton key={item.id} id={item.id} label={t(item.key)} icon={item.icon} stacked />
                ))}
              </div>
            </nav>
          ) : null}
          <SessionWidget />
          <FocusWidget />
          <Toast />
        </div>
      </div>
    </div>
  );
}

export function controlRun(action: "pause" | "resume" | "next" | "prev" | "jump", index?: number) {
  const api = useBrasa.getState();
  if (action === "pause") {
    api.pause();
    syncBed({ settings: api.settings, run: useBrasa.getState().run });
    return;
  }
  if (action === "resume") {
    api.resume();
    syncBed({ settings: useBrasa.getState().settings, run: useBrasa.getState().run });
    return;
  }
  if (action === "next") hear(api.next());
  if (action === "prev") hear(api.prev());
  if (action === "jump" && index != null) hear(api.jump(index));
}
