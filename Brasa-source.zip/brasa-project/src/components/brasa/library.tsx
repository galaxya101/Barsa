import { useMemo, useState } from "react";
import { Copy, Pencil, Play, Plus, Search, Star, Trash2, Upload } from "lucide-react";
import { beginWorkout } from "@/lib/brasa/launch";
import { flatten, formatSpan } from "@/lib/brasa/engine";
import { categoryLabel } from "@/lib/brasa/i18n";
import { useBrasa } from "@/lib/brasa/store";
import { CATEGORIES } from "@/lib/brasa/types";
import { downloadJson, readJson } from "./download";
import { FILL, GhostButton, Modal, useI18n } from "./ui";

export function Library() {
  const { t, lang } = useI18n();
  const workouts = useBrasa((state) => state.workouts);
  const custom = useBrasa((state) => state.customCategories);
  const go = useBrasa((state) => state.go);
  const create = useBrasa((state) => state.createWorkout);
  const duplicate = useBrasa((state) => state.duplicateWorkout);
  const remove = useBrasa((state) => state.deleteWorkout);
  const favorite = useBrasa((state) => state.toggleFavorite);
  const restore = useBrasa((state) => state.restoreSamples);
  const importWorkout = useBrasa((state) => state.importWorkout);
  const toastTo = useBrasa((state) => state.toastTo);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  const categories = useMemo(() => {
    const extra = new Set<string>(custom);
    for (const workout of workouts) {
      if (!CATEGORIES.includes(workout.category as (typeof CATEGORIES)[number])) extra.add(workout.category);
    }
    return [...CATEGORIES, ...extra];
  }, [custom, workouts]);

  const visible = workouts.filter((workout) => {
    if (filter === "fav" && !workout.favorite) return false;
    if (filter !== "all" && filter !== "fav" && workout.category !== filter) return false;
    const hay = `${workout.name} ${workout.description} ${workout.blocks.flatMap((block) => block.intervals.map((item) => item.name)).join(" ")}`.toLocaleLowerCase();
    return hay.includes(query.trim().toLocaleLowerCase());
  });

  const missingSamples = !["tabata", "full", "emom", "box", "mob", "core", "ladder"].every((id) => workouts.some((workout) => workout.builtinId === id));

  return (
    <div className="mx-auto w-full min-w-0 max-w-full px-4 py-6 md:max-w-5xl md:px-8 md:py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="display text-5xl">{t("library")}</h1>
          <p className="mt-2 text-muted">{t("tagline")}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {missingSamples ? <GhostButton onClick={restore}>{t("restore")}</GhostButton> : null}
          <label className="inline-flex h-12 cursor-pointer items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm font-semibold">
            <Upload className="size-4" />
            {t("importOne")}
            <input
              type="file"
              accept=".json,application/json,text/json"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                void readJson(file)
                  .then((data) => {
                    const record = data as { app?: string; workout?: unknown };
                    const ok = record?.app === "brasa-workout" ? importWorkout(record.workout) : importWorkout(data);
                    if (!ok) toastTo(t("importBad"));
                  })
                  .catch(() => toastTo(t("importBad")));
              }}
            />
          </label>
          <GhostButton onClick={() => create()}>
            <Plus className="size-4" />
            {t("create")}
          </GhostButton>
        </div>
      </div>

      <label className="mt-5 flex items-center gap-2">
        <span className="sr-only">{t("search")}</span>
        <span className="panel flex h-12 w-full items-center gap-2 px-3">
          <Search className="size-4 text-muted" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("search")} className="h-full w-full bg-transparent outline-none" />
        </span>
      </label>

      <div className="mt-3 flex w-full min-w-0 max-w-full gap-2 overscroll-x-contain overflow-x-auto pb-1">
        {[["all", t("all")], ["fav", t("favFilter")], ...categories.map((id) => [id, categoryLabel(lang, id)] as const)].map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={`h-10 shrink-0 rounded-full px-4 text-sm font-semibold ${filter === id ? "bg-accent text-onaccent" : "border border-line bg-surface text-ink"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="panel mt-5 p-6">
          <p className="text-lg font-semibold">{t("emptyLibrary")}</p>
          <div className="mt-4 max-w-xs">
            <GhostButton onClick={() => create()}>{t("create")}</GhostButton>
          </div>
        </div>
      ) : (
        <ul className="mt-5 grid gap-3 md:grid-cols-2">
          {visible.map((workout) => {
            const steps = flatten(workout);
            const total = steps.reduce((sum, step) => sum + step.seconds, 0);
            const color = steps[0]?.color ?? "ember";
            return (
              <li key={workout.id} className="panel flex gap-3 p-4">
                <span className={`mt-1 w-1.5 shrink-0 self-stretch rounded-full ${FILL[color]}`} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs uppercase tracking-widest text-muted">{categoryLabel(lang, workout.category)}</p>
                      <h2 className="truncate text-xl font-semibold">{workout.name}</h2>
                    </div>
                    <button type="button" aria-label={t("favorites")} className="grid size-11 place-items-center" onClick={() => favorite(workout.id)}>
                      <Star className={workout.favorite ? "size-5 fill-accent text-accent" : "size-5 text-muted"} />
                    </button>
                  </div>
                  <p className="mt-1 text-sm text-muted">
                    {formatSpan(total)} · {workout.blocks.length} {t("blocks")}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" className="inline-flex h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm font-semibold text-onaccent" onClick={() => beginWorkout(workout.id)}>
                      <Play className="size-4 fill-current" />
                      {t("start")}
                    </button>
                    <button type="button" className="inline-flex h-11 items-center gap-2 rounded-full border border-line px-3 text-sm font-semibold" onClick={() => { useBrasa.setState({ editReturn: "library" }); go({ name: "edit", id: workout.id }); }}>
                      <Pencil className="size-4" />
                      {t("edit")}
                    </button>
                    <button type="button" aria-label={t("duplicate")} className="grid size-11 place-items-center rounded-full border border-line" onClick={() => duplicate(workout.id)}>
                      <Copy className="size-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={t("delete")}
                      className="grid size-11 place-items-center rounded-full border border-line"
                      onClick={() => setPendingDelete(workout.id)}
                    >
                      <Trash2 className="size-4" />
                    </button>
                    <button
                      type="button"
                      className="h-11 rounded-full px-2 text-sm font-semibold text-muted"
                      onClick={() => {
                        void downloadJson(`${workout.name}.json`, { app: "brasa-workout", workout }).then((result) => {
                          if (result !== "cancelled") toastTo(t("fileReady"));
                        });
                      }}
                    >
                      JSON
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {pendingDelete ? (
        <Modal title={t("confirmDelete")} onClose={() => setPendingDelete(null)}>
          <button type="button" className="h-12 rounded-full bg-danger text-canvas font-semibold" onClick={() => { remove(pendingDelete); setPendingDelete(null); }}>
            {t("yesDelete")}
          </button>
          <button type="button" className="h-12 rounded-full border border-line font-semibold" onClick={() => setPendingDelete(null)}>
            {t("cancel")}
          </button>
        </Modal>
      ) : null}
    </div>
  );
}
