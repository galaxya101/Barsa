import assert from "node:assert/strict";
import test from "node:test";
import { csvContent, readJson } from "./download.ts";

test("CSV quotes commas, quotes, and line breaks", () => {
  const csv = csvContent(["name", "note"], [["Intervals, HIIT", 'said "go"\nnow']]);
  assert.equal(csv, '\uFEFF"name","note"\r\n"Intervals, HIIT","said ""go""\nnow"');
});

test("CSV leaves empty values as empty cells", () => {
  assert.equal(csvContent(["date", "note"], [["2026-11-11", null]]), '\uFEFF"date","note"\r\n"2026-11-11",""');
});

test("imports a JSON file", async () => {
  const file = new File(['{"app":"brasa"}'], "backup.json", { type: "application/json" });
  assert.deepEqual(await readJson(file), { app: "brasa" });
});
