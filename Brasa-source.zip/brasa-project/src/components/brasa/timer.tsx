import { useEffect, useState } from "react";
import { Minus, Pause, Play, Plus, SkipBack, SkipForward, Square, X } from "lucide-react";
import { requestWakeLock } from "@/lib/brasa/audio";
import { cueSecond, formatClock, plannedSeconds, trainedMs } from "@/lib/brasa/engine";
import { kindLabel } from "@/lib/brasa/i18n";
import { useBrasa } from "@/lib/brasa/store";
import { emptyNotes } from "@/lib/brasa/types";
import { stopAudio } from "@/lib/brasa/audio";
import { FILL, INK, Modal, STROKE, useI18n } from "./ui";
import { controlRun } from "./shell";

export function TimerScreen() {
  const { t, lang } = useI18n();
  const run = useBrasa((state) => state.run);
  const settings = useBrasa((state) => state.settings);
  const leave = useBrasa((state) => state.leaveRun);
  const toastTo = useBrasa((state) => state.toastTo);
  const updateLog = useBrasa((state) => state.updateLog);
  const dismiss = useBrasa((state) => state.dismissSummary);
  const savePartial = useBrasa((state) => state.savePartial);
  const discard = useBrasa((state) => state.discardRun);
  const [, setFrame] = useState(0);
  const [stopOpen, setStopOpen] = useState(false);
  const [rpe, setRpe] = useState<number | null>(null);
  const [note, setNote] = useState("");

  useEffect(() => {
    const id = window.setInterval(() => setFrame((value) => value + 1), 200);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!run || !settings.keepAwake) return;
    if (run.phase !== "running" && run.phase !== "ready") return;
    let lock: { release: () => Promise<unknown> } | null = null;
    let alive = true;
    void requestWakeLock().then((sentinel) => {
      if (!alive) void sentinel?.release();
      else lock = sentinel;
    });
    return () => {
      alive = false;
      void lock?.release();
    };
  }, [run?.phase, settings.keepAwake, toastTo, t]);

  useEffect(() => {
    if (!run || run.phase !== "done" || !run.sessionId) return;
    const session = useBrasa.getState().sessions.find((item) => item.id === run.sessionId);
    if (!session) return;
    setRpe(session.rpe);
    setNote(session.note);
  }, [run?.phase, run?.sessionId]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (event.code === "Space") {
        event.preventDefault();
        const phase = useBrasa.getState().run?.phase;
        if (phase === "paused") controlRun("resume");
        else if (phase === "running" || phase === "ready") controlRun("pause");
      }
      if (event.code === "ArrowRight") controlRun("next");
      if (event.code === "ArrowLeft") controlRun("prev");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (!run) {
    return (
      <div className="grid min-h-dvh w-full min-w-0 place-items-center p-6">
        <button type="button" className="text-accent" onClick={() => useBrasa.getState().go({ name: "home" })}>
          {t("home")}
        </button>
      </div>
    );
  }

  const now = Date.now();
  const step = run.steps[run.index];
  const color = run.phase === "ready" ? "gold" : step?.color ?? "ember";
  const remaining = run.phase === "paused" || run.phase === "done" ? run.remainingMs : Math.max(0, (run.segmentEndsAt ?? now) - now);
  const cue = cueSecond({ ...run, remainingMs: remaining }, settings.countdown);
  const title = run.phase === "ready" ? t("ready") : step ? kindLabel(lang, step.kind) : "";
  const name = run.phase === "ready" ? run.steps[0]?.name ?? run.workoutName : step?.name ?? "";
  const next = run.phase === "ready" ? run.steps[0] : run.steps[run.index + 1];
  const elapsed = trainedMs({ ...run, remainingMs: remaining, segmentEndsAt: run.phase === "paused" ? null : run.segmentEndsAt }, now);
  const total = plannedSeconds(run.steps) * 1000;
  const radius = 46;
  const circ = 2 * Math.PI * radius;
  const fraction = run.segmentDurationMs > 0 ? Math.max(0, Math.min(1, remaining / run.segmentDurationMs)) : 0;
  const workoutProgress = total > 0 ? Math.max(0, Math.min(1, elapsed / total)) : 0;
  const cueStep = run.phase === "ready" ? run.steps[0] : step;
  const noted = cueStep?.notes ?? emptyNotes();
  const notes = cueStep
    ? [
        noted.speed && `${t("speed")} ${noted.speed}`,
        noted.incline && `${t("incline")} ${noted.incline}`,
        noted.resistance && `${t("resistance")} ${noted.resistance}`,
        noted.difficulty && `${t("difficulty")} ${noted.difficulty}`,
        noted.custom,
      ].filter((item): item is string => Boolean(item))
    : [];
  const instruction = cueStep?.instruction?.trim() ?? "";

  const exit = () => {
    if (run.phase === "running" || run.phase === "ready" || run.phase === "paused") toastTo(t("leaveRunning"));
    leave();
  };

  return (
    <div className={`stage-${color} min-h-dvh w-full overflow-x-hidden`}>
      <div className="mx-auto flex min-h-dvh w-full min-w-0 max-w-full flex-col gap-3 px-4 py-3 md:max-w-xl" style={{ paddingTop: "max(0.75rem, var(--brasa-safe-t, env(safe-area-inset-top, 0px)))", paddingBottom: "max(0.75rem, env(safe-area-inset-bottom, 0px), var(--brasa-safe-b, 0px))" }}>
        <div className="flex items-center gap-3">
          <button type="button" aria-label={t("back")} className="glass-chip grid size-12 place-items-center rounded-full" onClick={exit}>
            <X className="size-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{run.workoutName}</p>
            <p className="text-xs text-muted">
              {t("elapsed")} {formatClock(elapsed)}
            </p>
          </div>
          {run.phase === "paused" ? <span className="glass-chip rounded-full px-3 py-1 text-sm font-semibold">{t("paused")}</span> : null}
        </div>

        <section className="panel grid flex-1 content-center gap-3 px-4 py-5 sm:px-6" aria-label={t("currentInterval")}>
          <div className="flex items-center justify-between gap-3">
            <span className={`rounded-full bg-raised px-3 py-1 text-sm font-semibold ${INK[color]}`}>{title}</span>
            <span className="text-sm font-semibold tabular-nums text-muted">
              {run.index + (run.phase === "ready" ? 0 : 1)} / {run.steps.length}
            </span>
          </div>
          {cue ? (
            <p key={cue} className="cue-pop display text-center text-4xl text-accent">
              {cue}
            </p>
          ) : null}
          <div className="relative mx-auto grid w-full place-items-center">
            <svg viewBox="0 0 120 120" className="w-[min(58vw,15rem)]">
              <circle cx="60" cy="60" r={radius} className="stroke-line" strokeWidth="6" fill="none" />
              <circle
                cx="60"
                cy="60"
                r={radius}
                className={STROKE[color]}
                strokeWidth="6"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={circ}
                strokeDashoffset={circ * (1 - fraction)}
                transform="rotate(-90 60 60)"
              />
            </svg>
            <div className="absolute inset-0 grid place-items-center">
              <h1 className="timer-digits">{formatClock(remaining)}</h1>
            </div>
          </div>
          <p className="sr-only" aria-live="polite">
            {title}. {name}. {formatClock(remaining)}
          </p>
          <div className="text-center">
            <h2 className="display max-w-full truncate text-3xl sm:text-4xl">{name}</h2>
            {step && run.phase !== "ready" ? (
              <p className="mt-2 text-sm text-muted">
                {t("round")} {step.round} {t("of")} {step.rounds}
                {step.blockName ? ` · ${step.blockName}` : ""}
              </p>
            ) : null}
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-raised" role="progressbar" aria-label={t("workoutProgress")} aria-valuenow={Math.round(workoutProgress * 100)} aria-valuemin={0} aria-valuemax={100}>
            <div className="h-full rounded-full bg-accent transition-[width] duration-200" style={{ width: `${workoutProgress * 100}%` }} />
          </div>
        </section>

        <div className="shrink-0">
          {instruction || notes.length ? (
            <section className="panel mx-auto mb-3 w-full max-w-md px-4 py-3">
              <p className="text-xs font-semibold text-muted">{t("cues")}</p>
              {instruction ? <p className="mt-1 text-base font-medium text-balance">{instruction}</p> : null}
              {notes.length ? (
                <div className="mt-2 flex flex-wrap gap-2">
                  {notes.map((item) => (
                    <span key={item} className="rounded-full bg-raised px-3 py-1 text-sm font-medium">
                      {item}
                    </span>
                  ))}
                </div>
              ) : null}
            </section>
          ) : null}
          <section className="panel mx-auto mb-3 w-full max-w-md px-4 py-3">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted">{t("next")}</p>
            <p className="mt-1 truncate font-semibold">{next ? (next.kind === "rest" ? t("rest") : next.name) : t("noneNext")}</p>
          </section>
          <div className="mt-3 flex h-12 items-end gap-1 overflow-x-auto" aria-label={t("timeline")}>
            {run.steps.map((item, index) => (
              <button
                key={item.key}
                type="button"
                aria-label={`${t("jump")} ${item.name}`}
                onClick={() => controlRun("jump", index)}
                className={`h-full shrink-0 rounded-md ${FILL[item.color]} ${index === run.index && run.phase !== "ready" ? "opacity-100" : "opacity-45"}`}
                style={{ width: Math.max(10, item.seconds / 3) }}
              />
            ))}
          </div>
          <p className="mt-2 text-center text-xs text-muted">
            {t("remaining")} {formatClock(Math.max(0, total - elapsed))}
            {settings.metronomeBpm ? ` · ${settings.metronomeBpm} bpm` : ""}
          </p>
        </div>

        <div className="grid grid-cols-5 items-center gap-2 pb-1">
          <button type="button" aria-label={t("previous")} className="glass-chip grid size-14 place-items-center rounded-full" onClick={() => controlRun("prev")}>
            <SkipBack className="size-5" />
          </button>
          <button type="button" aria-label={t("minus")} className="glass-chip flex size-14 flex-col items-center justify-center gap-0.5 rounded-full" onClick={() => useBrasa.getState().nudgeRun(-15_000)}>
            <Minus className="size-4" />
            <span className="text-[10px] font-semibold leading-none">15 s</span>
          </button>
          <button
            type="button"
            data-testid="timer-toggle"
            aria-label={run.phase === "paused" ? t("resume") : t("pause")}
            className="grid size-20 place-items-center justify-self-center rounded-full bg-accent text-onaccent"
            onClick={() => {
              if (run.phase === "done") return;
              if (run.phase === "paused") controlRun("resume");
              else controlRun("pause");
            }}
          >
            {run.phase === "paused" ? <Play className="size-8 fill-current" /> : <Pause className="size-8" />}
          </button>
          <button type="button" aria-label={t("plus")} className="glass-chip flex size-14 flex-col items-center justify-center gap-0.5 rounded-full" onClick={() => useBrasa.getState().nudgeRun(15_000)}>
            <Plus className="size-4" />
            <span className="text-[10px] font-semibold leading-none">15 s</span>
          </button>
          <button type="button" aria-label={t("next")} className="glass-chip grid size-14 place-items-center rounded-full" onClick={() => controlRun("next")}>
            <SkipForward className="size-5" />
          </button>
        </div>
        <button type="button" className="mx-auto mb-2 inline-flex h-12 items-center gap-2 rounded-full px-4 text-sm font-semibold text-danger" onClick={() => setStopOpen(true)}>
          <Square className="size-4 fill-current" />
          {t("stop")}
        </button>
      </div>

      {stopOpen ? (
        <Modal title={t("stopTitle")} body={t("stopBody")} onClose={() => setStopOpen(false)}>
          <button
            type="button"
            className="h-12 rounded-full bg-accent font-semibold text-onaccent"
            onClick={() => {
              stopAudio();
              setStopOpen(false);
              savePartial();
            }}
          >
            {t("savePartial")}
          </button>
          <button type="button" className="h-12 rounded-full border border-line font-semibold" onClick={() => setStopOpen(false)}>
            {t("continue")}
          </button>
          <button
            type="button"
            className="h-12 rounded-full font-semibold text-danger"
            onClick={() => {
              stopAudio();
              discard();
            }}
          >
            {t("discard")}
          </button>
        </Modal>
      ) : null}

      {run.phase === "done" ? (
        <Modal title={t("doneTitle")} body={t("doneBody")} onClose={() => {}}>
          <p className="text-center text-lg font-semibold">
            {formatClock(run.completedMs)} · {run.workoutName}
          </p>
          <div className="mt-2">
            <p className="mb-2 text-base font-semibold">{t("rpe")}</p>
            <div className="grid grid-cols-5 gap-2">
              {Array.from({ length: 10 }, (_, index) => index + 1).map((level) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setRpe(level)}
                  className={`grid h-12 place-items-center rounded-xl text-lg font-bold ${rpe === level ? "bg-accent text-onaccent" : "border-2 border-line bg-surface"}`}
                >
                  {level}
                </button>
              ))}
            </div>
            <p className="mt-1 text-center text-xs text-muted">1 = muy fácil · 10 = máximo</p>
          </div>
          <label className="mt-2">
            <span className="text-sm text-muted">{t("note")}</span>
            <textarea className="field mt-1" placeholder={t("notePh")} value={note} onChange={(event) => setNote(event.target.value)} />
          </label>
          <button
            type="button"
            className="h-12 rounded-full bg-accent font-semibold text-onaccent"
            onClick={() => {
              updateLog({ rpe, note });
              stopAudio();
              dismiss();
            }}
          >
            {t("saveExit")}
          </button>
          <button
            type="button"
            className="h-12 font-semibold text-danger"
            onClick={() => {
              stopAudio();
              discard();
            }}
          >
            {t("dropSession")}
          </button>
        </Modal>
      ) : null}
    </div>
  );
}
