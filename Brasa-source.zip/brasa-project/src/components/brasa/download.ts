type NativeFileBridge = {
  saveFile?: (filename: string, mimeType: string, content: string) => boolean;
};

export type DownloadResult = "native" | "shared" | "downloaded" | "cancelled";

async function saveFile(filename: string, content: string, mimeType: string): Promise<DownloadResult> {
  const safeName = filename.replace(/[^\w.\-]+/g, "-");
  const native = typeof window === "undefined" ? undefined : (window as Window & { BrasaNative?: NativeFileBridge }).BrasaNative;
  try {
    if (native?.saveFile?.(safeName, mimeType, content)) return "native";
  } catch {
    // Continue to a browser fallback when an older native wrapper rejects this call.
  }

  const blob = new Blob([content], { type: mimeType });
  if (typeof navigator !== "undefined" && typeof navigator.share === "function" && typeof File !== "undefined") {
    try {
      const file = new File([blob], safeName, { type: mimeType });
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: safeName });
        return "shared";
      }
    } catch (error) {
      if (typeof DOMException !== "undefined" && error instanceof DOMException && error.name === "AbortError") return "cancelled";
      // A browser that advertises sharing but cannot complete it still gets the download fallback.
    }
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = safeName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  return "downloaded";
}

export function downloadJson(filename: string, data: unknown): Promise<DownloadResult> {
  return saveFile(filename, JSON.stringify(data, null, 2), "application/json;charset=utf-8");
}

function csvCell(value: string | number | null | undefined): string {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

export function csvContent(headers: string[], rows: (string | number | null | undefined)[][]): string {
  return `\uFEFF${[headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n")}`;
}

export function downloadCsv(filename: string, headers: string[], rows: (string | number | null | undefined)[][]): Promise<DownloadResult> {
  return saveFile(filename, csvContent(headers, rows), "text/csv;charset=utf-8");
}

export async function readJson(file: File): Promise<unknown> {
  const text = typeof file.text === "function" ? await file.text() : await readFileText(file);
  return JSON.parse(text) as unknown;
}

function readFileText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => (typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Archivo vacío")));
    reader.onerror = () => reject(reader.error ?? new Error("No se pudo leer el archivo"));
    reader.readAsText(file);
  });
}
