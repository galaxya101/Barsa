import { useEffect, useState } from "react";
import { widgetPayload } from "@/lib/brasa/native";
import { useBrasa } from "@/lib/brasa/store";
import { useI18n } from "./ui";

export function WidgetCard() {
  const { lang } = useI18n();
  const run = useBrasa((state) => state.run);
  const sessions = useBrasa((state) => state.sessions);
  const theme = useBrasa((state) => state.settings.theme);
  const [now, setNow] = useState(() => Date.now());
  const live = Boolean(run && run.phase !== "done" && run.phase !== "paused");
  useEffect(() => {
    if (!live) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [live, run?.segmentEndsAt, run?.index]);
  const data = widgetPayload(lang, run, sessions);
  const remain =
    data.active && run
      ? run.phase === "paused"
        ? run.remainingMs
        : Math.max(0, (run.segmentEndsAt ?? now) - now)
      : 0;
  const hero = data.active ? format(remain) : data.hero;
  const press = () => {
    const api = useBrasa.getState();
    if (!data.active) {
      api.go(api.run && api.run.phase !== "done" ? { name: "run" } : { name: "home" });
      return;
    }
    if (data.action === "resume") api.resume();
    else if (data.action === "pause") api.pause();
    else api.go({ name: "run" });
  };
  return (
    <div data-theme={theme} data-testid="widget-preview" className="rounded-[22px] bg-surface p-4 text-ink shadow-sm">
      <div className="h-1 w-7 rounded-full bg-accent" />
      <p className="mt-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">{data.kicker}</p>
      <p className="display mt-1 text-5xl tabular-nums">{hero}</p>
      <p className="truncate text-base font-semibold">{data.title}</p>
      <p className="truncate text-sm text-muted">{data.detail}</p>
      <button type="button" onClick={press} className="mt-3 inline-flex h-8 items-center rounded-full bg-accent px-3 text-sm font-semibold text-onaccent">
        {data.actionLabel}
      </button>
    </div>
  );
}

function format(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}
