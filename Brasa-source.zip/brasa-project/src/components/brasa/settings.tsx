import { useRef, useState } from "react";
import { AppMark } from "@/lib/brasa/icons";
import { pingNotification, previewAmbience, previewSound, previewVoice, unlockAudio } from "@/lib/brasa/audio";
import { brasaNative, setNativeIcon } from "@/lib/brasa/native";
import { resolveReminderLabel } from "@/lib/brasa/reminders";
import { useBrasa } from "@/lib/brasa/store";
import { APP_ICONS, THEME_HEX, THEMES, type AmbienceKind, type Reminder, type SoundPack, type ThemeId } from "@/lib/brasa/types";
import { uid } from "@/lib/utils";
import { appIconLabel, t as translate, type Key } from "@/lib/brasa/i18n";
import { downloadCsv, downloadJson, readJson } from "./download";
import { useI18n } from "./ui";
import { WidgetCard } from "./widget-card";

const THEME_KEYS: Record<ThemeId, Key> = {
  carbon: "carbon",
  dawn: "dawn",
  tide: "tide",
  bone: "bone",
};

const PACKS: SoundPack[] = ["bell", "click", "wood", "soft"];
const BEDS: AmbienceKind[] = ["rain", "ocean", "ember", "night", "pulse"];
const BED_KEY: Record<AmbienceKind, "bedRain" | "bedOcean" | "bedEmber" | "bedNight" | "bedPulse"> = {
  rain: "bedRain",
  ocean: "bedOcean",
  ember: "bedEmber",
  night: "bedNight",
  pulse: "bedPulse",
};

export function Settings() {
  const { t, lang } = useI18n();
  const settings = useBrasa((state) => state.settings);
  const sessions = useBrasa((state) => state.sessions);
  const patch = useBrasa((state) => state.patchSettings);
  const setTheme = useBrasa((state) => state.setTheme);
  const setLang = useBrasa((state) => state.setLang);
  const toastTo = useBrasa((state) => state.toastTo);
  const exportBackup = useBrasa((state) => state.exportBackup);
  const importBackup = useBrasa((state) => state.importBackup);
  const importWorkout = useBrasa((state) => state.importWorkout);
  const fileRef = useRef<HTMLInputElement>(null);
  const [hour, setHour] = useState(18);
  const [minute, setMinute] = useState(0);
  const [days, setDays] = useState<number[]>([1, 2, 3, 4, 5]);
  const [label, setLabel] = useState("");
  const reminderLabel = resolveReminderLabel(label, t("reminderDefault"));

  const addReminder = async () => {
    await pingNotification(reminderLabel);
    const reminder: Reminder = {
      id: uid(),
      label: reminderLabel,
      hour,
      minute,
      days,
      enabled: true,
    };
    patch({ reminders: [...settings.reminders, reminder] });
    setLabel("");
  };

  return (
    <div className="mx-auto grid w-full min-w-0 max-w-full grid-cols-1 gap-4 px-4 py-6 md:max-w-3xl md:px-8 md:py-8">
      <h1 className="display text-5xl">{t("settings")}</h1>

      <section className="panel p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("language")}</h2>
        <div className="mt-3 grid grid-cols-2 gap-2">
          {(["es", "en"] as const).map((code) => (
            <button key={code} type="button" onClick={() => setLang(code)} className={`h-12 rounded-full font-semibold ${settings.lang === code ? "bg-accent text-onaccent" : "border border-line"}`}>
              {code === "es" ? "Español" : "English"}
            </button>
          ))}
        </div>
      </section>

      <section className="panel p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("theme")}</h2>
        <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">
          {THEMES.map((theme) => (
            <button key={theme} type="button" onClick={() => setTheme(theme)} className={`rounded-2xl border p-3 text-left ${settings.theme === theme ? "border-accent" : "border-line"}`}>
              <span className="mb-3 flex gap-1" aria-hidden="true">
                <span className="size-4 rounded-full ring-1 ring-line" style={{ background: THEME_HEX[theme].canvas }} />
                <span className="size-4 rounded-full" style={{ background: THEME_HEX[theme].accent }} />
              </span>
              <span className="text-sm font-semibold">{t(THEME_KEYS[theme])}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="panel p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("icon")}</h2>
        <p className="mt-2 text-sm text-muted">{t("iconHelp")}</p>
        <div className="mt-4 grid gap-4 md:grid-cols-[180px_1fr]">
          <div className="rounded-3xl border border-line bg-raised p-4">
            <p className="text-center text-xs uppercase tracking-widest text-muted">{t("launcher")}</p>
            <div className="mx-auto mt-3 w-28 rounded-[1.4rem] border border-line bg-canvas px-3 py-5 text-center">
              <AppMark id={settings.appIcon} className="mx-auto size-16" />
              <p className="mt-2 text-sm font-semibold">{appIconLabel(lang, settings.appIcon)}</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {APP_ICONS.map((icon) => (
              <button
                key={icon}
                type="button"
                onClick={() => {
                  patch({ appIcon: icon });
                  if (!brasaNative()?.setIcon) return;
                  toastTo(setNativeIcon(icon, settings.theme) ? t("iconApplied") : t("iconFailed"));
                }}
                className={`rounded-2xl border p-2 ${settings.appIcon === icon ? "border-accent" : "border-line"}`}
              >
                <AppMark id={icon} className="mx-auto size-14" />
                <span className="mt-1 block text-center text-xs font-semibold">{appIconLabel(lang, icon)}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="panel p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("homeWidget")}</h2>
        <p className="mt-2 text-sm text-muted">{t("widgetHint")}</p>
        <div className="mt-4 max-w-sm">
          <WidgetCard />
        </div>
        <button
          type="button"
          data-testid="pin-widget"
          className="mt-4 h-12 rounded-full bg-accent px-5 font-semibold text-onaccent"
          onClick={() => {
            const bridge = brasaNative();
            toastTo(bridge?.pinWidget?.() ? t("pinWidgetOk") : t("pinWidgetManual"));
          }}
        >
          {t("pinWidget")}
        </button>
      </section>

      <section className="panel grid gap-3 p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("sound")}</h2>
        <Toggle label={t("sound")} checked={settings.soundEnabled} onChange={(soundEnabled) => patch({ soundEnabled })} />
        <div className="flex flex-wrap gap-2">
          {PACKS.map((pack) => (
            <button key={pack} type="button" onClick={() => patch({ soundPack: pack })} className={`h-10 rounded-full px-3 text-sm font-semibold ${settings.soundPack === pack ? "bg-accent text-onaccent" : "border border-line"}`}>
              {t(pack)}
            </button>
          ))}
        </div>
        <label className="text-sm text-muted">
          {t("volume")}
          <input type="range" min={0} max={1} step={0.05} value={settings.soundVolume} onChange={(event) => patch({ soundVolume: Number(event.target.value) })} />
        </label>
        <button type="button" className="h-11 rounded-full border border-line font-semibold" onClick={() => { unlockAudio(); previewSound(settings); }}>
          {t("previewSound")}
        </button>
        <label className="text-sm text-muted">
          {t("metro")}
          <select className="field mt-1" value={settings.metronomeBpm} onChange={(event) => patch({ metronomeBpm: Number(event.target.value) })}>
            {[0, 60, 80, 100, 120, 140, 160].map((bpm) => (
              <option key={bpm} value={bpm}>{bpm === 0 ? t("metroOff") : `${bpm} bpm`}</option>
            ))}
          </select>
        </label>
        <Toggle label={t("ambience")} checked={settings.ambience} onChange={(ambience) => patch({ ambience })} />
        <p className="text-sm text-muted">{t("ambienceHelp")}</p>
        <p className="text-sm text-muted">{t("ambienceStyle")}</p>
        <div className="flex flex-wrap gap-2">
          {BEDS.map((kind) => (
            <button
              key={kind}
              type="button"
              onClick={() => {
                const next = { ...settings, ambienceKind: kind, ambience: true };
                patch({ ambienceKind: kind, ambience: true });
                previewAmbience(next);
              }}
              className={`h-10 rounded-full px-3 text-sm font-semibold ${settings.ambienceKind === kind ? "bg-accent text-onaccent" : "border border-line"}`}
            >
              {t(BED_KEY[kind])}
            </button>
          ))}
        </div>
        <button type="button" className="h-11 rounded-full border border-line font-semibold" onClick={() => previewAmbience({ ...settings, ambience: true })}>
          {t("previewAmbience")}
        </button>
        <label className="text-sm text-muted">
          {t("volume")}
          <input type="range" min={0} max={1} step={0.05} value={settings.ambienceVolume} onChange={(event) => patch({ ambienceVolume: Number(event.target.value) })} />
        </label>
        <Toggle label={t("duck")} checked={settings.ducking} onChange={(ducking) => patch({ ducking })} />
      </section>

      <section className="panel grid gap-3 p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("voice")}</h2>
        <Toggle label={t("voice")} checked={settings.voiceEnabled} onChange={(voiceEnabled) => patch({ voiceEnabled })} />
        <div className="flex flex-wrap gap-2">
          {(["energetic", "calm", "minimal"] as const).map((style) => (
            <button key={style} type="button" onClick={() => patch({ voiceStyle: style })} className={`h-10 rounded-full px-3 text-sm font-semibold ${settings.voiceStyle === style ? "bg-accent text-onaccent" : "border border-line"}`}>
              {t(style)}
            </button>
          ))}
        </div>
        <label className="text-sm text-muted">
          {t("voiceVolume")}
          <input type="range" min={0} max={1} step={0.05} value={settings.voiceVolume} onChange={(event) => patch({ voiceVolume: Number(event.target.value) })} />
        </label>
        <button type="button" className="h-11 rounded-full border border-line font-semibold" onClick={() => { unlockAudio(); previewVoice(settings); }}>
          {t("testVoice")}
        </button>
        <Toggle label={t("countdown")} checked={settings.countdown} onChange={(countdown) => patch({ countdown })} />
        <Toggle label={t("announceNext")} checked={settings.announceNext} onChange={(announceNext) => patch({ announceNext })} />
        <label className="text-sm text-muted">
          {t("getReady")}
          <select className="field mt-1" value={settings.getReadySeconds} onChange={(event) => patch({ getReadySeconds: Number(event.target.value) })}>
            {[0, 3, 5, 10, 15].map((seconds) => (
              <option key={seconds} value={seconds}>{seconds === 0 ? t("off") : `${seconds} s`}</option>
            ))}
          </select>
        </label>
      </section>

      <section className="panel grid gap-3 p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("access")}</h2>
        <Toggle label={t("vibration")} checked={settings.vibration} onChange={(vibration) => patch({ vibration })} />
        <Toggle label={t("wake")} checked={settings.keepAwake} onChange={(keepAwake) => patch({ keepAwake })} />
        <Toggle label={t("largeText")} checked={settings.largeText} onChange={(largeText) => patch({ largeText })} />
      </section>

      <section className="panel grid gap-3 p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("reminders")}</h2>
        <p className="text-sm text-muted">{t("reminderHelp")}</p>
        {settings.reminders.map((reminder) => (
          <div key={reminder.id} className="flex items-center justify-between gap-2 rounded-2xl border border-line px-3 py-2">
            <div>
              <p className="font-semibold">{reminder.label}</p>
              <p className="text-sm text-muted">
                {String(reminder.hour).padStart(2, "0")}:{String(reminder.minute).padStart(2, "0")} · {reminder.days.map((day) => translate(lang, dayKey(day))).join(" ")}
              </p>
            </div>
            <button type="button" className="text-sm font-semibold text-accent" onClick={() => patch({ reminders: settings.reminders.map((item) => item.id === reminder.id ? { ...item, enabled: !item.enabled } : item) })}>
              {reminder.enabled ? "ON" : "OFF"}
            </button>
            <button type="button" className="text-sm text-danger" onClick={() => patch({ reminders: settings.reminders.filter((item) => item.id !== reminder.id) })}>
              {t("delete")}
            </button>
          </div>
        ))}
        <div className="grid grid-cols-2 gap-2">
          <input className="field" inputMode="numeric" value={hour} onChange={(event) => setHour(Math.max(0, Math.min(23, Number(event.target.value) || 0)))} aria-label="hour" />
          <input className="field" inputMode="numeric" value={minute} onChange={(event) => setMinute(Math.max(0, Math.min(59, Number(event.target.value) || 0)))} aria-label="minute" />
        </div>
        <div className="flex flex-wrap gap-1">
          {[1, 2, 3, 4, 5, 6, 0].map((day) => (
            <button
              key={day}
              type="button"
              onClick={() => setDays((current) => current.includes(day) ? current.filter((item) => item !== day) : [...current, day])}
              className={`grid size-10 place-items-center rounded-full text-sm font-semibold ${days.includes(day) ? "bg-accent text-onaccent" : "border border-line"}`}
            >
              {t(dayKey(day))}
            </button>
          ))}
        </div>
        <input className="field" placeholder={t("reminderLabel")} value={label} onChange={(event) => setLabel(event.target.value)} />
        <button type="button" className="h-12 rounded-full bg-accent font-semibold text-onaccent" onClick={() => void addReminder()}>
          {t("addReminder")}
        </button>
        <button
          type="button"
          className="h-11 rounded-full border border-line font-semibold"
          onClick={() => {
            void pingNotification(reminderLabel).then((result) => {
              toastTo(result === "sent" ? t("notifySent") : t("notifyNeed"));
            });
          }}
        >
          {t("notify")}
        </button>
      </section>

      <section className="panel grid gap-3 p-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted">{t("backup")}</h2>
        <button
          type="button"
          className="h-12 rounded-full border border-line font-semibold"
          onClick={() => {
            void downloadJson("brasa-copia.json", exportBackup()).then((result) => {
              if (result !== "cancelled") toastTo(t("fileReady"));
            });
          }}
        >
          {t("exportAll")}
        </button>
        <button
          type="button"
          className="h-12 rounded-full border border-line font-semibold"
          onClick={() => {
            void downloadCsv(
              "brasa-historial.csv",
              lang === "es"
                ? ["Fecha", "Entrenamiento", "Categoría", "Completado", "Segundos", "Segundos planeados", "Esfuerzo", "Nota"]
                : ["Date", "Workout", "Category", "Completed", "Seconds", "Planned seconds", "Effort", "Note"],
              sessions.map((session) => [
                new Date(session.startedAt).toISOString(),
                session.workoutName,
                session.category,
                session.completed ? "yes" : "partial",
                session.elapsedSeconds,
                session.plannedSeconds,
                session.rpe,
                session.note,
              ]),
            ).then((result) => {
              if (result !== "cancelled") toastTo(t("fileReady"));
            });
          }}
        >
          {t("exportCsv")}
        </button>
        <button type="button" className="h-12 rounded-full border border-line font-semibold" onClick={() => fileRef.current?.click()}>
          {t("importAll")}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept=".json,application/json,text/json"
          className="hidden"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            void readJson(file)
              .then((data) => {
                const record = data as { app?: string; workout?: unknown };
                const ok = record?.app === "brasa-workout" ? importWorkout(record.workout) : importBackup(data);
                if (!ok) toastTo(t("importBad"));
              })
              .catch(() => toastTo(t("importBad")));
          }}
        />
        <p className="text-sm text-muted">{t("about")}</p>
      </section>
    </div>
  );
}

function dayKey(day: number): Key {
  return (`day${day}`) as Key;
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className="flex h-12 items-center justify-between gap-3 text-left">
      <span className="font-medium">{label}</span>
      <span className={`ios-switch ${checked ? "is-on" : ""}`} aria-hidden="true">
        <span />
      </span>
    </button>
  );
}
