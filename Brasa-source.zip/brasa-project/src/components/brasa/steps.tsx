import { Footprints } from "lucide-react";
import { weekSeries } from "@/lib/brasa/day";
import { disableStepSensor, enableStepSensor } from "@/lib/brasa/sensor";
import { useBrasa } from "@/lib/brasa/store";
import type { SensorMode } from "@/lib/brasa/day";
import { cn } from "@/lib/utils";
import { PrimaryButton, Ring, useI18n, useMounted } from "./ui";

const GOALS = [6000, 8000, 10000];

function statusKey(sensor: SensorMode, tracking: boolean) {
  if (!tracking || sensor === "off") return "stepsIdle" as const;
  if (sensor === "hardware") return "stepsHardware" as const;
  if (sensor === "motion") return "stepsMotion" as const;
  if (sensor === "waiting") return "stepsWaiting" as const;
  if (sensor === "denied") return "stepsDenied" as const;
  return "stepsNone" as const;
}

export function StepsScreen() {
  const { t, lang } = useI18n();
  const mounted = useMounted();
  const steps = useBrasa((state) => state.steps);
  const setGoal = useBrasa((state) => state.setStepGoal);
  const ratio = Math.min(1, steps.today / Math.max(1, steps.goal));
  const week = mounted ? weekSeries(steps) : [0, 1, 2, 3, 4, 5, 6].map((index) => ({ date: `d${index}`, steps: 0 }));
  const peak = Math.max(steps.goal, ...week.map((day) => day.steps), 1);
  const listening = steps.tracking && steps.sensor !== "denied" && steps.sensor !== "none" && steps.sensor !== "off";
  const count = mounted ? steps.today.toLocaleString(lang === "es" ? "es" : "en") : String(steps.today);
  const goalLabel = mounted ? steps.goal.toLocaleString(lang === "es" ? "es" : "en") : String(steps.goal);

  return (
    <div data-testid="steps-screen" className="mx-auto grid w-full min-w-0 max-w-3xl gap-5 px-4 py-6 md:px-8 md:py-8">
      <header>
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-muted">Brasa</p>
        <h1 className="display mt-2 text-5xl">{t("stepsTitle")}</h1>
      </header>

      <section className="panel flex items-center gap-5 p-5 md:p-7">
        <Ring value={mounted ? ratio : 0} className="size-24" />
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted">{t("today")}</p>
          <p data-testid="step-count" className="display mt-1 text-6xl tabular-nums">
            {count}
          </p>
          <p className="mt-1 text-sm text-muted">
            {t("stepsGoal")} {goalLabel}
          </p>
        </div>
      </section>

      <section className="panel grid gap-4 p-5">
        <div className="flex items-start gap-3">
          <span className={cn("mt-1 size-2.5 shrink-0 rounded-full", listening ? "bg-good" : "bg-line")} />
          <div>
            <p className="font-semibold">{listening ? t("stepsNav") : t("stepsEnable")}</p>
            <p className="mt-1 text-sm text-muted">{t(statusKey(steps.sensor, steps.tracking))}</p>
          </div>
        </div>
        {listening ? (
          <button type="button" data-testid="step-stop" className="h-12 rounded-full border border-line font-semibold" onClick={() => disableStepSensor()}>
            {t("stepsStop")}
          </button>
        ) : (
          <PrimaryButton testId="step-enable" onClick={() => void enableStepSensor()}>
            <Footprints className="size-5" />
            {t("stepsEnable")}
          </PrimaryButton>
        )}
      </section>

      <section className="panel p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted">{t("stepsGoal")}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {GOALS.map((goal) => (
            <button
              key={goal}
              type="button"
              onClick={() => setGoal(goal)}
              className={cn(
                "h-11 rounded-full border px-4 text-sm font-semibold",
                steps.goal === goal ? "border-accent bg-raised text-ink" : "border-line text-muted",
              )}
            >
              {goal / 1000}k
            </button>
          ))}
          <button type="button" className="h-11 rounded-full border border-line px-4 text-sm font-semibold" onClick={() => setGoal(steps.goal - 500)}>
            −500
          </button>
          <button type="button" className="h-11 rounded-full border border-line px-4 text-sm font-semibold" onClick={() => setGoal(steps.goal + 500)}>
            +500
          </button>
        </div>
      </section>

      <section className="panel p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted">{t("stepsWeek")}</p>
        <div className="mt-4 grid grid-cols-7 items-end gap-2">
          {week.map((day) => {
            const height = Math.max(8, Math.round((day.steps / peak) * 100));
            const label = day.date.slice(8);
            const stepsLabel = day.steps >= 1000 ? `${(day.steps / 1000).toFixed(1)}k` : String(day.steps);
            return (
              <div key={day.date} className="flex flex-col items-center gap-1">
                <span className="text-[11px] font-semibold tabular-nums text-ink">{stepsLabel}</span>
                <div className="flex h-28 w-full items-end">
                  <div className="w-full rounded-t-xl bg-accent" style={{ height: `${height}%` }} />
                </div>
                <span className="text-xs font-semibold text-muted">{label}</span>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
